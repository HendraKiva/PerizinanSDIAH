import React, { useState, useEffect } from 'react';
import { Header, ActiveTabType } from './components/Header';
import { StatsCards } from './components/StatsCards';
import { PengajuanList } from './components/PengajuanList';
import { PengajuanModal } from './components/PengajuanModal';
import { PengajuanDetailModal } from './components/PengajuanDetailModal';
import { AdminDashboard } from './components/AdminDashboard';
import { GuruPegawaiDirectory } from './components/GuruPegawaiDirectory';
import { SqlSchemaViewer } from './components/SqlSchemaViewer';
import { ApiPlayground } from './components/ApiPlayground';
import { AndroidMobileSimulator } from './components/AndroidMobileSimulator';
import { 
  PengajuanIzin, 
  JenisPerizinan, 
  Pengguna, 
  CreatePengajuanDTO, 
  UpdatePengajuanDTO, 
  UpdateStatusDTO 
} from './types/database';
import { GuruPegawai } from './data/schoolStaffData';
import { AlertCircle, CheckCircle2, X } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTabType>('admin');

  // Main Data States
  const [pengajuanList, setPengajuanList] = useState<PengajuanIzin[]>([]);
  const [jenisList, setJenisList] = useState<JenisPerizinan[]>([]);
  const [usersList, setUsersList] = useState<Pengguna[]>([]);
  const [stats, setStats] = useState({
    totalPengajuan: 0,
    diajukan: 0,
    dalamProses: 0,
    disetujui: 0,
    ditolak: 0,
    totalRetribusi: 0,
    totalJenisIzin: 0,
    totalPengguna: 0,
  });

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('SEMUA');
  const [selectedJenis, setSelectedJenis] = useState('SEMUA');

  // Loading States
  const [isLoading, setIsLoading] = useState(true);
  const [isResetting, setIsResetting] = useState(false);

  // Modals State
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedItemForDetail, setSelectedItemForDetail] = useState<PengajuanIzin | null>(null);
  const [selectedItemForEdit, setSelectedItemForEdit] = useState<PengajuanIzin | null>(null);

  // Toast Notification State
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  };

  // Pending count for Admin badge
  const pendingCount = pengajuanList.filter(
    (p) => p.status_pengajuan === 'DIAJUKAN' || p.status_pengajuan === 'VERIFIKASI_BERKAS' || p.status_pengajuan === 'SURVEI_LAPANGAN' || p.status_pengajuan === 'MENUNGGU_PEMBAYARAN'
  ).length;

  // Quick One-Click Approval (Kepala Sekolah)
  const handleQuickApprove = async (item: PengajuanIzin) => {
    const randomSuffix = String(item.id_pengajuan).padStart(3, '0');
    const autoSk = item.nomor_surat_izin || `SK-IZN/SDIAH-YAA/VIII/2026/${randomSuffix}`;
    try {
      await handleUpdateStatus(item.id_pengajuan, {
        status_baru: 'DISETUJUI',
        id_petugas: 1, // Hendra, S.Pd. (Kepsek)
        keterangan: 'Permohonan izin disetujui langsung oleh Kepala Sekolah SDI Abu Hurairah Lahat.',
        nomor_surat_izin: autoSk,
      });
    } catch (err: any) {
      showToast(err.message || 'Gagal menyetujui izin', 'error');
    }
  };

  // Quick One-Click Reject
  const handleQuickReject = async (item: PengajuanIzin) => {
    const namaGuru = item.data_pemohon?.nama_guru_pegawai || item.pengguna?.nama_lengkap || 'Guru';
    const reason = window.prompt(
      `Masukkan catatan/alasan penolakan izin untuk ${namaGuru}:`,
      'Jadwal bertabrakan / Tugas guru inval belum dikoordinasikan.'
    );
    if (reason === null) return; // cancelled

    try {
      await handleUpdateStatus(item.id_pengajuan, {
        status_baru: 'DITOLAK',
        id_petugas: 1,
        keterangan: reason || 'Permohonan izin ditolak oleh Kepala Sekolah.',
      });
    } catch (err: any) {
      showToast(err.message || 'Gagal menolak izin', 'error');
    }
  };

  // Fetch initial master data
  useEffect(() => {
    fetchMasterData();
    fetchStats();
  }, []);

  // Fetch pengajuan whenever filters change
  useEffect(() => {
    fetchPengajuan();
  }, [searchQuery, selectedStatus, selectedJenis]);

  const fetchMasterData = async () => {
    try {
      const [resJenis, resUsers] = await Promise.all([
        fetch('/api/jenis-perizinan'),
        fetch('/api/pengguna')
      ]);
      const dataJenis = await resJenis.json();
      const dataUsers = await resUsers.json();

      if (dataJenis.success) setJenisList(dataJenis.data || []);
      if (dataUsers.success) setUsersList(dataUsers.data || []);
    } catch (err) {
      console.error('Failed to fetch master data:', err);
    }
  };

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/stats');
      const data = await res.json();
      if (data.success) {
        setStats(data.data);
      }
    } catch (err) {
      console.error('Failed to fetch stats:', err);
    }
  };

  const fetchPengajuan = async () => {
    setIsLoading(true);
    try {
      const params = new URLSearchParams();
      if (searchQuery) params.append('search', searchQuery);
      if (selectedStatus && selectedStatus !== 'SEMUA') params.append('status', selectedStatus);
      if (selectedJenis && selectedJenis !== 'SEMUA') params.append('id_jenis', selectedJenis);

      const res = await fetch(`/api/pengajuan?${params.toString()}`);
      const json = await res.json();
      if (json.success) {
        setPengajuanList(json.data || []);
      }
    } catch (err: any) {
      console.error('Failed to fetch pengajuan:', err);
      showToast('Gagal memuat data pengajuan dari Express API', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  // CRUD Handler 1: CREATE or EDIT (POST / PUT)
  const handleSavePengajuan = async (
    payload: CreatePengajuanDTO | UpdatePengajuanDTO,
    isEdit: boolean,
    id?: number
  ) => {
    const url = isEdit ? `/api/pengajuan/${id}` : '/api/pengajuan';
    const method = isEdit ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const json = await res.json();
    if (!res.ok || !json.success) {
      throw new Error(json.message || 'Gagal menyimpan pengajuan');
    }

    showToast(isEdit ? 'Data permohonan izin berhasil diperbarui!' : 'Permohonan izin guru/pegawai baru berhasil diajukan!');
    fetchPengajuan();
    fetchStats();
  };

  // CRUD Handler 2: UPDATE STATUS (PATCH /api/pengajuan/:id/status)
  const handleUpdateStatus = async (id: number, payload: UpdateStatusDTO) => {
    const res = await fetch(`/api/pengajuan/${id}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const json = await res.json();
    if (!res.ok || !json.success) {
      throw new Error(json.message || 'Gagal memperbarui status');
    }

    showToast(`Status izin berhasil diubah menjadi ${payload.status_baru}!`);
    
    // Update local modal item
    if (json.data?.pengajuan) {
      setSelectedItemForDetail(json.data.pengajuan);
    }

    fetchPengajuan();
    fetchStats();
  };

  // CRUD Handler 3: DELETE (DELETE /api/pengajuan/:id)
  const handleDeletePengajuan = async (item: PengajuanIzin) => {
    const namaGuru = item.data_pemohon?.nama_guru_pegawai || item.pengguna?.nama_lengkap || 'Guru';
    const confirmDelete = window.confirm(
      `Apakah Anda yakin ingin menghapus permohonan ${item.nomor_registrasi} untuk ${namaGuru}? Seluruh riwayat log_status juga akan dihapus.`
    );

    if (!confirmDelete) return;

    try {
      const res = await fetch(`/api/pengajuan/${item.id_pengajuan}`, {
        method: 'DELETE',
      });
      const json = await res.json();

      if (res.ok && json.success) {
        showToast(`Permohonan izin ${item.nomor_registrasi} berhasil dihapus.`);
        fetchPengajuan();
        fetchStats();
      } else {
        showToast(json.message || 'Gagal menghapus pengajuan', 'error');
      }
    } catch (err: any) {
      showToast('Terjadi kesalahan jaringan saat menghapus', 'error');
    }
  };

  // Reset Sample Data
  const handleResetData = async () => {
    setIsResetting(true);
    try {
      const res = await fetch('/api/reset-sample-data', { method: 'POST' });
      const json = await res.json();
      if (json.success) {
        showToast('Database SDI Abu Hurairah Lahat telah di-reset ke kondisi awal!');
        await fetchMasterData();
        await fetchPengajuan();
        await fetchStats();
      }
    } catch (err) {
      showToast('Gagal me-reset data sekolah', 'error');
    } finally {
      setIsResetting(false);
    }
  };

  // Open modals helper
  const handleOpenDetail = (item: PengajuanIzin) => {
    setSelectedItemForDetail(item);
    setIsDetailModalOpen(true);
  };

  const handleOpenEdit = (item: PengajuanIzin) => {
    setSelectedItemForEdit(item);
    setIsCreateModalOpen(true);
  };

  const handleOpenCreate = () => {
    setSelectedItemForEdit(null);
    setIsCreateModalOpen(true);
  };

  const handleAjukanForGuruFromDirectory = (guru: GuruPegawai) => {
    setSelectedItemForEdit(null);
    setIsCreateModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans selection:bg-emerald-600 selection:text-white antialiased">
      
      {/* Global Header with Dual Logos */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onResetData={handleResetData}
        isResetting={isResetting}
        pendingCount={pendingCount}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Floating Toast Notification */}
        {toast && (
          <div className="fixed bottom-5 right-5 z-50 animate-in slide-in-from-bottom-5 duration-200">
            <div className={`p-4 rounded-xl shadow-xl border text-xs sm:text-sm font-semibold flex items-center space-x-3 ${
              toast.type === 'success' 
                ? 'bg-slate-950 text-emerald-400 border-slate-800' 
                : 'bg-rose-950 text-rose-200 border-rose-800'
            }`}>
              {toast.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              ) : (
                <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
              )}
              <span>{toast.message}</span>
              <button 
                onClick={() => setToast(null)}
                className="text-slate-400 hover:text-white p-1 cursor-pointer transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* TAB 0: DASBOR ADMIN (PERSETUJUAN & DISPOSISI) */}
        {activeTab === 'admin' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            <AdminDashboard
              pengajuanList={pengajuanList}
              jenisList={jenisList}
              isLoading={isLoading}
              onUpdateStatus={handleUpdateStatus}
              onOpenDetailModal={handleOpenDetail}
              onOpenEditModal={handleOpenEdit}
              onRefresh={() => {
                fetchPengajuan();
                fetchStats();
              }}
            />
          </div>
        )}

        {/* TAB 1: CRUD PENGAJUAN DASHBOARD */}
        {activeTab === 'crud' && (
          <div className="space-y-6 animate-in fade-in duration-150">
            {/* KPI Metrics */}
            <StatsCards 
              stats={stats} 
              onFilterStatus={(status) => setSelectedStatus(status)} 
            />

            {/* Live CRUD Table */}
            <PengajuanList
              items={pengajuanList}
              jenisList={jenisList}
              selectedStatus={selectedStatus}
              selectedJenis={selectedJenis}
              searchQuery={searchQuery}
              isLoading={isLoading}
              onSearchChange={setSearchQuery}
              onStatusChange={setSelectedStatus}
              onJenisChange={setSelectedJenis}
              onOpenCreateModal={handleOpenCreate}
              onOpenDetailModal={handleOpenDetail}
              onOpenEditModal={handleOpenEdit}
              onDelete={handleDeletePengajuan}
              onQuickApprove={handleQuickApprove}
              onQuickReject={handleQuickReject}
            />
          </div>
        )}

        {/* TAB 2: DIREKTORI 37 GURU & PEGAWAI */}
        {activeTab === 'guru' && (
          <div className="animate-in fade-in duration-150">
            <GuruPegawaiDirectory
              onAjukanIzinForGuru={handleAjukanForGuruFromDirectory}
            />
          </div>
        )}

        {/* TAB 3: SKEMA POSTGRESQL */}
        {activeTab === 'schema' && (
          <div className="animate-in fade-in duration-150">
            <SqlSchemaViewer />
          </div>
        )}

        {/* TAB 4: REST API TESTER & CODE */}
        {activeTab === 'api' && (
          <div className="animate-in fade-in duration-150">
            <ApiPlayground />
          </div>
        )}

        {/* TAB 5: SIMULASI ANDROID */}
        {activeTab === 'android' && (
          <div className="animate-in fade-in duration-150">
            <AndroidMobileSimulator
              pengajuanList={pengajuanList}
              jenisList={jenisList}
              onRefresh={() => {
                fetchPengajuan();
                fetchStats();
              }}
              onSelectDetail={(item) => {
                setSelectedItemForDetail(item);
                setIsDetailModalOpen(true);
              }}
            />
          </div>
        )}

      </main>

      {/* Modal 1: Create & Edit Form */}
      <PengajuanModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSave={handleSavePengajuan}
        jenisList={jenisList}
        usersList={usersList}
        editItem={selectedItemForEdit}
      />

      {/* Modal 2: Detail & Tracking Logs */}
      <PengajuanDetailModal
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        pengajuan={selectedItemForDetail}
        onUpdateStatus={handleUpdateStatus}
        onRefresh={() => {
          fetchPengajuan();
          fetchStats();
        }}
      />

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-slate-500 font-medium">
          Sistem Perizinan Guru & Pegawai SDI Abu Hurairah Lahat • Yayasan Al Afwa Wal Afiah • PostgreSQL & Express REST API (Web & Android)
        </div>
      </footer>
    </div>
  );
}
