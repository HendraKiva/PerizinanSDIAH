import React, { useState, useEffect } from 'react';
import { 
  X, 
  CheckCircle2, 
  Clock, 
  FileText, 
  User, 
  Calendar, 
  GraduationCap, 
  ShieldCheck, 
  AlertTriangle, 
  ArrowRight,
  Printer,
  Send,
  Users,
  BookOpen,
  Award
} from 'lucide-react';
import { PengajuanIzin, LogStatus, StatusPengajuan, UpdateStatusDTO } from '../types/database';
import { getStatusBadge } from './PengajuanList';
import { LogoSDIAH, LogoYayasan } from './Logos';

interface PengajuanDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  pengajuan: PengajuanIzin | null;
  onUpdateStatus: (id: number, payload: UpdateStatusDTO) => Promise<void>;
  onRefresh: () => void;
}

export const PengajuanDetailModal: React.FC<PengajuanDetailModalProps> = ({
  isOpen,
  onClose,
  pengajuan,
  onUpdateStatus,
  onRefresh
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'detail' | 'logs' | 'certificate'>('detail');
  const [logs, setLogs] = useState<LogStatus[]>([]);
  const [isLoadingLogs, setIsLoadingLogs] = useState(false);

  // Status Change Form State
  const [selectedNextStatus, setSelectedNextStatus] = useState<StatusPengajuan>('VERIFIKASI_BERKAS');
  const [petugasCatatan, setPetugasCatatan] = useState('');
  const [selectedPetugasId, setSelectedPetugasId] = useState<number>(1); // Default Kepsek Hendra, S.Pd.
  const [customSkNumber, setCustomSkNumber] = useState('');
  const [isSubmittingStatus, setIsSubmittingStatus] = useState(false);
  const [statusSuccessMsg, setStatusSuccessMsg] = useState('');

  useEffect(() => {
    if (pengajuan && isOpen) {
      fetchLogs(pengajuan.id_pengajuan);
      setPetugasCatatan('');
      setStatusSuccessMsg('');

      // Auto suggest next status based on current
      if (pengajuan.status_pengajuan === 'DIAJUKAN') {
        setSelectedNextStatus('VERIFIKASI_BERKAS');
        setSelectedPetugasId(36); // Renny Melia Sari (Kurikulum)
      } else if (pengajuan.status_pengajuan === 'VERIFIKASI_BERKAS') {
        setSelectedNextStatus('DISETUJUI');
        setSelectedPetugasId(1); // Hendra, S.Pd. (Kepala Sekolah)
      } else {
        setSelectedNextStatus('DISETUJUI');
        setSelectedPetugasId(1);
      }
    }
  }, [pengajuan, isOpen]);

  const fetchLogs = async (id: number) => {
    setIsLoadingLogs(true);
    try {
      const res = await fetch(`/api/log-status/${id}`);
      const json = await res.json();
      if (json.success) {
        setLogs(json.data || []);
      }
    } catch (err) {
      console.error('Failed to fetch logs:', err);
    } finally {
      setIsLoadingLogs(false);
    }
  };

  const handleStatusSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pengajuan) return;

    setIsSubmittingStatus(true);
    try {
      await onUpdateStatus(pengajuan.id_pengajuan, {
        status_baru: selectedNextStatus,
        id_petugas: selectedPetugasId,
        keterangan: petugasCatatan || `Status izin diubah ke ${selectedNextStatus}`,
        nomor_surat_izin: customSkNumber || undefined,
      });
      setStatusSuccessMsg(`Berhasil memperbarui status menjadi ${selectedNextStatus}!`);
      setPetugasCatatan('');
      await fetchLogs(pengajuan.id_pengajuan);
      onRefresh();
    } catch (err: any) {
      console.error(err);
    } finally {
      setIsSubmittingStatus(false);
    }
  };

  if (!isOpen || !pengajuan) return null;

  const badge = getStatusBadge(pengajuan.status_pengajuan);
  const BadgeIcon = badge.icon;

  const formatDateTime = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateStr;
    }
  };

  const namaGuru = pengajuan.data_pemohon?.nama_guru_pegawai || pengajuan.pengguna?.nama_lengkap || 'Guru / Pegawai';
  const jabatan = pengajuan.data_pemohon?.jabatan || pengajuan.pengguna?.jabatan || 'Tenaga Pendidik';
  const nuptk = pengajuan.data_pemohon?.nuptk_nip || pengajuan.pengguna?.nuptk_nip || pengajuan.pengguna?.nik || '-';
  const alasan = pengajuan.data_pemohon?.alasan_izin || pengajuan.data_pemohon?.nama_usaha || '-';
  const tglMulai = pengajuan.data_pemohon?.tgl_mulai_izin || '-';
  const tglSelesai = pengajuan.data_pemohon?.tgl_selesai_izin || '-';
  const durasi = pengajuan.data_pemohon?.durasi_hari || 1;
  const guruInval = pengajuan.data_pemohon?.guru_pengganti_inval || 'Belum ditunjuk';
  const tugasInval = pengajuan.data_pemohon?.tugas_inval_siswa || 'Mengerjakan tugas modul mandiri';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-4xl overflow-hidden my-8 transform transition-all flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-linear-to-r from-emerald-800 via-teal-900 to-slate-900 px-6 py-4.5 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3.5">
            <div className="flex items-center -space-x-2 shrink-0">
              <div className="w-10 h-10 rounded-full bg-white p-0.5 shadow-md">
                <LogoYayasan className="w-full h-full" />
              </div>
              <div className="w-10 h-10 rounded-full bg-white p-0.5 shadow-md">
                <LogoSDIAH className="w-full h-full" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="font-mono text-xs font-bold text-amber-300">
                  {pengajuan.nomor_registrasi}
                </span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${badge.bg}`}>
                  {badge.label}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-black tracking-tight text-white mt-0.5">
                Permohonan Izin: {namaGuru}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-emerald-200 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sub Navigation Tabs */}
        <div className="flex items-center px-6 border-b border-slate-200 bg-slate-50 space-x-6 text-xs sm:text-sm font-bold shrink-0">
          <button
            onClick={() => setActiveSubTab('detail')}
            className={`py-3 border-b-2 transition-all cursor-pointer ${
              activeSubTab === 'detail'
                ? 'border-emerald-700 text-emerald-800'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            1. Detail & Data Izin Guru
          </button>

          <button
            onClick={() => setActiveSubTab('logs')}
            className={`py-3 border-b-2 transition-all cursor-pointer flex items-center space-x-1.5 ${
              activeSubTab === 'logs'
                ? 'border-emerald-700 text-emerald-800'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <span>2. Audit Trail Log ({logs.length})</span>
          </button>

          <button
            onClick={() => setActiveSubTab('certificate')}
            className={`py-3 border-b-2 transition-all cursor-pointer flex items-center space-x-1.5 ${
              activeSubTab === 'certificate'
                ? 'border-emerald-700 text-emerald-800'
                : 'border-transparent text-slate-500 hover:text-slate-900'
            }`}
          >
            <Award className="w-4 h-4 text-amber-600" />
            <span>3. Surat Izin Resmi SDI Abu Hurairah</span>
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="overflow-y-auto p-6 space-y-6 flex-1 text-slate-800">
          {/* TAB 1: DETAIL PERIZINAN */}
          {activeSubTab === 'detail' && (
            <div className="space-y-6">
              {/* Top Banner Status */}
              <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-700 text-white flex items-center justify-center shrink-0">
                    <BadgeIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-emerald-950">
                      Status Terkini: {badge.label}
                    </h4>
                    <p className="text-xs text-emerald-800">
                      {badge.sublabel} • Terakhir diperbarui {formatDateTime(pengajuan.updated_at)}
                    </p>
                  </div>
                </div>

                {pengajuan.nomor_surat_izin && (
                  <div className="text-left sm:text-right font-mono text-xs">
                    <span className="text-[10px] text-emerald-700 font-bold block uppercase tracking-wider">No. SK Izin Sah:</span>
                    <strong className="text-emerald-900 font-bold">{pengajuan.nomor_surat_izin}</strong>
                  </div>
                )}
              </div>

              {/* Data Guru Pemohon Card */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2.5">
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center">
                    <GraduationCap className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
                    Data Dewan Guru / Pegawai
                  </h4>
                  <div className="space-y-1 text-xs">
                    <div>
                      <span className="text-slate-400">Nama Lengkap:</span>{' '}
                      <strong className="text-slate-900 text-sm font-black">{namaGuru}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400">Jabatan:</span>{' '}
                      <span className="font-semibold text-slate-800">{jabatan}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">NUPTK / NIP:</span>{' '}
                      <span className="font-mono text-slate-800">{nuptk}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">No. WhatsApp / HP:</span>{' '}
                      <span className="font-mono text-slate-800">{pengajuan.pengguna?.no_telepon || '-'}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">Email:</span>{' '}
                      <span className="text-slate-800">{pengajuan.pengguna?.email || '-'}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2.5">
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-500 flex items-center">
                    <FileText className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
                    Kategori & Waktu Izin
                  </h4>
                  <div className="space-y-1 text-xs">
                    <div>
                      <span className="text-slate-400">Jenis Izin:</span>{' '}
                      <strong className="text-emerald-800 font-bold">{pengajuan.jenis_perizinan?.nama_izin}</strong>
                    </div>
                    <div>
                      <span className="text-slate-400">Kode Izin:</span>{' '}
                      <span className="font-mono text-slate-700">{pengajuan.jenis_perizinan?.kode_izin}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">Rentang Tanggal:</span>{' '}
                      <span className="font-bold text-slate-900">{tglMulai} s.d. {tglSelesai}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">Total Durasi:</span>{' '}
                      <span className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-900 font-black text-xs">{durasi} Hari Kerja</span>
                    </div>
                    <div>
                      <span className="text-slate-400">Mapel / Kelas:</span>{' '}
                      <span className="text-slate-800">{pengajuan.data_pemohon?.mata_pelajaran_kelas || 'Tematik SD'}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Alasan & Guru Inval Card */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="bg-white p-4 rounded-xl border border-slate-200 space-y-2">
                  <h4 className="text-xs font-black uppercase tracking-wider text-slate-500">
                    Alasan / Keperluan Izin
                  </h4>
                  <p className="text-xs text-slate-700 bg-slate-50 p-3 rounded-lg border border-slate-200 leading-relaxed font-medium">
                    {alasan}
                  </p>
                  {pengajuan.catatan_petugas && (
                    <div className="text-xs text-emerald-900 bg-emerald-50/70 p-2.5 rounded-lg border border-emerald-200">
                      <strong>Catatan Petugas / Kepsek:</strong> {pengajuan.catatan_petugas}
                    </div>
                  )}
                </div>

                <div className="bg-amber-50/40 p-4 rounded-xl border border-amber-200 space-y-2">
                  <h4 className="text-xs font-black uppercase tracking-wider text-amber-900 flex items-center">
                    <Users className="w-3.5 h-3.5 mr-1.5 text-amber-700" />
                    Pelimpahan Tugas Guru Pengganti (Inval)
                  </h4>
                  <div className="text-xs space-y-1.5">
                    <div>
                      <span className="text-slate-500">Guru Inval:</span>{' '}
                      <strong className="text-slate-900">{guruInval}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500">Tugas / Modul Siswa:</span>{' '}
                      <span className="text-slate-700">{tugasInval}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Dokumen Lampiran */}
              <div className="space-y-3">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center">
                  <FileText className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
                  Dokumen Berkas Lampiran ({pengajuan.dokumen_lampiran?.length || 0})
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {pengajuan.dokumen_lampiran?.map((doc) => (
                    <div
                      key={doc.id_dokumen}
                      className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                    >
                      <div className="flex items-center space-x-2 truncate">
                        <FileText className="w-4 h-4 text-emerald-700 shrink-0" />
                        <span className="font-semibold text-slate-800 truncate">{doc.nama_dokumen}</span>
                        <span className="text-[10px] text-slate-400 font-mono shrink-0">({doc.ukuran_kb} KB)</span>
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-bold shrink-0">
                        Terverifikasi
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Update Status Workflow */}
              <div className="p-5 bg-linear-to-b from-slate-50 to-emerald-50/30 rounded-2xl border border-emerald-200 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-xs font-black uppercase tracking-wider text-emerald-950 flex items-center">
                      <ShieldCheck className="w-4 h-4 mr-1.5 text-emerald-700" />
                      Disposisi & Persetujuan Izin Sekolah (Workflow Update)
                    </h4>
                    <p className="text-[11px] text-slate-500">
                      Ubah status izin dan catat riwayat secara otomatis ke tabel <code className="bg-white px-1 rounded text-emerald-800 font-mono">log_status</code>.
                    </p>
                  </div>
                </div>

                {statusSuccessMsg && (
                  <div className="p-3 bg-emerald-100 border border-emerald-300 text-emerald-900 rounded-xl text-xs flex items-center space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                    <span>{statusSuccessMsg}</span>
                  </div>
                )}

                <form onSubmit={handleStatusSubmit} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                        Pilih Status Selanjutnya
                      </label>
                      <select
                        value={selectedNextStatus}
                        onChange={(e) => setSelectedNextStatus(e.target.value as StatusPengajuan)}
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value="VERIFIKASI_BERKAS">VERIFIKASI_BERKAS (Pemeriksaan Kurikulum / TU)</option>
                        <option value="DISETUJUI">DISETUJUI (Kepala Sekolah Hendra, S.Pd. Menyetujui)</option>
                        <option value="DITOLAK">DITOLAK / DITINJAU ULANG</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                        Petugas Verifikator / Penandatangan
                      </label>
                      <select
                        value={selectedPetugasId}
                        onChange={(e) => setSelectedPetugasId(Number(e.target.value))}
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                      >
                        <option value={1}>HENDRA, S.Pd. (Kepala Sekolah SDI Abu Hurairah)</option>
                        <option value={36}>RENNY MELIA SARI, Dipl, Phil, B.A. (Koordinator Kurikulum)</option>
                        <option value={33}>MIKO RAHMAN, S.A.P. (Kepala Tata Usaha)</option>
                        <option value={31}>IMAM MUTTAQIN S.Sos (Waka Humas)</option>
                        <option value={38}>Pengurus Yayasan Al Afwa Wal Afiah</option>
                      </select>
                    </div>
                  </div>

                  {selectedNextStatus === 'DISETUJUI' && (
                    <div>
                      <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                        Nomor Surat Keputusan (SK) Izin (Opsional / Otomatis)
                      </label>
                      <input
                        type="text"
                        value={customSkNumber}
                        onChange={(e) => setCustomSkNumber(e.target.value)}
                        placeholder="SK-IZN/SDIAH-YAA/VIII/2026/015 (Kosongkan untuk otomatis)"
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl font-mono font-bold text-slate-800"
                      />
                    </div>
                  )}

                  <div>
                    <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700 mb-1">
                      Catatan Disposisi / Keterangan Persetujuan
                    </label>
                    <textarea
                      rows={2}
                      value={petugasCatatan}
                      onChange={(e) => setPetugasCatatan(e.target.value)}
                      placeholder="Masukkan catatan persetujuan, konfirmasi jadwal guru inval, atau instruksi dari Kepala Sekolah..."
                      className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 text-slate-800"
                    />
                  </div>

                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={isSubmittingStatus}
                      className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold rounded-xl shadow-md shadow-emerald-700/20 transition-all flex items-center cursor-pointer disabled:opacity-50"
                    >
                      {isSubmittingStatus ? (
                        <span>Memproses Perubahan Status...</span>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5 mr-1.5" />
                          <span>Perbarui Status & Simpan ke Audit Log</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>

            </div>
          )}

          {/* TAB 2: AUDIT LOG TIMELINE */}
          {activeSubTab === 'logs' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-black text-slate-900">Riwayat Perjalanan Berkas Izin (Audit Trail)</h4>
                  <p className="text-xs text-slate-500">
                    Data riwayat status diambil dari tabel <code className="bg-slate-100 text-emerald-800 px-1 py-0.5 rounded font-mono">log_status</code> dengan <code className="bg-slate-100 text-emerald-800 px-1 py-0.5 rounded font-mono">id_pengajuan = {pengajuan.id_pengajuan}</code>
                  </p>
                </div>
                <button
                  onClick={() => fetchLogs(pengajuan.id_pengajuan)}
                  className="text-xs text-emerald-700 hover:text-emerald-900 font-bold cursor-pointer"
                >
                  Segarkan Log
                </button>
              </div>

              {isLoadingLogs ? (
                <div className="py-8 text-center text-xs text-slate-500">Memuat riwayat log...</div>
              ) : logs.length === 0 ? (
                <div className="py-8 text-center text-xs text-slate-400">Belum ada riwayat status.</div>
              ) : (
                <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                  {logs.map((log) => {
                    const prevBadge = log.status_sebelumnya ? getStatusBadge(log.status_sebelumnya) : null;
                    const nextBadge = getStatusBadge(log.status_baru);
                    return (
                      <div key={log.id_log} className="relative group">
                        <div className={`absolute -left-6 top-1 w-3.5 h-3.5 rounded-full border-2 border-white shadow-xs ${nextBadge.dot}`} />
                        
                        <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-1.5">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="flex items-center space-x-2 text-xs">
                              {prevBadge ? (
                                <>
                                  <span className={`px-2 py-0.5 rounded text-[11px] font-bold border ${prevBadge.bg}`}>
                                    {prevBadge.label}
                                  </span>
                                  <ArrowRight className="w-3 h-3 text-slate-400" />
                                </>
                              ) : (
                                <span className="text-[11px] text-slate-400 font-medium">Awal:</span>
                              )}
                              <span className={`px-2 py-0.5 rounded text-[11px] font-black border ${nextBadge.bg}`}>
                                {nextBadge.label}
                              </span>
                            </div>
                            <span className="text-[11px] text-slate-400 font-mono flex items-center">
                              <Calendar className="w-3 h-3 mr-1" />
                              {formatDateTime(log.created_at)}
                            </span>
                          </div>

                          <p className="text-xs text-slate-700 font-semibold">
                            {log.keterangan || 'Tidak ada catatan tambahan.'}
                          </p>

                          <div className="pt-1 text-[11px] text-slate-500 flex items-center">
                            <User className="w-3 h-3 mr-1 text-slate-400" />
                            <span>
                              Aktor Petugas: <strong>{log.petugas?.nama_lengkap || `Pengguna ID #${log.id_petugas || '-'}`}</strong>
                              {log.petugas?.jabatan && ` (${log.petugas.jabatan})`}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: SURAT IZIN RESMI SDI ABU HURAIRAH LAHAT */}
          {activeSubTab === 'certificate' && (
            <div className="space-y-4">
              <div className="p-6 sm:p-8 bg-white border-2 border-emerald-800/60 rounded-2xl shadow-lg space-y-6 relative print:border-none print:shadow-none">
                {/* Official Letterhead with Both Logos */}
                <div className="flex items-center justify-between pb-4 border-b-2 border-slate-900 gap-4">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 shrink-0">
                    <LogoYayasan className="w-full h-full" />
                  </div>
                  
                  <div className="text-center flex-1">
                    <h3 className="text-xs sm:text-sm uppercase tracking-wider font-extrabold text-slate-700">
                      YAYASAN AL AFWA WAL AFIAH KABUPATEN LAHAT
                    </h3>
                    <h1 className="text-base sm:text-xl font-black text-emerald-900 tracking-tight">
                      SEKOLAH DASAR ISLAM (SDI) ABU HURAIRAH LAHAT
                    </h1>
                    <p className="text-[10px] sm:text-xs text-slate-500 mt-0.5">
                      Jl. Mayor Ruslan III / Lingkungan Pendidikan Abu Hurairah, Kabupaten Lahat, Sumatera Selatan
                    </p>
                    <p className="text-[10px] text-slate-400 font-mono">
                      NPSN: 699XXXXX • Email: sdiah.lahat@gmail.com • Telp: (0731) 321XXX
                    </p>
                  </div>

                  <div className="w-16 h-16 sm:w-20 sm:h-20 shrink-0">
                    <LogoSDIAH className="w-full h-full" />
                  </div>
                </div>

                {/* Surat Title */}
                <div className="text-center space-y-1">
                  <h2 className="text-sm sm:text-base font-black text-slate-900 underline uppercase tracking-wide">
                    SURAT KETERANGAN IZIN GURU & PEGAWAI
                  </h2>
                  <p className="font-mono text-xs font-bold text-emerald-800">
                    Nomor: {pengajuan.nomor_surat_izin || 'SK-IZN/SDIAH-YAA/VIII/2026/015'}
                  </p>
                </div>

                {/* Body Text */}
                <div className="text-xs text-slate-800 space-y-3 leading-relaxed">
                  <p>
                    Yang bertanda tangan di bawah ini, Kepala Sekolah Dasar Islam (SDI) Abu Hurairah Lahat, menerangkan bahwa:
                  </p>
                  
                  <div className="grid grid-cols-3 gap-2 pl-4 py-2 bg-slate-50 rounded-xl border border-slate-200 font-mono text-xs">
                    <span className="text-slate-500 font-sans">Nama Lengkap</span>
                    <span className="col-span-2 font-black text-slate-900 font-sans">: {namaGuru}</span>

                    <span className="text-slate-500 font-sans">NUPTK / NIP</span>
                    <span className="col-span-2 text-slate-900">: {nuptk}</span>

                    <span className="text-slate-500 font-sans">Jabatan / Tugas</span>
                    <span className="col-span-2 font-sans font-semibold text-slate-900">: {jabatan}</span>

                    <span className="text-slate-500 font-sans">Mata Pelajaran / Kelas</span>
                    <span className="col-span-2 font-sans text-slate-900">: {pengajuan.data_pemohon?.mata_pelajaran_kelas || 'Tematik SD'}</span>

                    <span className="text-slate-500 font-sans">Jenis Izin</span>
                    <span className="col-span-2 font-sans font-bold text-emerald-800">: {pengajuan.jenis_perizinan?.nama_izin}</span>

                    <span className="text-slate-500 font-sans">Alasan / Keperluan</span>
                    <span className="col-span-2 font-sans text-slate-800">: {alasan}</span>

                    <span className="text-slate-500 font-sans">Waktu Pelaksanaan</span>
                    <span className="col-span-2 font-sans font-bold text-slate-900">: {tglMulai} s.d. {tglSelesai} ({durasi} Hari)</span>

                    <span className="text-slate-500 font-sans">Guru Pengganti (Inval)</span>
                    <span className="col-span-2 font-sans text-slate-900">: {guruInval}</span>
                  </div>

                  <p>
                    Diberikan izin tidak melaksanakan tugas mengajar/dinas pada tanggal yang telah disebutkan di atas. Selama masa izin, tugas pembelajaran telah dilimpahkan kepada Guru Pengganti (Inval) dan dikoordinasikan bersama Guru Piket.
                  </p>
                  <p>
                    Demikian surat izin ini dibuat dan disahkan untuk dipergunakan sebagaimana mestinya.
                  </p>
                </div>

                {/* Signature Section */}
                <div className="flex justify-between items-end pt-6 text-xs text-slate-800">
                  <div className="text-center">
                    <p className="text-[11px] text-slate-500">Mengetahui,</p>
                    <p className="font-bold text-slate-900 mt-1">Pengurus Yayasan Al Afwa Wal Afiah</p>
                    <div className="h-16 flex items-center justify-center">
                      <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-mono">
                        [TERVALIDASI ELEKTRONIK]
                      </span>
                    </div>
                    <p className="font-black text-slate-900">( Pengurus Yayasan )</p>
                  </div>

                  <div className="text-center">
                    <p className="text-[11px] text-slate-500">Lahat, {pengajuan.tgl_terbit || new Date().toISOString().split('T')[0]}</p>
                    <p className="font-bold text-slate-900 mt-1">Kepala SDI Abu Hurairah Lahat</p>
                    <div className="h-16 flex items-center justify-center">
                      <span className="text-[10px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 font-mono">
                        [DIGITALLY SIGNED & VERIFIED]
                      </span>
                    </div>
                    <p className="font-black text-slate-900 text-sm underline">HENDRA, S.Pd.</p>
                    <p className="text-[10px] text-slate-500 font-mono">NIP/NUPTK: 197805122005011002</p>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center hover:bg-emerald-800 cursor-pointer shadow-md shadow-emerald-700/20"
                >
                  <Printer className="w-3.5 h-3.5 mr-1.5" />
                  <span>Cetak Surat Izin Resmi SDI Abu Hurairah</span>
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between rounded-b-2xl text-xs text-slate-500">
          <span>ID Pengajuan: <strong>#{pengajuan.id_pengajuan}</strong> • SDI Abu Hurairah Lahat</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl transition-colors cursor-pointer"
          >
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
};
