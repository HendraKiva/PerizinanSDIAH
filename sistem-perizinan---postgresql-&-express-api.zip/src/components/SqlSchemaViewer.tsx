import React, { useState } from 'react';
import { 
  Database, 
  Copy, 
  Check, 
  Download, 
  Table, 
  Key, 
  Link, 
  Layers, 
  FileCode, 
  Smartphone, 
  ShieldAlert,
  ArrowRight,
  Info
} from 'lucide-react';
import { TABLE_SCHEMAS, POSTGRESQL_DDL_SCRIPT } from '../data/sqlSchema';

export const SqlSchemaViewer: React.FC = () => {
  const [activeTableTab, setActiveTableTab] = useState<string>('pengajuan_izin');
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<'dictionary' | 'erd' | 'raw_sql'>('dictionary');

  const selectedTable = TABLE_SCHEMAS.find((t) => t.tableName === activeTableTab) || TABLE_SCHEMAS[0];

  const handleCopySql = () => {
    navigator.clipboard.writeText(POSTGRESQL_DDL_SCRIPT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadSql = () => {
    const element = document.createElement('a');
    const file = new Blob([POSTGRESQL_DDL_SCRIPT], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = 'struktur_database_perizinan_postgresql.sql';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner / Explanation */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/90 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2.5">
              <span className="p-2 rounded-xl bg-blue-50 text-blue-700 border border-blue-200/60">
                <Database className="w-5 h-5" />
              </span>
              <h2 className="text-lg font-bold text-slate-900 tracking-tight">Arsitektur Database PostgreSQL Aplikasi Perizinan</h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-600 mt-1.5 max-w-3xl leading-relaxed">
              Struktur database relasional yang dirancang khusus untuk memenuhi standar aplikasi perizinan berbasis Web & Android (Mobile), mencakup 4 tabel utama: <code className="bg-slate-100 text-blue-800 px-1.5 py-0.5 rounded font-mono font-bold text-xs">pengguna</code>, <code className="bg-slate-100 text-blue-800 px-1.5 py-0.5 rounded font-mono font-bold text-xs">jenis_perizinan</code>, <code className="bg-slate-100 text-blue-800 px-1.5 py-0.5 rounded font-mono font-bold text-xs">pengajuan_izin</code>, dan <code className="bg-slate-100 text-blue-800 px-1.5 py-0.5 rounded font-mono font-bold text-xs">log_status</code>.
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex items-center space-x-2 shrink-0">
            <button
              onClick={handleCopySql}
              className="inline-flex items-center px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
                  <span>Tersalin!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 mr-1.5" />
                  <span>Salin Skrip SQL</span>
                </>
              )}
            </button>
            <button
              onClick={handleDownloadSql}
              className="inline-flex items-center px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold rounded-xl shadow-xs shadow-blue-500/20 transition-all cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 mr-1.5" />
              <span>Download .sql</span>
            </button>
          </div>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center space-x-2 mt-5 border-t border-slate-100 pt-4">
          <span className="text-xs font-bold text-slate-400 mr-2 uppercase tracking-wider">Mode Tampilan:</span>
          <button
            onClick={() => setViewMode('dictionary')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              viewMode === 'dictionary'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Kamus Data (Data Dictionary)
          </button>
          <button
            onClick={() => setViewMode('erd')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              viewMode === 'erd'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Diagram Relasi (ERD)
          </button>
          <button
            onClick={() => setViewMode('raw_sql')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
              viewMode === 'raw_sql'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Skrip Lengkap DDL (PostgreSQL)
          </button>
        </div>
      </div>

      {/* VIEW 1: DATA DICTIONARY */}
      {viewMode === 'dictionary' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          
          {/* Table Selector Tabs */}
          <div className="flex overflow-x-auto border-b border-slate-200 bg-slate-50 p-2 gap-2">
            {TABLE_SCHEMAS.map((tbl) => (
              <button
                key={tbl.tableName}
                onClick={() => setActiveTableTab(tbl.tableName)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center whitespace-nowrap transition-colors ${
                  activeTableTab === tbl.tableName
                    ? 'bg-white text-blue-700 shadow-xs border border-slate-200'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <Table className="w-3.5 h-3.5 mr-1.5 text-blue-600" />
                <span className="font-mono">{tbl.tableName}</span>
                <span className="ml-2 px-1.5 py-0.2 rounded bg-slate-100 text-[10px] text-slate-500 font-sans">
                  {tbl.columns.length} kolom
                </span>
              </button>
            ))}
          </div>

          {/* Table Description Header */}
          <div className="p-5 border-b border-slate-200 bg-white">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-base font-bold font-mono text-slate-900 flex items-center">
                  <span>TABEL: {selectedTable.tableName}</span>
                  <span className="ml-2 px-2 py-0.5 rounded text-xs font-sans font-medium bg-blue-50 text-blue-700 border border-blue-200">
                    Primary Key: {selectedTable.primaryKey}
                  </span>
                </h3>
                <p className="text-xs text-slate-600 mt-1">{selectedTable.description}</p>
              </div>

              {/* Foreign Keys & Indexes Badges */}
              {selectedTable.foreignKeys && selectedTable.foreignKeys.length > 0 && (
                <div className="text-xs space-y-1">
                  <span className="text-[11px] font-bold text-slate-400 block uppercase">Foreign Keys:</span>
                  {selectedTable.foreignKeys.map((fk, idx) => (
                    <div key={idx} className="font-mono text-[11px] bg-slate-50 px-2 py-0.5 rounded text-slate-700 border border-slate-200">
                      {fk.column} → <span className="text-blue-700 font-bold">{fk.referencesTable}({fk.referencesColumn})</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Columns Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-600 text-xs font-semibold uppercase tracking-wider border-b border-slate-200">
                  <th className="py-3 px-4">Nama Kolom</th>
                  <th className="py-3 px-4">Tipe Data PostgreSQL</th>
                  <th className="py-3 px-4">Constraint / Sifat</th>
                  <th className="py-3 px-4">Null?</th>
                  <th className="py-3 px-4">Nilai Default</th>
                  <th className="py-3 px-4">Deskripsi Fungsi Kolom</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-800">
                {selectedTable.columns.map((col) => {
                  const isPK = col.columnName === selectedTable.primaryKey;
                  const isFK = selectedTable.foreignKeys?.some((fk) => fk.column === col.columnName);
                  return (
                    <tr key={col.columnName} className="hover:bg-slate-50/60 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-slate-900 flex items-center">
                        {isPK && <Key className="w-3.5 h-3.5 mr-1 text-amber-500" title="Primary Key" />}
                        {isFK && <Link className="w-3.5 h-3.5 mr-1 text-blue-500" title="Foreign Key" />}
                        <span>{col.columnName}</span>
                      </td>
                      <td className="py-3 px-4 font-mono text-blue-700 font-semibold">
                        {col.dataType}
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-600">
                        {col.constraints || '-'}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-0.5 rounded font-mono text-[10px] ${
                          col.nullable ? 'bg-slate-100 text-slate-600' : 'bg-rose-50 text-rose-700 font-bold'
                        }`}>
                          {col.nullable ? 'YES' : 'NO (NOT NULL)'}
                        </span>
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-500">
                        {col.defaultValue || '-'}
                      </td>
                      <td className="py-3 px-4 text-slate-700 leading-relaxed max-w-sm">
                        {col.description}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Indexes */}
          {selectedTable.indexes && selectedTable.indexes.length > 0 && (
            <div className="p-4 bg-slate-50 border-t border-slate-200 text-xs">
              <span className="font-bold text-slate-700">Indexes & Optimasi Performa Query:</span>
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                {selectedTable.indexes.map((idx, i) => (
                  <span key={i} className="font-mono text-[11px] bg-white border border-slate-200 text-slate-700 px-2 py-0.5 rounded">
                    {idx}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* VIEW 2: ERD DIAGRAM */}
      {viewMode === 'erd' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6">
          <div>
            <h3 className="text-base font-bold text-slate-900">Entity Relationship Diagram (ERD) Perizinan</h3>
            <p className="text-xs text-slate-500">
              Relasi antar tabel relasional PostgreSQL untuk Web dan Android:
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Box 1: pengguna */}
            <div className="border-2 border-blue-400 bg-blue-50/20 rounded-xl overflow-hidden shadow-xs">
              <div className="bg-blue-600 text-white p-2.5 font-mono font-bold text-xs flex items-center justify-between">
                <span>pengguna</span>
                <span className="text-[10px] bg-blue-700 px-1.5 py-0.5 rounded">1 (One)</span>
              </div>
              <div className="p-3 text-[11px] space-y-1 font-mono">
                <div className="font-bold text-amber-700">🔑 id_pengguna (PK)</div>
                <div>nama_lengkap</div>
                <div>nik (UNIQUE)</div>
                <div>email (UNIQUE)</div>
                <div>password_hash</div>
                <div>no_telepon</div>
                <div>peran (ENUM)</div>
                <div className="text-emerald-700 font-semibold">fcm_token (Android)</div>
                <div className="text-slate-400">created_at, updated_at</div>
              </div>
            </div>

            {/* Box 2: jenis_perizinan */}
            <div className="border-2 border-emerald-400 bg-emerald-50/20 rounded-xl overflow-hidden shadow-xs">
              <div className="bg-emerald-600 text-white p-2.5 font-mono font-bold text-xs flex items-center justify-between">
                <span>jenis_perizinan</span>
                <span className="text-[10px] bg-emerald-700 px-1.5 py-0.5 rounded">1 (One)</span>
              </div>
              <div className="p-3 text-[11px] space-y-1 font-mono">
                <div className="font-bold text-amber-700">🔑 id_jenis (PK)</div>
                <div>kode_izin (UNIQUE)</div>
                <div>nama_izin</div>
                <div className="text-purple-700 font-semibold">persyaratan (JSONB)</div>
                <div>estimasi_hari_kerja</div>
                <div>biaya_retribusi</div>
                <div>masa_berlaku_tahun</div>
                <div className="text-slate-400">is_active, created_at</div>
              </div>
            </div>

            {/* Box 3: pengajuan_izin (CENTRAL) */}
            <div className="border-2 border-indigo-600 bg-indigo-50/30 rounded-xl overflow-hidden shadow-md">
              <div className="bg-indigo-700 text-white p-2.5 font-mono font-bold text-xs flex items-center justify-between">
                <span>pengajuan_izin</span>
                <span className="text-[10px] bg-indigo-800 px-1.5 py-0.5 rounded">N (Many)</span>
              </div>
              <div className="p-3 text-[11px] space-y-1 font-mono">
                <div className="font-bold text-amber-700">🔑 id_pengajuan (PK)</div>
                <div className="font-bold text-blue-700">nomor_registrasi (UQ)</div>
                <div className="text-blue-600 font-semibold">🔗 id_pengguna (FK)</div>
                <div className="text-emerald-600 font-semibold">🔗 id_jenis (FK)</div>
                <div className="text-purple-700 font-semibold">data_pemohon (JSONB)</div>
                <div className="text-purple-700 font-semibold">dokumen_lampiran (JSONB)</div>
                <div className="font-bold text-indigo-900">status_pengajuan (ENUM)</div>
                <div>catatan_petugas</div>
                <div>nomor_surat_izin</div>
                <div>biaya_final, status_pembayaran</div>
                <div className="text-slate-400">created_at, updated_at</div>
              </div>
            </div>

            {/* Box 4: log_status */}
            <div className="border-2 border-amber-400 bg-amber-50/20 rounded-xl overflow-hidden shadow-xs">
              <div className="bg-amber-600 text-white p-2.5 font-mono font-bold text-xs flex items-center justify-between">
                <span>log_status</span>
                <span className="text-[10px] bg-amber-700 px-1.5 py-0.5 rounded">N (Many)</span>
              </div>
              <div className="p-3 text-[11px] space-y-1 font-mono">
                <div className="font-bold text-amber-700">🔑 id_log (PK)</div>
                <div className="text-indigo-600 font-semibold">🔗 id_pengajuan (FK)</div>
                <div>status_sebelumnya (ENUM)</div>
                <div className="font-bold text-amber-900">status_baru (ENUM)</div>
                <div className="text-blue-600 font-semibold">🔗 id_petugas (FK)</div>
                <div>keterangan (TEXT)</div>
                <div className="text-slate-400 font-semibold">created_at (TIMESTAMP)</div>
              </div>
            </div>
          </div>

          {/* Relational Flow Descriptions */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2 text-xs text-slate-700">
            <h4 className="font-bold text-slate-900">Penjelasan Hubungan Kunci Relasi (Foreign Keys):</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-semibold text-blue-700 block">pengguna (1) → (N) pengajuan_izin</span>
                <p className="text-[11px] text-slate-500 mt-1">Satu pemohon/warga dapat memiliki banyak pengajuan perizinan sekaligus (1 to Many).</p>
              </div>
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-semibold text-emerald-700 block">jenis_perizinan (1) → (N) pengajuan_izin</span>
                <p className="text-[11px] text-slate-500 mt-1">Satu jenis master perizinan (misal: IMB) dapat diajukan oleh banyak pemohon.</p>
              </div>
              <div className="p-3 bg-white rounded-lg border border-slate-200">
                <span className="font-semibold text-indigo-700 block">pengajuan_izin (1) → (N) log_status</span>
                <p className="text-[11px] text-slate-500 mt-1">Setiap pengajuan izin memiliki riwayat kronologis lengkap perpindahan status untuk audit trail.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 3: RAW DDL SCRIPT */}
      {viewMode === 'raw_sql' && (
        <div className="bg-slate-900 text-slate-100 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
          <div className="p-4 bg-slate-800/80 border-b border-slate-700 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <FileCode className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-mono text-slate-300">schema_perizinan_postgresql.sql</span>
            </div>
            <button
              onClick={handleCopySql}
              className="text-xs text-slate-300 hover:text-white px-2.5 py-1 bg-slate-700 hover:bg-slate-600 rounded transition-colors flex items-center cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 mr-1 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 mr-1" />}
              <span>{copied ? 'Tersalin' : 'Salin SQL'}</span>
            </button>
          </div>
          <pre className="p-5 font-mono text-xs overflow-x-auto text-emerald-300/90 leading-relaxed max-h-[600px] overflow-y-auto">
            {POSTGRESQL_DDL_SCRIPT}
          </pre>
        </div>
      )}

      {/* Engineering Highlights / Keunggulan Arsitektur */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center space-x-2 text-blue-700 font-bold text-xs">
            <Smartphone className="w-4 h-4" />
            <span>Optimal untuk Web & Android</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Menyediakan kolom <code className="text-blue-700 font-mono">fcm_token</code> untuk Firebase Cloud Messaging (Android Push Notification saat status berubah) dan field koordinat GPS Lat/Lng di dalam <code className="text-blue-700 font-mono">data_pemohon</code>.
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center space-x-2 text-purple-700 font-bold text-xs">
            <Layers className="w-4 h-4" />
            <span>Fleksibilitas JSONB PostgreSQL</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Penggunaan <code className="text-purple-700 font-mono">JSONB</code> untuk formulir dinamis & daftar berkas lampiran memungkinkan setiap jenis izin memiliki input yang variatif tanpa perlu merubah skema tabel fisik.
          </p>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center space-x-2 text-emerald-700 font-bold text-xs">
            <ShieldAlert className="w-4 h-4" />
            <span>Integritas & Audit Trail Ketat</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Tabel <code className="text-emerald-700 font-mono">log_status</code> mencatat siapa petugas yang memverifikasi, waktu persis, status sebelum-sesudah, serta alasan, menjamin transparansi pelayanan publik.
          </p>
        </div>
      </div>

    </div>
  );
};
