import React, { useState } from 'react';
import { 
  Smartphone, 
  Wifi, 
  Battery, 
  Bell, 
  PlusCircle, 
  Camera, 
  CheckCircle2, 
  Clock, 
  FileText, 
  ChevronRight, 
  User,
  Calendar,
  Users,
  GraduationCap,
  Sparkles,
  BookOpen,
  ShieldCheck
} from 'lucide-react';
import { PengajuanIzin, JenisPerizinan } from '../types/database';
import { DAFTAR_GURU_PEGAWAI } from '../data/schoolStaffData';
import { LogoSDIAH, LogoYayasan } from './Logos';
import { getStatusBadge } from './PengajuanList';

interface AndroidSimulatorProps {
  pengajuanList: PengajuanIzin[];
  jenisList: JenisPerizinan[];
  onRefresh: () => void;
  onSelectDetail: (item: PengajuanIzin) => void;
}

export const AndroidMobileSimulator: React.FC<AndroidSimulatorProps> = ({
  pengajuanList,
  jenisList,
  onRefresh,
  onSelectDetail,
}) => {
  const [mobileTab, setMobileTab] = useState<'home' | 'status' | 'form'>('home');
  const [selectedGuruId, setSelectedGuruId] = useState<number>(7); // NIA WULANDARI
  const [selectedJenisForForm, setSelectedJenisForForm] = useState<number>(1);
  const [alasanIzin, setAlasanIzin] = useState('');
  const [tglMulai, setTglMulai] = useState(new Date().toISOString().split('T')[0]);
  const [tglSelesai, setTglSelesai] = useState(new Date().toISOString().split('T')[0]);
  const [guruInval, setGuruInval] = useState('WIWIN WINDRIANI');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showPushNotification, setShowPushNotification] = useState(true);

  const selectedGuru = DAFTAR_GURU_PEGAWAI.find(g => g.id === selectedGuruId) || DAFTAR_GURU_PEGAWAI[0];
  const selectedJenisObj = jenisList.find((j) => j.id_jenis === selectedJenisForForm) || jenisList[0];

  const handleMobileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!alasanIzin) return;

    setIsSubmitting(true);
    try {
      const payload = {
        id_pengguna: selectedGuruId,
        id_jenis: selectedJenisForForm,
        data_pemohon: {
          nama_guru_pegawai: selectedGuru.nama,
          jabatan: selectedGuru.jabatan,
          nuptk_nip: selectedGuru.nuptk_nip,
          mata_pelajaran_kelas: "Tematik SD",
          alasan_izin: alasanIzin,
          tgl_mulai_izin: tglMulai,
          tgl_selesai_izin: tglSelesai,
          durasi_hari: 1,
          guru_pengganti_inval: guruInval,
          tugas_inval_siswa: "Latihan soal mandiri & membaca senyap.",
        },
        dokumen_lampiran: [
          {
            id_dokumen: `doc_mobile_${Date.now()}`,
            nama_dokumen: "Foto_Surat_Dokter_Kamera_Android.jpg",
            url: "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=600&auto=format&fit=crop&q=60",
            tipe_file: "image/jpeg",
            ukuran_kb: 480,
            uploaded_at: new Date().toISOString(),
          }
        ],
        catatan_pemohon: `Diajukan via Aplikasi Mobile Android SDIAH oleh ${selectedGuru.nama}.`
      };

      const res = await fetch('/api/pengajuan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        setAlasanIzin('');
        setMobileTab('status');
        onRefresh();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      
      {/* Description column */}
      <div className="lg:col-span-6 space-y-4">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center space-x-3 text-emerald-800 font-black">
            <span className="p-2.5 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200">
              <Smartphone className="w-5 h-5" />
            </span>
            <div>
              <h3 className="text-base font-black text-slate-900">
                Aplikasi Mobile Android SDI Abu Hurairah Lahat
              </h3>
              <p className="text-xs text-slate-500 font-normal">
                Sistem Terpadu Guru & Pegawai • Kotlin / Jetpack Compose & REST API
              </p>
            </div>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            Aplikasi Android ini digunakan oleh <strong>37 Dewan Guru & Pegawai SDI Abu Hurairah Lahat</strong> untuk mengajukan permohonan izin harian, cuti, dispensasi dinas, mengunggah foto surat dokter langsung dari kamera HP, serta menerima notifikasi Firebase Cloud Messaging (FCM) saat disetujui Kepala Sekolah Hendra, S.Pd.
          </p>

          {/* Feature Checklist */}
          <div className="space-y-2 pt-2 border-t border-slate-100 text-xs">
            <div className="flex items-start space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span><strong>Login Otomatis NUPTK:</strong> Terhubung dengan database 37 personil sekolah.</span>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span><strong>Integrasi Kamera HP:</strong> Langsung foto surat dokter / surat tugas dinas.</span>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span><strong>Pelimpahan Guru Inval:</strong> Otomatis memberi notifikasi kepada guru pengganti.</span>
            </div>
            <div className="flex items-start space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span><strong>Notifikasi Realtime:</strong> Status disposisi langsung update di layar Android.</span>
            </div>
          </div>

          {/* Push Notification Toggle Demo */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between text-xs">
            <div className="flex items-center space-x-2">
              <Bell className="w-4 h-4 text-amber-500" />
              <span className="font-bold text-slate-700">Simulasi Notifikasi FCM Android</span>
            </div>
            <button
              onClick={() => setShowPushNotification(!showPushNotification)}
              className="text-[11px] font-bold text-emerald-700 hover:text-emerald-900 cursor-pointer"
            >
              {showPushNotification ? 'Sembunyikan' : 'Tampilkan'}
            </button>
          </div>
        </div>
      </div>

      {/* Android Device Frame Simulation */}
      <div className="lg:col-span-6 flex justify-center">
        <div className="w-[340px] sm:w-[360px] h-[680px] bg-slate-950 rounded-[44px] p-3 shadow-2xl ring-12 ring-slate-800/80 border-4 border-slate-700 relative overflow-hidden flex flex-col">
          
          {/* Hardware Notch */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-36 h-6 bg-slate-950 rounded-b-2xl z-40 flex items-center justify-center space-x-2">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-900 border border-slate-700"></div>
            <div className="w-12 h-1.5 rounded-full bg-slate-900"></div>
          </div>

          {/* Mobile Screen Container */}
          <div className="bg-slate-50 w-full h-full rounded-[34px] overflow-hidden flex flex-col relative z-20">
            
            {/* Status Bar */}
            <div className="bg-emerald-900 text-white px-5 pt-3 pb-2 flex items-center justify-between text-[10px] font-mono shrink-0">
              <span>08:45</span>
              <div className="flex items-center space-x-1.5">
                <Wifi className="w-3 h-3" />
                <span>4G+</span>
                <Battery className="w-3.5 h-3.5" />
              </div>
            </div>

            {/* In-App Push Notification Popup Simulation */}
            {showPushNotification && (
              <div className="bg-slate-900/95 text-white m-2 p-2.5 rounded-2xl shadow-xl border border-emerald-500/30 flex items-start space-x-2.5 animate-bounce z-50 text-[11px]">
                <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center shrink-0 mt-0.5">
                  <LogoSDIAH className="w-4 h-4" />
                </div>
                <div className="flex-1">
                  <div className="font-bold flex items-center justify-between">
                    <span>SDIAH Mobile • Disetujui</span>
                    <span className="text-[9px] text-slate-400">Baru saja</span>
                  </div>
                  <p className="text-[10px] text-slate-300 line-clamp-2">
                    Permohonan Izin Anda telah disetujui Kepala Sekolah Hendra, S.Pd. SK Izin resmi telah terbit.
                  </p>
                </div>
              </div>
            )}

            {/* App Top Bar with Dual Logos */}
            <div className="bg-emerald-800 text-white p-3.5 flex items-center justify-between shadow-md shrink-0">
              <div className="flex items-center space-x-2">
                <div className="flex items-center -space-x-1.5">
                  <div className="w-7 h-7 rounded-full bg-white p-0.5 shadow-sm">
                    <LogoYayasan className="w-full h-full" />
                  </div>
                  <div className="w-7 h-7 rounded-full bg-white p-0.5 shadow-sm">
                    <LogoSDIAH className="w-full h-full" />
                  </div>
                </div>
                <div>
                  <h4 className="text-xs font-black leading-tight">SDI Abu Hurairah</h4>
                  <p className="text-[9px] text-emerald-200 leading-none">Izin Guru & Pegawai</p>
                </div>
              </div>

              <div className="flex items-center space-x-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-[10px] font-bold text-emerald-100">Live</span>
              </div>
            </div>

            {/* Mobile Body Content */}
            <div className="flex-1 overflow-y-auto p-3 space-y-3">
              
              {/* TAB 1: HOME */}
              {mobileTab === 'home' && (
                <div className="space-y-3">
                  {/* User Profile Banner */}
                  <div className="bg-linear-to-r from-emerald-700 to-teal-800 text-white p-3.5 rounded-2xl shadow-sm space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] uppercase font-bold text-emerald-200">Profil Dewan Guru</span>
                      <span className="text-[9px] bg-emerald-900/60 px-2 py-0.5 rounded-full text-emerald-300 font-mono">
                        NUPTK: {selectedGuru.nuptk_nip}
                      </span>
                    </div>

                    <div className="flex items-center space-x-2.5">
                      <div className="w-10 h-10 rounded-full bg-amber-400 text-slate-900 flex items-center justify-center font-black text-sm">
                        {selectedGuru.nama.charAt(0)}
                      </div>
                      <div>
                        <h4 className="text-xs font-black leading-tight">{selectedGuru.nama}</h4>
                        <p className="text-[10px] text-emerald-200">{selectedGuru.jabatan}</p>
                      </div>
                    </div>
                  </div>

                  {/* Fast Action Buttons */}
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setMobileTab('form')}
                      className="p-3 bg-white border border-emerald-200 rounded-xl shadow-2xs hover:bg-emerald-50 text-left space-y-1 cursor-pointer"
                    >
                      <PlusCircle className="w-5 h-5 text-emerald-700" />
                      <div className="text-xs font-black text-slate-800 leading-tight">Ajukan Izin</div>
                      <div className="text-[9px] text-slate-400">Sakit / Dinas / Pribadi</div>
                    </button>

                    <button
                      onClick={() => setMobileTab('status')}
                      className="p-3 bg-white border border-emerald-200 rounded-xl shadow-2xs hover:bg-emerald-50 text-left space-y-1 cursor-pointer"
                    >
                      <Clock className="w-5 h-5 text-amber-600" />
                      <div className="text-xs font-black text-slate-800 leading-tight">Status Izin</div>
                      <div className="text-[9px] text-slate-400">Tracking Disposisi</div>
                    </button>
                  </div>

                  {/* Recent Permit Requests */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                      <span>Permohonan Terakhir</span>
                      <button onClick={() => setMobileTab('status')} className="text-emerald-700 text-[10px]">
                        Lihat Semua
                      </button>
                    </div>

                    {pengajuanList.slice(0, 3).map((item) => {
                      const badge = getStatusBadge(item.status_pengajuan);
                      const namaG = item.data_pemohon?.nama_guru_pegawai || item.pengguna?.nama_lengkap || 'Guru';
                      return (
                        <div
                          key={item.id_pengajuan}
                          onClick={() => onSelectDetail(item)}
                          className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-2xs space-y-1 hover:border-emerald-400 transition-all cursor-pointer"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[10px] font-mono font-bold text-emerald-800">
                              {item.nomor_registrasi}
                            </span>
                            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${badge.bg}`}>
                              {badge.label}
                            </span>
                          </div>
                          <div className="text-[11px] font-black text-slate-900 truncate">
                            {item.jenis_perizinan?.nama_izin || 'Izin'}
                          </div>
                          <div className="text-[10px] text-slate-500 truncate flex items-center justify-between">
                            <span>{namaG}</span>
                            <span>{item.data_pemohon?.durasi_hari || 1} Hari</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* TAB 2: FORM AJUKAN */}
              {mobileTab === 'form' && (
                <form onSubmit={handleMobileSubmit} className="space-y-2.5 text-xs">
                  <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-2">
                    <label className="block text-[10px] font-bold uppercase text-slate-600">
                      Pilih Dewan Guru (37 Staf)
                    </label>
                    <select
                      value={selectedGuruId}
                      onChange={(e) => setSelectedGuruId(Number(e.target.value))}
                      className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-900"
                    >
                      {DAFTAR_GURU_PEGAWAI.map((g) => (
                        <option key={g.id} value={g.id}>
                          {g.nama} ({g.kategori})
                        </option>
                      ))}
                    </select>

                    <label className="block text-[10px] font-bold uppercase text-slate-600 mt-2">
                      Kategori Izin
                    </label>
                    <select
                      value={selectedJenisForForm}
                      onChange={(e) => setSelectedJenisForForm(Number(e.target.value))}
                      className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-900"
                    >
                      {jenisList.map((j) => (
                        <option key={j.id_jenis} value={j.id_jenis}>
                          {j.nama_izin}
                        </option>
                      ))}
                    </select>

                    <label className="block text-[10px] font-bold uppercase text-slate-600 mt-2">
                      Alasan Permohonan Izin
                    </label>
                    <textarea
                      rows={2}
                      value={alasanIzin}
                      onChange={(e) => setAlasanIzin(e.target.value)}
                      placeholder="Misal: Sakit radang, undangan Bimtek Diknas Lahat..."
                      className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs"
                      required
                    />

                    <label className="block text-[10px] font-bold uppercase text-slate-600 mt-2">
                      Guru Pengganti (Inval)
                    </label>
                    <select
                      value={guruInval}
                      onChange={(e) => setGuruInval(e.target.value)}
                      className="w-full p-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold"
                    >
                      {DAFTAR_GURU_PEGAWAI.filter(g => g.id !== selectedGuruId).map((g) => (
                        <option key={g.id} value={g.nama}>
                          {g.nama}
                        </option>
                      ))}
                    </select>

                    {/* Camera Attachment simulation */}
                    <div className="p-2.5 bg-emerald-50 rounded-lg border border-emerald-200 flex items-center justify-between mt-2">
                      <div className="flex items-center space-x-2">
                        <Camera className="w-4 h-4 text-emerald-700" />
                        <span className="text-[10px] font-bold text-emerald-900">Lampirkan Foto Surat</span>
                      </div>
                      <span className="text-[9px] text-emerald-700 bg-white px-2 py-0.5 rounded border border-emerald-300">
                        Foto_Kamera.jpg (480 KB)
                      </span>
                    </div>
                  </div>

                  {/* Notice Approval Workflow */}
                  <div className="bg-amber-50 p-2.5 rounded-xl border border-amber-200/80 flex items-start space-x-2 text-[10px] text-amber-900 leading-tight">
                    <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                    <span>
                      <strong>Alur Persetujuan:</strong> Izin yang Anda kirim akan masuk ke antrean akun <strong>Kepala Sekolah (Hendra, S.Pd.)</strong> / <strong>Admin Yayasan</strong> untuk diperiksa dan disetujui.
                    </span>
                  </div>

                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => setMobileTab('home')}
                      className="flex-1 py-2 bg-slate-200 rounded-xl text-xs font-bold text-slate-700 cursor-pointer"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="flex-1 py-2 bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md hover:bg-emerald-800 cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? 'Mengirim...' : 'Kirim ke Meja Kepsek'}
                    </button>
                  </div>
                </form>
              )}

              {/* TAB 3: STATUS / TRACKING */}
              {mobileTab === 'status' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-slate-700 pb-1 border-b border-slate-200">
                    <span>Tracking Izin Guru ({pengajuanList.length})</span>
                    <button onClick={() => setMobileTab('form')} className="text-emerald-700 text-[10px] font-bold">
                      + Ajukan
                    </button>
                  </div>

                  {pengajuanList.map((item) => {
                    const badge = getStatusBadge(item.status_pengajuan);
                    const namaG = item.data_pemohon?.nama_guru_pegawai || item.pengguna?.nama_lengkap || 'Guru';
                    return (
                      <div
                        key={item.id_pengajuan}
                        onClick={() => onSelectDetail(item)}
                        className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs space-y-1.5 hover:border-emerald-500 cursor-pointer transition-all"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] font-mono font-bold text-emerald-800">
                            {item.nomor_registrasi}
                          </span>
                          <span className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${badge.bg}`}>
                            {badge.label}
                          </span>
                        </div>
                        <div className="text-xs font-black text-slate-900">
                          {item.jenis_perizinan?.nama_izin || 'Izin'}
                        </div>
                        <div className="text-[10px] text-slate-600">
                          <strong>Guru:</strong> {namaG}
                        </div>
                        {item.nomor_surat_izin && (
                          <div className="text-[9px] font-mono text-emerald-700 bg-emerald-50 p-1 rounded font-bold">
                            SK: {item.nomor_surat_izin}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}

            </div>

            {/* Mobile Bottom Navigation */}
            <div className="bg-white border-t border-slate-200 px-4 py-2 flex items-center justify-around text-[10px] font-bold shrink-0">
              <button
                onClick={() => setMobileTab('home')}
                className={`flex flex-col items-center space-y-0.5 ${mobileTab === 'home' ? 'text-emerald-700' : 'text-slate-400'}`}
              >
                <Users className="w-4 h-4" />
                <span>Beranda</span>
              </button>

              <button
                onClick={() => setMobileTab('form')}
                className={`flex flex-col items-center space-y-0.5 ${mobileTab === 'form' ? 'text-emerald-700' : 'text-slate-400'}`}
              >
                <PlusCircle className="w-4 h-4" />
                <span>Ajukan</span>
              </button>

              <button
                onClick={() => setMobileTab('status')}
                className={`flex flex-col items-center space-y-0.5 ${mobileTab === 'status' ? 'text-emerald-700' : 'text-slate-400'}`}
              >
                <Clock className="w-4 h-4" />
                <span>Status</span>
              </button>
            </div>

            {/* Android Navigation Home Bar */}
            <div className="bg-white pb-2 flex justify-center shrink-0">
              <div className="w-24 h-1 bg-slate-300 rounded-full"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
