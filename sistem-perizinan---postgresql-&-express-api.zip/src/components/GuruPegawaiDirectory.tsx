import React, { useState } from 'react';
import { DAFTAR_GURU_PEGAWAI, GuruPegawai } from '../data/schoolStaffData';
import { Search, PlusCircle, Users, Phone, Mail, Award, CheckCircle2, Shield } from 'lucide-react';
import { LogoSDIAH, LogoYayasan } from './Logos';

interface GuruPegawaiDirectoryProps {
  onAjukanIzinForGuru: (guru: GuruPegawai) => void;
}

export const GuruPegawaiDirectory: React.FC<GuruPegawaiDirectoryProps> = ({
  onAjukanIzinForGuru
}) => {
  const [search, setSearch] = useState('');
  const [kategoriFilter, setKategoriFilter] = useState<'SEMUA' | 'Guru' | 'Pegawai / Tata Usaha' | 'Pimpinan'>('SEMUA');

  const filteredList = DAFTAR_GURU_PEGAWAI.filter((g) => {
    const matchSearch =
      g.nama.toLowerCase().includes(search.toLowerCase()) ||
      g.jabatan.toLowerCase().includes(search.toLowerCase()) ||
      g.nuptk_nip.includes(search) ||
      g.email.toLowerCase().includes(search.toLowerCase());

    const matchKategori = kategoriFilter === 'SEMUA' || g.kategori === kategoriFilter;

    return matchSearch && matchKategori;
  });

  const totalGuru = DAFTAR_GURU_PEGAWAI.filter((g) => g.kategori === 'Guru').length;
  const totalStaf = DAFTAR_GURU_PEGAWAI.filter((g) => g.kategori === 'Pegawai / Tata Usaha').length;
  const totalPimpinan = DAFTAR_GURU_PEGAWAI.filter((g) => g.kategori === 'Pimpinan').length;

  return (
    <div className="space-y-6">
      {/* Banner Card with Dual Logos */}
      <div className="bg-linear-to-r from-emerald-800 via-teal-900 to-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-md border border-emerald-700/40 relative overflow-hidden">
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
          <div className="flex items-center space-x-4">
            <div className="flex items-center -space-x-3 shrink-0">
              <div className="w-16 h-16 rounded-full bg-white p-1 shadow-lg ring-4 ring-white/20 z-10">
                <LogoYayasan className="w-full h-full" />
              </div>
              <div className="w-16 h-16 rounded-full bg-white p-1 shadow-lg ring-4 ring-white/20">
                <LogoSDIAH className="w-full h-full" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider bg-amber-400 text-slate-900">
                  Database Resmi 2026
                </span>
                <span className="text-emerald-300 text-xs font-semibold">
                  Yayasan Al Afwa Wal Afiah
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black mt-1 tracking-tight">
                Daftar 37 Dewan Guru & Pegawai
              </h2>
              <p className="text-xs sm:text-sm text-emerald-100/80 mt-1 max-w-2xl">
                Sekolah Dasar Islam (SDI) Abu Hurairah Lahat • Terintegrasi dengan Sistem Perizinan dan PostgreSQL Database.
              </p>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center gap-3 bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/10 shrink-0">
            <div className="text-center px-2">
              <div className="text-lg font-black text-amber-300">{DAFTAR_GURU_PEGAWAI.length}</div>
              <div className="text-[10px] text-emerald-100 font-medium">Total Personil</div>
            </div>
            <div className="w-px h-8 bg-white/20" />
            <div className="text-center px-2">
              <div className="text-lg font-black text-white">{totalGuru}</div>
              <div className="text-[10px] text-emerald-100 font-medium">Guru Pendidik</div>
            </div>
            <div className="w-px h-8 bg-white/20" />
            <div className="text-center px-2">
              <div className="text-lg font-black text-white">{totalStaf + totalPimpinan}</div>
              <div className="text-[10px] text-emerald-100 font-medium">Staf & Pimpinan</div>
            </div>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            id="search-guru-input"
            type="text"
            placeholder="Cari nama guru, NUPTK, atau jabatan..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white transition-all font-medium text-slate-900"
          />
        </div>

        <div className="flex items-center space-x-1.5 w-full sm:w-auto overflow-x-auto">
          {(['SEMUA', 'Guru', 'Pegawai / Tata Usaha', 'Pimpinan'] as const).map((kat) => (
            <button
              key={kat}
              onClick={() => setKategoriFilter(kat)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-all cursor-pointer shrink-0 ${
                kategoriFilter === kat
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
              }`}
            >
              {kat === 'SEMUA' ? `Semua (${DAFTAR_GURU_PEGAWAI.length})` : kat}
            </button>
          ))}
        </div>
      </div>

      {/* Grid of Teachers and Staff */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredList.map((guru, index) => {
          const isPimpinan = guru.kategori === 'Pimpinan';
          const isGuru = guru.kategori === 'Guru';

          return (
            <div
              key={guru.id}
              className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs hover:shadow-md hover:border-emerald-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-black text-sm text-white shrink-0 ${
                      isPimpinan 
                        ? 'bg-amber-600 ring-2 ring-amber-200' 
                        : isGuru 
                        ? 'bg-emerald-600 ring-2 ring-emerald-100' 
                        : 'bg-blue-600 ring-2 ring-blue-100'
                    }`}>
                      {guru.nama.charAt(0)}
                    </div>
                    <div>
                      <div className="text-xs font-black text-slate-400">
                        #{guru.id.toString().padStart(2, '0')}
                      </div>
                      <h3 className="text-sm font-black text-slate-900 leading-snug">
                        {guru.nama}
                      </h3>
                    </div>
                  </div>

                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                    isPimpinan
                      ? 'bg-amber-50 text-amber-800 border-amber-200'
                      : isGuru
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                      : 'bg-blue-50 text-blue-800 border-blue-200'
                  }`}>
                    {guru.kategori}
                  </span>
                </div>

                <div className="mt-3 space-y-1.5 text-xs text-slate-600">
                  <div className="flex items-center text-slate-700 font-semibold">
                    <Award className="w-3.5 h-3.5 mr-1.5 text-emerald-600 shrink-0" />
                    <span>{guru.jabatan}</span>
                  </div>

                  <div className="flex items-center text-slate-500 font-mono text-[11px]">
                    <Shield className="w-3.5 h-3.5 mr-1.5 text-slate-400 shrink-0" />
                    <span>NUPTK: {guru.nuptk_nip}</span>
                  </div>

                  <div className="flex items-center text-slate-500 text-[11px]">
                    <Mail className="w-3.5 h-3.5 mr-1.5 text-slate-400 shrink-0" />
                    <span className="truncate">{guru.email}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-emerald-700 font-medium flex items-center">
                  <CheckCircle2 className="w-3 h-3 mr-1 text-emerald-600" />
                  Status Aktif
                </span>
                
                <button
                  onClick={() => onAjukanIzinForGuru(guru)}
                  className="inline-flex items-center px-2.5 py-1 text-xs font-bold text-emerald-700 hover:text-white bg-emerald-50 hover:bg-emerald-700 border border-emerald-200 hover:border-emerald-700 rounded-lg transition-all cursor-pointer"
                >
                  <PlusCircle className="w-3 h-3 mr-1" />
                  Ajukan Izin
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
