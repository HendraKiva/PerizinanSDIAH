import React from 'react';
import { FileText, Clock, CheckCircle2, XCircle, Users, BookOpen, TrendingUp } from 'lucide-react';
import { DAFTAR_GURU_PEGAWAI } from '../data/schoolStaffData';

interface StatsProps {
  stats: {
    totalPengajuan: number;
    diajukan: number;
    dalamProses: number;
    disetujui: number;
    ditolak: number;
    totalRetribusi: number;
    totalJenisIzin: number;
    totalPengguna: number;
  };
  onFilterStatus?: (status: string) => void;
}

export const StatsCards: React.FC<StatsProps> = ({ stats, onFilterStatus }) => {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
      {/* 37 Dewan Guru & Pegawai */}
      <div 
        id="stat-card-guru"
        className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs hover:border-emerald-500 transition-all duration-150 group"
      >
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">Dewan Guru/Staf</span>
          <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:bg-emerald-700 group-hover:text-white transition-colors">
            <Users className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">{DAFTAR_GURU_PEGAWAI.length}</span>
          <span className="text-[10px] font-bold bg-emerald-50 text-emerald-800 px-1.5 py-0.5 rounded">Aktif</span>
        </div>
        <span className="text-[10px] text-slate-400 block mt-0.5 truncate">SDI Abu Hurairah</span>
      </div>

      {/* Total Izin Masuk */}
      <div 
        id="stat-card-total"
        onClick={() => onFilterStatus && onFilterStatus('SEMUA')}
        className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs cursor-pointer hover:border-emerald-500 transition-all duration-150 group"
      >
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">Total Izin</span>
          <div className="w-7 h-7 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center group-hover:bg-teal-700 group-hover:text-white transition-colors">
            <FileText className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">{stats.totalPengajuan}</span>
          <span className="text-[10px] font-bold text-teal-700 flex items-center">
            <TrendingUp className="w-3 h-3 mr-0.5" /> Th. 2026
          </span>
        </div>
        <span className="text-[10px] text-slate-400 block mt-0.5">Semua permohonan</span>
      </div>

      {/* Menunggu Verifikasi */}
      <div 
        id="stat-card-diajukan"
        onClick={() => onFilterStatus && onFilterStatus('DIAJUKAN')}
        className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs cursor-pointer hover:border-amber-400 transition-all duration-150 group"
      >
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">Permohonan Baru</span>
          <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-white transition-colors">
            <Clock className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="text-xl sm:text-2xl font-black text-amber-600 tracking-tight">{stats.diajukan}</span>
          <span className="text-[10px] font-bold bg-amber-50 text-amber-700 px-1.5 py-0.5 rounded">Antrean</span>
        </div>
        <span className="text-[10px] text-slate-400 block mt-0.5">Menunggu Verifikasi</span>
      </div>

      {/* Sedang Verifikasi Berkas */}
      <div 
        id="stat-card-proses"
        onClick={() => onFilterStatus && onFilterStatus('VERIFIKASI_BERKAS')}
        className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs cursor-pointer hover:border-blue-400 transition-all duration-150 group"
      >
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">Verifikasi Inval</span>
          <div className="w-7 h-7 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center group-hover:bg-blue-600 group-hover:text-white transition-colors">
            <BookOpen className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="text-xl sm:text-2xl font-black text-blue-600 tracking-tight">{stats.dalamProses}</span>
          <span className="text-[10px] font-bold bg-blue-50 text-blue-700 px-1.5 py-0.5 rounded">Review TU</span>
        </div>
        <span className="text-[10px] text-slate-400 block mt-0.5">Cek Rencana Inval</span>
      </div>

      {/* Disetujui (Izin Terbit) */}
      <div 
        id="stat-card-disetujui"
        onClick={() => onFilterStatus && onFilterStatus('DISETUJUI')}
        className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs cursor-pointer hover:border-emerald-500 transition-all duration-150 group"
      >
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">Izin Disetujui</span>
          <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:bg-emerald-700 group-hover:text-white transition-colors">
            <CheckCircle2 className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="text-xl sm:text-2xl font-black text-emerald-700 tracking-tight">{stats.disetujui}</span>
          <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded">SK Terbit</span>
        </div>
        <span className="text-[10px] text-slate-400 block mt-0.5">TTD Kepala Sekolah</span>
      </div>

      {/* Ditolak / Dibatalkan */}
      <div 
        id="stat-card-ditolak"
        onClick={() => onFilterStatus && onFilterStatus('DITOLAK')}
        className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs cursor-pointer hover:border-rose-400 transition-all duration-150 group"
      >
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-black uppercase tracking-wider text-slate-500">Ditolak/Revisi</span>
          <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center group-hover:bg-rose-600 group-hover:text-white transition-colors">
            <XCircle className="w-3.5 h-3.5" />
          </div>
        </div>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="text-xl sm:text-2xl font-black text-rose-600 tracking-tight">{stats.ditolak}</span>
          <span className="text-[10px] font-bold bg-rose-50 text-rose-700 px-1.5 py-0.5 rounded">Tinjau</span>
        </div>
        <span className="text-[10px] text-slate-400 block mt-0.5">Tidak memenuhi syarat</span>
      </div>
    </div>
  );
};
