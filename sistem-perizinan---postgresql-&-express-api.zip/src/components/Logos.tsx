import React from 'react';

interface LogoProps {
  className?: string;
  size?: number | string;
}

export const LogoSDIAH: React.FC<LogoProps> = ({ className = 'w-12 h-12', size }) => {
  return (
    <svg
      viewBox="0 0 500 500"
      className={className}
      style={size ? { width: size, height: size } : undefined}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Curved Path for Text "SEKOLAH DASAR ISLAM" */}
        <path id="sdiah-top-arc" d="M 65,250 A 185,185 0 0,1 435,250" fill="none" />
        {/* Curved Path for Text "LAHAT" */}
        <path id="sdiah-bot-arc" d="M 100,270 A 180,180 0 0,0 400,270" fill="none" />
        <linearGradient id="book-gold" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#FACC15" />
          <stop offset="100%" stopColor="#EAB308" />
        </linearGradient>
      </defs>

      {/* Main Outer Circle White */}
      <circle cx="250" cy="250" r="238" fill="#FFFFFF" stroke="#111827" strokeWidth="12" />

      {/* Top Arc Text */}
      <text fill="#111827" fontSize="33" fontWeight="900" letterSpacing="4">
        <textPath href="#sdiah-top-arc" startOffset="50%" textAnchor="middle">
          SEKOLAH DASAR ISLAM
        </textPath>
      </text>

      {/* Bottom Arc Text */}
      <text fill="#111827" fontSize="48" fontWeight="900" letterSpacing="6">
        <textPath href="#sdiah-bot-arc" startOffset="50%" textAnchor="middle">
          LAHAT
        </textPath>
      </text>

      {/* Inner Green Circle */}
      <circle cx="250" cy="250" r="162" fill="#16A34A" stroke="#111827" strokeWidth="9" />

      {/* "SDI" Heading inside Green Circle */}
      <text x="250" y="165" fill="#111827" fontSize="46" fontWeight="900" textAnchor="middle" letterSpacing="3">
        SDI
      </text>

      {/* Open Book / Al-Qur'an Graphic */}
      <g transform="translate(135, 168) scale(0.92)">
        {/* Book Base Outline Gold */}
        <path
          d="M 125,75 C 90,65 40,68 0,82 L 0,16 C 45,5 95,3 125,18 C 155,3 205,5 250,16 L 250,82 C 210,68 160,65 125,75 Z"
          fill="url(#book-gold)"
          stroke="#111827"
          strokeWidth="6"
        />
        {/* Book Pages White */}
        <path
          d="M 125,68 C 95,58 45,60 10,72 L 10,22 C 50,12 95,10 125,24 C 155,10 200,12 240,22 L 240,72 C 205,60 155,58 125,68 Z"
          fill="#FFFFFF"
          stroke="#111827"
          strokeWidth="5"
        />
        {/* Book Center Seam */}
        <line x1="125" y1="24" x2="125" y2="68" stroke="#111827" strokeWidth="4" />
      </g>

      {/* Ribbon Banner Wings (Left & Right) */}
      <polygon points="30,295 90,270 90,378 30,378 68,336" fill="#FACC15" stroke="#111827" strokeWidth="7" />
      <polygon points="470,295 410,270 410,378 470,378 432,336" fill="#FACC15" stroke="#111827" strokeWidth="7" />

      {/* Left wing year Arabic ١٤٣٧ */}
      <text x="74" y="365" fill="#111827" fontSize="22" fontWeight="800" textAnchor="middle">
        ١٤٣٧
      </text>

      {/* Right wing year 2015 */}
      <text x="426" y="365" fill="#111827" fontSize="21" fontWeight="800" textAnchor="middle">
        2015
      </text>

      {/* Main Center Yellow Banner */}
      <rect x="85" y="270" width="330" height="85" rx="4" fill="#FACC15" stroke="#111827" strokeWidth="8" />

      {/* Arabic Calligraphy "ابو هريرة" */}
      <text x="250" y="306" fill="#111827" fontSize="32" fontWeight="900" textAnchor="middle" fontFamily="sans-serif">
        ابو هريرة
      </text>

      {/* Latin Text "ABU HURAIRAH" */}
      <text x="250" y="340" fill="#111827" fontSize="22" fontWeight="900" textAnchor="middle" letterSpacing="3">
        ABU HURAIRAH
      </text>

      {/* Kec. Lahat text in lower green zone */}
      <text x="250" y="385" fill="#111827" fontSize="20" fontWeight="900" textAnchor="middle" letterSpacing="1.5">
        KEC. LAHAT
      </text>
    </svg>
  );
};

export const LogoYayasan: React.FC<LogoProps> = ({ className = 'w-12 h-12', size }) => {
  return (
    <svg
      viewBox="0 0 500 500"
      className={className}
      style={size ? { width: size, height: size } : undefined}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Curved Path for Text "YAYASAN AL AFWA WAL AFIAH" */}
        <path id="yayasan-top-arc" d="M 60,255 A 190,190 0 0,1 440,255" fill="none" />
        {/* Curved Path for Text "KABUPATEN LAHAT" */}
        <path id="yayasan-bot-arc" d="M 90,265 A 185,185 0 0,0 410,265" fill="none" />
        
        {/* Green Book Gradient */}
        <linearGradient id="quran-green-grad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#22C55E" />
          <stop offset="60%" stopColor="#16A34A" />
          <stop offset="100%" stopColor="#15803D" />
        </linearGradient>

        <linearGradient id="dome-green" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#15803D" />
          <stop offset="100%" stopColor="#166534" />
        </linearGradient>
      </defs>

      {/* Outer Circle Container */}
      <circle cx="250" cy="250" r="238" fill="#FFFFFF" stroke="#111827" strokeWidth="12" />

      {/* Top Arc Text */}
      <text fill="#111827" fontSize="29" fontWeight="900" letterSpacing="3.5">
        <textPath href="#yayasan-top-arc" startOffset="50%" textAnchor="middle">
          YAYASAN AL AFWA WAL AFIAH
        </textPath>
      </text>

      {/* Left Star */}
      <polygon
        points="95,305 99,315 110,316 102,323 104,334 95,328 86,334 88,323 80,316 91,315"
        fill="#FFFFFF"
        stroke="#111827"
        strokeWidth="3.5"
      />

      {/* Right Star */}
      <polygon
        points="405,305 409,315 420,316 412,323 414,334 405,328 396,334 398,323 390,316 401,315"
        fill="#FFFFFF"
        stroke="#111827"
        strokeWidth="3.5"
      />

      {/* Bottom Arc Text */}
      <text fill="#111827" fontSize="33" fontWeight="900" letterSpacing="4.5">
        <textPath href="#yayasan-bot-arc" startOffset="50%" textAnchor="middle">
          KABUPATEN LAHAT
        </textPath>
      </text>

      {/* Center Circle Content Area */}
      <circle cx="250" cy="250" r="172" fill="#FFFFFF" stroke="#111827" strokeWidth="5" />

      {/* Crescent & Star above Dome */}
      <g transform="translate(230, 115) scale(0.9)">
        {/* Crescent */}
        <path
          d="M 22,2 A 18,18 0 1,0 40,28 A 15,15 0 1,1 22,2 Z"
          fill="#111827"
        />
        {/* Small Star inside crescent */}
        <polygon
          points="36,10 38,15 43,15 39,18 40,23 36,20 32,23 33,18 29,15 34,15"
          fill="#FACC15"
          stroke="#111827"
          strokeWidth="1"
        />
      </g>

      {/* Mosque Dome */}
      <g transform="translate(202, 142)">
        {/* Dome shape */}
        <path
          d="M 48,0 C 48,0 40,15 15,30 C 0,38 0,50 0,50 L 96,50 C 96,50 96,38 81,30 C 56,15 48,0 48,0 Z"
          fill="url(#dome-green)"
          stroke="#111827"
          strokeWidth="4"
        />
        {/* Dome Base */}
        <rect x="5" y="50" width="86" height="15" fill="#15803D" stroke="#111827" strokeWidth="4" />
        {/* Small windows */}
        <rect x="15" y="53" width="7" height="7" fill="#FFFFFF" stroke="#111827" strokeWidth="2" />
        <rect x="34" y="53" width="7" height="7" fill="#FFFFFF" stroke="#111827" strokeWidth="2" />
        <rect x="55" y="53" width="7" height="7" fill="#FFFFFF" stroke="#111827" strokeWidth="2" />
        <rect x="74" y="53" width="7" height="7" fill="#FFFFFF" stroke="#111827" strokeWidth="2" />
      </g>

      {/* Open Green Al-Qur'an / Book */}
      <g transform="translate(136, 185)">
        {/* Left Book Page */}
        <path
          d="M 114,75 C 75,60 25,64 0,72 L 48,15 C 75,10 100,10 114,24 Z"
          fill="url(#quran-green-grad)"
          stroke="#111827"
          strokeWidth="4"
        />
        {/* Right Book Page */}
        <path
          d="M 114,75 C 153,60 203,64 228,72 L 180,15 C 153,10 128,10 114,24 Z"
          fill="url(#quran-green-grad)"
          stroke="#111827"
          strokeWidth="4"
        />
        {/* Spine line */}
        <line x1="114" y1="24" x2="114" y2="75" stroke="#FFFFFF" strokeWidth="6" />
        <line x1="114" y1="24" x2="114" y2="75" stroke="#111827" strokeWidth="2" />
        
        {/* Subtle white bookmark ribbon */}
        <path d="M 112,75 L 112,88 L 114,84 L 116,88 L 116,75 Z" fill="#FFFFFF" stroke="#111827" strokeWidth="1.5" />
      </g>

      {/* Two Praying Hands (Tangan Berdoa) */}
      <g transform="translate(172, 255)">
        {/* Left Hand */}
        <path
          d="M 25,70 C 10,70 0,60 5,45 L 20,12 C 22,6 26,6 28,12 L 34,42 C 34,30 38,10 42,4 C 44,0 48,0 50,4 L 54,42 C 54,32 58,18 62,10 C 64,6 68,6 70,10 L 74,45 C 74,38 78,25 82,20 C 84,17 88,18 89,22 L 88,68 C 88,88 65,108 45,108 C 25,108 25,70 25,70 Z"
          fill="#FEF08A"
          stroke="#111827"
          strokeWidth="4"
        />
        {/* Right Hand (Mirrored) */}
        <path
          d="M 131,70 C 146,70 156,60 151,45 L 136,12 C 134,6 130,6 128,12 L 122,42 C 122,30 118,10 114,4 C 112,0 108,0 106,4 L 102,42 C 102,32 98,18 94,10 C 92,6 88,6 86,10 L 82,45 C 82,38 78,25 74,20 C 72,17 68,18 67,22 L 68,68 C 68,88 91,108 111,108 C 131,108 131,70 131,70 Z"
          fill="#FEF08A"
          stroke="#111827"
          strokeWidth="4"
        />
      </g>
    </svg>
  );
};

export const CombinedSchoolBrand: React.FC<{
  showFullText?: boolean;
  size?: 'sm' | 'md' | 'lg';
}> = ({ showFullText = true, size = 'md' }) => {
  const logoSizes = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-14 h-14'
  };

  return (
    <div className="flex items-center space-x-3">
      <div className="flex items-center -space-x-2 shrink-0">
        <div className="p-0.5 rounded-full bg-white shadow-sm ring-1 ring-slate-200 z-10">
          <LogoYayasan className={logoSizes[size]} />
        </div>
        <div className="p-0.5 rounded-full bg-white shadow-sm ring-1 ring-slate-200">
          <LogoSDIAH className={logoSizes[size]} />
        </div>
      </div>
      {showFullText && (
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
              SDI Abu Hurairah <span className="text-emerald-700 font-bold">Lahat</span>
            </span>
          </div>
          <p className="text-[11px] text-slate-500 font-medium">
            Yayasan Al Afwa Wal Afiah • Sistem Perizinan Guru & Pegawai
          </p>
        </div>
      )}
    </div>
  );
};
