import React, { useState } from 'react';
import { 
  Play, 
  Copy, 
  Check, 
  FileCode, 
  Terminal, 
  Smartphone, 
  Send, 
  RefreshCw,
  Code2,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';

interface ApiEndpoint {
  id: string;
  name: string;
  method: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  path: string;
  description: string;
  defaultPayload?: any;
  defaultParams?: Record<string, string>;
  category: string;
}

const API_ENDPOINTS: ApiEndpoint[] = [
  {
    id: 'get_all_pengajuan',
    name: '1. Ambil Semua Pengajuan (Read All)',
    method: 'GET',
    path: '/api/pengajuan',
    description: 'Mengambil daftar permohonan izin dengan filter status, pencarian nomor/nama usaha, pagination, dan relasi tabel pengguna & jenis_perizinan.',
    category: 'pengajuan_izin',
    defaultParams: {
      search: '',
      status: 'SEMUA',
      page: '1',
      limit: '10'
    }
  },
  {
    id: 'get_single_pengajuan',
    name: '2. Ambil Detail Pengajuan (Read One)',
    method: 'GET',
    path: '/api/pengajuan/1',
    description: 'Mengambil informasi lengkap satu pengajuan izin beserta berkas dokumen dan seluruh riwayat kronologis status (log_status).',
    category: 'pengajuan_izin',
  },
  {
    id: 'post_create_pengajuan',
    name: '3. Buat Pengajuan Baru (Create)',
    method: 'POST',
    path: '/api/pengajuan',
    description: 'Mendaftarkan pengajuan izin baru dari pemohon. Otomatis men-generate nomor registrasi unik (REG-YYYYMM-XXXX) dan mencatat log status awal (DIAJUKAN).',
    category: 'pengajuan_izin',
    defaultPayload: {
      id_pengguna: 1,
      id_jenis: 1,
      data_pemohon: {
        nama_usaha: "Pembangunan Rumah Tingkat Baru",
        alamat_lokasi: "Jl. Diponegoro No. 100",
        kecamatan: "Coblong",
        kelurahan: "Dago",
        luas_tempat_m2: 250,
        koordinat_lat: -6.8901,
        koordinat_lng: 107.6150
      },
      dokumen_lampiran: [
        {
          id_dokumen: "doc_demo_1",
          nama_dokumen: "KTP_Pemohon.pdf",
          url: "https://example.com/ktp.pdf",
          tipe_file: "application/pdf",
          ukuran_kb: 480,
          uploaded_at: new Date().toISOString()
        },
        {
          id_dokumen: "doc_demo_2",
          nama_dokumen: "SHM_Tanah.pdf",
          url: "https://example.com/shm.pdf",
          tipe_file: "application/pdf",
          ukuran_kb: 1100,
          uploaded_at: new Date().toISOString()
        }
      ],
      catatan_pemohon: "Pengajuan izin mendirikan bangunan baru untuk tempat tinggal."
    }
  },
  {
    id: 'put_update_pengajuan',
    name: '4. Perbarui Data Formulir (Update)',
    method: 'PUT',
    path: '/api/pengajuan/1',
    description: 'Memperbarui rincian formulir data_pemohon, dokumen lampiran, atau penyesuaian biaya.',
    category: 'pengajuan_izin',
    defaultPayload: {
      data_pemohon: {
        nama_usaha: "Pembangunan Rumah Tinggal Tingkat 2 (Revisi)",
        alamat_lokasi: "Jl. Melati Indah No. 12 Blok C - Revisi Denah",
        luas_tempat_m2: 195
      }
    }
  },
  {
    id: 'patch_status_pengajuan',
    name: '5. Ubah Status & Workflow (Update Status)',
    method: 'PATCH',
    path: '/api/pengajuan/1/status',
    description: 'Memperbarui status proses perizinan oleh petugas (misal: VERIFIKASI_BERKAS, DISETUJUI, DITOLAK), menerbitkan nomor SK jika disetujui, dan otomatis mencatat ke log_status.',
    category: 'pengajuan_izin',
    defaultPayload: {
      status_baru: "DISETUJUI",
      id_petugas: 4,
      keterangan: "Seluruh berkas teknis arsitektur dan kepemilikan tanah telah diverifikasi valid.",
      nomor_surat_izin: "503/IMB-01/DPMPTSP/VIII/2026",
      masa_berlaku_tahun: 0
    }
  },
  {
    id: 'delete_pengajuan',
    name: '6. Hapus Pengajuan (Delete)',
    method: 'DELETE',
    path: '/api/pengajuan/3',
    description: 'Menghapus data permohonan izin dari database beserta seluruh riwayat relasi log_status secara cascade.',
    category: 'pengajuan_izin',
  },
  {
    id: 'get_master_jenis',
    name: '7. Master Jenis Perizinan (Katalog)',
    method: 'GET',
    path: '/api/jenis-perizinan',
    description: 'Mengambil daftar jenis izin aktif beserta syarat dokumen, retribusi, dan masa berlaku.',
    category: 'master',
  },
  {
    id: 'get_status_logs',
    name: '8. Riwayat Status Log Pengajuan (Audit)',
    method: 'GET',
    path: '/api/log-status/1',
    description: 'Mengambil log status kronologis untuk satu pengajuan izin.',
    category: 'audit',
  }
];

export const ApiPlayground: React.FC = () => {
  const [selectedEndpoint, setSelectedEndpoint] = useState<ApiEndpoint>(API_ENDPOINTS[0]);
  const [customPath, setCustomPath] = useState<string>(API_ENDPOINTS[0].path);
  const [requestBody, setRequestBody] = useState<string>(
    API_ENDPOINTS[0].defaultPayload ? JSON.stringify(API_ENDPOINTS[0].defaultPayload, null, 2) : ''
  );
  const [codeLanguage, setCodeLanguage] = useState<'nodejs' | 'kotlin' | 'curl'>('nodejs');

  // Response State
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [responseBody, setResponseBody] = useState<string | null>(null);
  const [responseHeaders, setResponseHeaders] = useState<Record<string, string> | null>(null);
  const [responseTime, setResponseTime] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  const handleSelectEndpoint = (ep: ApiEndpoint) => {
    setSelectedEndpoint(ep);
    setCustomPath(ep.path);
    setRequestBody(ep.defaultPayload ? JSON.stringify(ep.defaultPayload, null, 2) : '');
    setResponseBody(null);
    setResponseStatus(null);
  };

  const handleExecuteRequest = async () => {
    setIsLoading(true);
    const startTime = performance.now();

    try {
      const options: RequestInit = {
        method: selectedEndpoint.method,
        headers: {
          'Content-Type': 'application/json',
        },
      };

      if (['POST', 'PUT', 'PATCH'].includes(selectedEndpoint.method) && requestBody.trim()) {
        try {
          // Validate JSON syntax
          JSON.parse(requestBody);
          options.body = requestBody;
        } catch (e: any) {
          setIsLoading(false);
          setResponseStatus(400);
          setResponseBody(JSON.stringify({ error: 'Format JSON pada Request Body tidak valid: ' + e.message }, null, 2));
          return;
        }
      }

      const res = await fetch(customPath, options);
      const endTime = performance.now();
      setResponseTime(Math.round(endTime - startTime));
      setResponseStatus(res.status);

      const headersObj: Record<string, string> = {};
      res.headers.forEach((val, key) => {
        headersObj[key] = val;
      });
      setResponseHeaders(headersObj);

      const json = await res.json();
      setResponseBody(JSON.stringify(json, null, 2));
    } catch (err: any) {
      const endTime = performance.now();
      setResponseTime(Math.round(endTime - startTime));
      setResponseStatus(500);
      setResponseBody(JSON.stringify({ error: err.message || 'Request gagal dieksekusi' }, null, 2));
    } finally {
      setIsLoading(false);
    }
  };

  // Generate Code Snippets
  const generateSnippet = () => {
    const method = selectedEndpoint.method;
    const url = `http://localhost:3000${customPath}`;

    if (codeLanguage === 'nodejs') {
      if (['POST', 'PUT', 'PATCH'].includes(method)) {
        return `// Node.js (Axios / Express Client)
import axios from 'axios';

async function executeRequest() {
  const payload = ${requestBody || '{}'};

  try {
    const response = await axios.${method.toLowerCase()}('${url}', payload, {
      headers: { 'Content-Type': 'application/json' }
    });
    console.log('Status:', response.status);
    console.log('Response:', response.data);
  } catch (error) {
    console.error('API Error:', error.response?.data || error.message);
  }
}

executeRequest();`;
      } else if (method === 'DELETE') {
        return `// Node.js (Axios Delete)
import axios from 'axios';

async function deletePengajuan() {
  try {
    const response = await axios.delete('${url}');
    console.log('Deleted successfully:', response.data);
  } catch (error) {
    console.error('Delete Error:', error.response?.data || error.message);
  }
}

deletePengajuan();`;
      } else {
        return `// Node.js (Axios Get)
import axios from 'axios';

async function getPengajuan() {
  try {
    const response = await axios.get('${url}');
    console.log('Data:', response.data);
  } catch (error) {
    console.error('Fetch Error:', error.response?.data || error.message);
  }
}

getPengajuan();`;
      }
    }

    if (codeLanguage === 'kotlin') {
      if (method === 'POST' || method === 'PATCH' || method === 'PUT') {
        return `// Android Kotlin (Retrofit 2 / OkHttp)
package com.perizinan.app.api

import retrofit2.Response
import retrofit2.http.*

interface PerizinanApiService {
    @${method}("${customPath}")
    suspend fun sendRequest(
        @Body request: Map<String, Any>
    ): Response<ApiResponse<Any>>
}

// Implementasi Coroutine di Android ViewModel
class PerizinanViewModel(private val api: PerizinanApiService) : ViewModel() {
    fun submitPengajuan() {
        viewModelScope.launch {
            try {
                val response = api.sendRequest(payloadMap)
                if (response.isSuccessful) {
                    val result = response.body()
                    // Update Android UI State
                }
            } catch (e: Exception) {
                // Handle Network Error on Mobile
            }
        }
    }
}`;
      } else {
        return `// Android Kotlin (Retrofit 2 / OkHttp)
package com.perizinan.app.api

import retrofit2.Response
import retrofit2.http.*

interface PerizinanApiService {
    @${method}("${customPath}")
    suspend fun getPengajuanList(): Response<ApiResponse<List<PengajuanIzin>>>
}`;
      }
    }

    // cURL
    if (['POST', 'PUT', 'PATCH'].includes(method)) {
      const sanitizedBody = requestBody.replace(/\n/g, ' ').replace(/"/g, '\\"');
      return `curl -X ${method} "${url}" \\
  -H "Content-Type: application/json" \\
  -d "${sanitizedBody}"`;
    } else {
      return `curl -X ${method} "${url}" \\
  -H "Accept: application/json"`;
    }
  };

  const handleCopyCode = () => {
    navigator.clipboard.writeText(generateSnippet());
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-white p-5 sm:p-6 rounded-2xl border border-slate-200/90 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg font-bold text-slate-900 tracking-tight flex items-center">
              <span className="p-2 rounded-xl bg-blue-50 text-blue-700 border border-blue-200/60 mr-2.5">
                <Code2 className="w-5 h-5" />
              </span>
              <span>Dokumentasi & Live REST API Playground (Express Node.js)</span>
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1.5 leading-relaxed">
              Uji coba langsung seluruh endpoint CRUD perizinan dengan respon real-time dan generator kode untuk Web & Android.
            </p>
          </div>
          <div className="inline-flex items-center px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-semibold border border-emerald-200/80 shadow-2xs self-start sm:self-auto">
            <CheckCircle2 className="w-4 h-4 mr-1.5 text-emerald-600" />
            <span className="font-mono">Base URL: http://localhost:3000</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Sidebar: Endpoint List */}
        <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200/90 shadow-xs p-4 space-y-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider px-2 block mb-2">
            Pilih Endpoint CRUD API
          </span>
          <div className="space-y-1.5 max-h-[580px] overflow-y-auto pr-1">
            {API_ENDPOINTS.map((ep) => {
              const isSelected = selectedEndpoint.id === ep.id;
              const methodColors: Record<string, string> = {
                GET: 'bg-emerald-50 text-emerald-800 border-emerald-200/80',
                POST: 'bg-blue-50 text-blue-800 border-blue-200/80',
                PUT: 'bg-amber-50 text-amber-800 border-amber-200/80',
                PATCH: 'bg-purple-50 text-purple-800 border-purple-200/80',
                DELETE: 'bg-rose-50 text-rose-800 border-rose-200/80',
              };

              return (
                <div
                  key={ep.id}
                  onClick={() => handleSelectEndpoint(ep)}
                  className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-blue-50/70 border-blue-500/80 shadow-xs'
                      : 'bg-slate-50/50 border-slate-200/70 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <span className={`px-2 py-0.5 rounded-lg font-mono font-bold text-[10px] border ${methodColors[ep.method]}`}>
                      {ep.method}
                    </span>
                    <span className="font-bold text-slate-900 truncate">{ep.name}</span>
                  </div>
                  <div className="font-mono text-[11px] text-slate-500 mt-1 truncate">
                    {ep.path}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Content: Request & Response Playground */}
        <div className="lg:col-span-8 space-y-5">
          
          {/* Active Endpoint Info & Runner Bar */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 sm:p-6 space-y-4">
            <div>
              <div className="flex items-center space-x-2">
                <span className="px-2.5 py-1 rounded-lg font-mono font-bold text-xs bg-blue-600 text-white shadow-2xs">
                  {selectedEndpoint.method}
                </span>
                <h3 className="text-base font-bold text-slate-900 tracking-tight">{selectedEndpoint.name}</h3>
              </div>
              <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">{selectedEndpoint.description}</p>
            </div>

            {/* URL Input & Execute Button */}
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="flex-1 flex items-center bg-slate-50/80 border border-slate-200/90 rounded-xl px-3.5 py-2">
                <span className="font-mono text-xs text-slate-400 select-none mr-1">http://localhost:3000</span>
                <input
                  type="text"
                  value={customPath}
                  onChange={(e) => setCustomPath(e.target.value)}
                  className="flex-1 bg-transparent font-mono text-xs font-semibold text-slate-900 focus:outline-hidden"
                />
              </div>
              <button
                id="btn-execute-api"
                onClick={handleExecuteRequest}
                disabled={isLoading}
                className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs sm:text-sm font-semibold rounded-xl shadow-xs shadow-blue-500/20 transition-all flex items-center justify-center cursor-pointer disabled:opacity-50"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    <span>Mengirim...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4 mr-1.5" />
                    <span>Send Request</span>
                  </>
                )}
              </button>
            </div>

            {/* Request Body Editor (for POST / PUT / PATCH) */}
            {['POST', 'PUT', 'PATCH'].includes(selectedEndpoint.method) && (
              <div className="space-y-1.5 pt-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">Request Body (JSON Payload):</label>
                  <span className="text-[11px] text-slate-400 font-mono">application/json</span>
                </div>
                <textarea
                  rows={8}
                  value={requestBody}
                  onChange={(e) => setRequestBody(e.target.value)}
                  className="w-full p-3 font-mono text-xs bg-slate-950 text-emerald-400 rounded-xl border border-slate-800 focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
                />
              </div>
            )}
          </div>

          {/* Response Box */}
          <div className="bg-slate-950 rounded-2xl border border-slate-800 shadow-xl overflow-hidden text-slate-100">
            <div className="p-3.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-3 text-xs">
                <span className="font-bold text-slate-300">Live API Response</span>
                {responseStatus !== null && (
                  <span className={`px-2 py-0.5 rounded-full font-mono font-bold text-[11px] ${
                    responseStatus >= 200 && responseStatus < 300 
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                      : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  }`}>
                    Status: {responseStatus}
                  </span>
                )}
                {responseTime !== null && (
                  <span className="text-slate-400 text-[11px] font-mono">
                    Latency: {responseTime} ms
                  </span>
                )}
              </div>
            </div>

            <div className="p-4 max-h-72 overflow-y-auto font-mono text-xs">
              {isLoading ? (
                <div className="py-8 text-center text-slate-400 flex items-center justify-center space-x-2">
                  <div className="w-4 h-4 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin"></div>
                  <span>Menunggu respon dari Express backend...</span>
                </div>
              ) : responseBody ? (
                <pre className="text-emerald-300 whitespace-pre-wrap">{responseBody}</pre>
              ) : (
                <div className="py-8 text-center text-slate-500">
                  Klik tombol <strong>"Send Request"</strong> di atas untuk memanggil API Express secara langsung.
                </div>
              )}
            </div>
          </div>

          {/* Code Generator Snippets */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">Contoh Kode Integrasi Klien:</span>
              
              <div className="flex items-center space-x-1 bg-slate-100/90 p-1 rounded-xl border border-slate-200/80">
                <button
                  onClick={() => setCodeLanguage('nodejs')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    codeLanguage === 'nodejs' ? 'bg-white text-blue-700 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Node.js / Axios
                </button>
                <button
                  onClick={() => setCodeLanguage('kotlin')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    codeLanguage === 'kotlin' ? 'bg-white text-blue-700 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Android (Kotlin Retrofit)
                </button>
                <button
                  onClick={() => setCodeLanguage('curl')}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                    codeLanguage === 'curl' ? 'bg-white text-blue-700 shadow-xs font-bold' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  cURL CLI
                </button>
              </div>
            </div>

            <div className="relative">
              <button
                onClick={handleCopyCode}
                className="absolute right-3 top-3 px-2.5 py-1 bg-slate-800/90 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold flex items-center transition-colors cursor-pointer"
              >
                {copiedCode ? <Check className="w-3.5 h-3.5 mr-1 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 mr-1" />}
                <span>{copiedCode ? 'Tersalin' : 'Salin Kode'}</span>
              </button>
              <pre className="p-4 bg-slate-950 text-slate-200 rounded-xl font-mono text-xs overflow-x-auto border border-slate-900">
                {generateSnippet()}
              </pre>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
