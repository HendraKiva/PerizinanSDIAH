import React from 'react';
import { 
  Bell, 
  CheckCircle2, 
  XCircle, 
  Send, 
  User, 
  Calendar, 
  FileText, 
  Award, 
  X, 
  Clock, 
  MessageSquare,
  Sparkles,
  PhoneCall
} from 'lucide-react';
import { StatusPengajuan } from '../types/database';

export interface NotificationPayload {
  id: string;
  id_pengajuan: number;
  nomor_registrasi: string;
  nama_guru: string;
  nomor_wa_telepon?: string;
  jenis_izin: string;
  status_baru: StatusPengajuan;
  nomor_sk?: string;
  keterangan: string;
  otorisator_nama: string;
  otorisator_jabatan: string;
  tgl_mulai: string;
  tgl_selesai: string;
  durasi_hari: number;
  guru_inval?: string;
  timestamp: string;
}

interface NotificationModalProps {
  notification: NotificationPayload | null;
  onClose: () => void;
  onSendWhatsapp?: (notif: NotificationPayload) => void;
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  notification,
  onClose,
  onSendWhatsapp,
}) => {
  if (!notification) return null;

  const isApproved = notification.status_baru === 'DISETUJUI';
  const isRejected = notification.status_baru === 'DITOLAK';

  // Construct standard notification text message for Guru
  const generatedMessageTemplate = `*NOTIFIKASI PERIZINAN GURU & PEGAWAI SDI ABU HURAIRAH LAHAT*\n` +
    `---------------------------------------------------\n` +
    `Kepada Yth. *${notification.nama_guru}*\n\n` +
    `Pemberitahuan status permohonan izin Anda:\n` +
    `• *No. Registrasi*: ${notification.nomor_registrasi}\n` +
    `• *Kategori Izin*: ${notification.jenis_izin}\n` +
    `• *Rentang Tanggal*: ${notification.tgl_mulai} s.d. ${notification.tgl_selesai} (${notification.durasi_hari} Hari)\n` +
    (notification.guru_inval ? `• *Guru Inval*: ${notification.guru_inval}\n` : '') +
    `• *Status Terkini*: *${isApproved ? 'DISETUJUI / RESMI' : isRejected ? 'DITOLAK / PERBAIKAN' : notification.status_baru}*\n` +
    (notification.nomor_sk ? `• *Nomor SK Izin*: ${notification.nomor_sk}\n` : '') +
    `• *Otorisator*: ${notification.otorisator_nama} (${notification.otorisator_jabatan})\n` +
    `• *Catatan/Disposisi*: "${notification.keterangan}"\n\n` +
    (isApproved 
      ? `Alhamdulillah permohonan izin Anda telah disetujui secara resmi. Tugas mengajar telah dikoordinasikan.` 
      : `Mohon konfirmasi ke pihak Tata Usaha / Kurikulum bila membutuhkan penjelasan lebih lanjut.`) +
    `\n\n_Sistem Informasi Perizinan SDI Abu Hurairah Lahat - Yayasan Al Afwa Wal Afiah_`;

  const handleCopyMessage = () => {
    navigator.clipboard.writeText(generatedMessageTemplate);
    alert('Ringkasan notifikasi berhasil disalin ke clipboard!');
  };

  const handleOpenDirectWhatsApp = () => {
    const encodedText = encodeURIComponent(generatedMessageTemplate);
    const waUrl = notification.nomor_wa_telepon 
      ? `https://wa.me/${notification.nomor_wa_telepon.replace(/[^0-9]/g, '')}?text=${encodedText}`
      : `https://wa.me/?text=${encodedText}`;
    window.open(waUrl, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden my-6">
        
        {/* Header Notification Card */}
        <div className={`px-6 py-4.5 text-white flex items-center justify-between ${
          isApproved
            ? 'bg-linear-to-r from-emerald-800 to-teal-900'
            : isRejected
            ? 'bg-linear-to-r from-rose-800 to-slate-900'
            : 'bg-linear-to-r from-slate-800 to-slate-900'
        }`}>
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shadow-inner">
              <Bell className="w-5 h-5 text-amber-300 animate-bounce" />
            </div>
            <div>
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider bg-white/20 px-2 py-0.5 rounded-full">
                Notifikasi Pengiriman Status
              </span>
              <h3 className="text-base font-black tracking-tight text-white mt-0.5">
                Pemberitahuan Terkirim ke Guru
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-white/70 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4 text-xs text-slate-800">
          
          {/* Status Alert Banner */}
          <div className={`p-4 rounded-xl border flex items-start space-x-3 ${
            isApproved
              ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
              : isRejected
              ? 'bg-rose-50 border-rose-200 text-rose-900'
              : 'bg-amber-50 border-amber-200 text-amber-900'
          }`}>
            {isApproved ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            ) : isRejected ? (
              <XCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            ) : (
              <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            )}
            <div>
              <div className="font-black text-sm">
                Status Izin Telah Diperbarui: <span className="underline uppercase">{notification.status_baru}</span>
              </div>
              <p className="text-xs mt-0.5 opacity-90">
                Ringkasan keputusan berhasil dicatat ke sistem audit database dan siap disiarkan ke guru pemohon.
              </p>
            </div>
          </div>

          {/* Guru & Detail Ringkasan Data */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2.5">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <span className="text-[11px] font-bold text-slate-500 uppercase">Penerima Notifikasi:</span>
              <span className="text-xs font-black text-slate-900 flex items-center">
                <User className="w-3.5 h-3.5 mr-1 text-emerald-700" />
                {notification.nama_guru}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 block font-bold uppercase">No. Registrasi</span>
                <span className="font-mono font-bold text-emerald-900">{notification.nomor_registrasi}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block font-bold uppercase">Jenis Izin</span>
                <span className="font-bold text-slate-800">{notification.jenis_izin}</span>
              </div>
            </div>

            {notification.nomor_sk && (
              <div className="bg-emerald-100/60 p-2 rounded-lg border border-emerald-200 text-emerald-900">
                <span className="text-[10px] text-emerald-800 font-bold uppercase block">No. Surat Keputusan (SK):</span>
                <span className="font-mono font-black text-xs">{notification.nomor_sk}</span>
              </div>
            )}

            <div className="bg-white p-2.5 rounded-lg border border-slate-200 space-y-1">
              <span className="text-[10px] text-slate-400 font-bold uppercase block">Catatan Disposisi Otorisator:</span>
              <p className="text-xs font-medium text-slate-700 italic">
                "{notification.keterangan}"
              </p>
              <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-100 font-semibold flex items-center justify-between">
                <span>Oleh: {notification.otorisator_nama}</span>
                <span>{notification.timestamp}</span>
              </div>
            </div>
          </div>

          {/* Preview WhatsApp / SMS Broadcast */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-bold uppercase tracking-wider text-slate-700 flex items-center">
                <MessageSquare className="w-3.5 h-3.5 mr-1 text-emerald-600" />
                Teks Pesan Notifikasi (Siap Broadcast):
              </label>
              <button
                type="button"
                onClick={handleCopyMessage}
                className="text-[11px] text-emerald-700 hover:text-emerald-900 font-bold hover:underline cursor-pointer"
              >
                Salin Teks
              </button>
            </div>

            <div className="bg-slate-900 text-slate-100 p-3 rounded-xl font-mono text-[11px] max-h-36 overflow-y-auto whitespace-pre-wrap leading-relaxed border border-slate-800 select-all">
              {generatedMessageTemplate}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              Tutup
            </button>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={handleOpenDirectWhatsApp}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-all shadow-sm flex items-center space-x-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Kirim via WhatsApp</span>
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
