import React, { useState } from 'react';
import { 
  ShieldCheck, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Search, 
  Filter, 
  FileText, 
  User, 
  Users, 
  GraduationCap, 
  Calendar, 
  AlertCircle, 
  Eye, 
  Award, 
  Send, 
  CheckCheck, 
  X, 
  Sparkles,
  ArrowRight,
  Printer
} from 'lucide-react';
import { PengajuanIzin, JenisPerizinan, StatusPengajuan, UpdateStatusDTO } from '../types/database';
import { getStatusBadge } from './PengajuanList';
import { LogoSDIAH, LogoYayasan } from './Logos';
import { NotificationModal, NotificationPayload } from './NotificationModal';

export type OtorisatorRole = 'KEPALA_SEKOLAH' | 'ADMIN_YAYASAN' | 'KURIKULUM';

interface AdminDashboardProps {
  pengajuanList: PengajuanIzin[];
  jenisList: JenisPerizinan[];
  isLoading: boolean;
  onUpdateStatus: (id: number, payload: UpdateStatusDTO) => Promise<void>;
  onOpenDetailModal: (item: PengajuanIzin) => void;
  onOpenEditModal: (item: PengajuanIzin) => void;
  onRefresh: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  pengajuanList,
  jenisList,
  isLoading,
  onUpdateStatus,
  onOpenDetailModal,
  onOpenEditModal,
  onRefresh,
}) => {
  // Active Approver Account Persona
  const [activeRole, setActiveRole] = useState<OtorisatorRole>('KEPALA_SEKOLAH');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'SEMUA' | 'PENDING' | 'DISETUJUI' | 'DITOLAK'>('PENDING');
  const [selectedJenisId, setSelectedJenisId] = useState<string>('SEMUA');

  // Modal Action Decision State (Setujui / Tolak)
  const [actionModalItem, setActionModalItem] = useState<{
    item: PengajuanIzin;
    type: 'SETUJUI' | 'TOLAK';
  } | null>(null);

  const [decisionNotes, setDecisionNotes] = useState('');
  const [customSkNumber, setCustomSkNumber] = useState('');
  const [selectedPetugasId, setSelectedPetugasId] = useState<number>(1); // Hendra, S.Pd. (Kepala Sekolah)
  const [isProcessingDecision, setIsProcessingDecision] = useState(false);

  // Notification Modal State
  const [sentNotification, setSentNotification] = useState<NotificationPayload | null>(null);

  // Set default petugas ID when active role changes
  const getPetugasIdForRole = (role: OtorisatorRole) => {
    switch (role) {
      case 'KEPALA_SEKOLAH':
        return 1; // Hendra, S.Pd.
      case 'ADMIN_YAYASAN':
        return 38; // Pengurus Yayasan Al Afwa Wal Afiah
      case 'KURIKULUM':
        return 36; // Renny Melia Sari
      default:
        return 1;
    }
  };

  const getApproverTitle = (role: OtorisatorRole) => {
    switch (role) {
      case 'KEPALA_SEKOLAH':
        return {
          nama: 'Hendra, S.Pd.',
          jabatan: 'Kepala Sekolah SDI Abu Hurairah Lahat',
          badge: 'Otorisator Utama (Akun Kepala Sekolah)',
          wewenang: 'Wewenang Persetujuan Izin Harian, Sakit, & Dinas Mengajar Guru',
          avatar: 'H',
          color: 'emerald'
        };
      case 'ADMIN_YAYASAN':
        return {
          nama: 'Pengurus Yayasan Al Afwa Wal Afiah',
          jabatan: 'Admin & Pimpinan Lembaga Yayasan',
          badge: 'Otorisator Pembina (Akun Admin Yayasan)',
          wewenang: 'Wewenang Pengawasan, Cuti Panjang, Cuti Melahirkan, & Regulasi SDM',
          avatar: 'Y',
          color: 'amber'
        };
      case 'KURIKULUM':
        return {
          nama: 'Renny Melia Sari, Dipl, Phil, B.A.',
          jabatan: 'Koordinator Kurikulum & Inval',
          badge: 'Tim Verifikator Akademik',
          wewenang: 'Verifikasi Kesiapan Guru Inval & Modul Siswa',
          avatar: 'R',
          color: 'indigo'
        };
    }
  };

  const currentApprover = getApproverTitle(activeRole);

  // Quick Action Handler to open Modal
  const handleOpenActionModal = (item: PengajuanIzin, type: 'SETUJUI' | 'TOLAK') => {
    setActionModalItem({ item, type });
    const targetPetugasId = getPetugasIdForRole(activeRole);
    setSelectedPetugasId(targetPetugasId);

    if (type === 'SETUJUI') {
      const randomSuffix = String(item.id_pengajuan).padStart(3, '0');
      const skPrefix = activeRole === 'ADMIN_YAYASAN' ? 'SK-YAA' : 'SK-IZN/SDIAH';
      setCustomSkNumber(item.nomor_surat_izin || `${skPrefix}/VIII/2026/${randomSuffix}`);
      setDecisionNotes(
        activeRole === 'ADMIN_YAYASAN'
          ? 'Permohonan izin/cuti telah ditelaah dan disetujui oleh Pimpinan Yayasan Al Afwa Wal Afiah.'
          : 'Permohonan izin telah diperiksa dan disetujui Kepala Sekolah. Pelimpahan tugas mengajar ke Guru Inval disahkan.'
      );
    } else {
      setCustomSkNumber('');
      setDecisionNotes(
        activeRole === 'ADMIN_YAYASAN'
          ? 'Permohonan izin belum memenuhi ketentuan yayasan atau perlu penyesuaian jadwal lebih lanjut.'
          : 'Permohonan belum dapat disetujui karena berkas pendukung belum lengkap atau jadwal guru inval perlu disesuaikan.'
      );
    }
  };

  // Submit Approval or Rejection
  const handleSubmitDecision = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!actionModalItem) return;

    setIsProcessingDecision(true);
    const targetItem = actionModalItem.item;
    const finalNotes = decisionNotes || (actionModalItem.type === 'SETUJUI' ? `Izin disetujui oleh ${currentApprover.nama}` : 'Izin ditolak oleh pimpinan');
    const finalSk = actionModalItem.type === 'SETUJUI' ? (customSkNumber || undefined) : undefined;
    const nextStatus: StatusPengajuan = actionModalItem.type === 'SETUJUI' ? 'DISETUJUI' : 'DITOLAK';

    try {
      await onUpdateStatus(targetItem.id_pengajuan, {
        status_baru: nextStatus,
        id_petugas: selectedPetugasId,
        keterangan: finalNotes,
        nomor_surat_izin: finalSk,
      });

      // Prepare Notification Summary for the Guru
      const namaGuru = targetItem.data_pemohon?.nama_guru_pegawai || targetItem.pengguna?.nama_lengkap || 'Guru SDI Abu Hurairah';
      const jenisNama = targetItem.jenis_perizinan?.nama_izin || 'Permohonan Izin Guru';
      
      setSentNotification({
        id: `notif-${Date.now()}`,
        id_pengajuan: targetItem.id_pengajuan,
        nomor_registrasi: targetItem.nomor_registrasi,
        nama_guru: namaGuru,
        nomor_wa_telepon: targetItem.data_pemohon?.nomor_telepon || targetItem.pengguna?.no_telepon || '081234567890',
        jenis_izin: jenisNama,
        status_baru: nextStatus,
        nomor_sk: finalSk,
        keterangan: finalNotes,
        otorisator_nama: currentApprover.nama,
        otorisator_jabatan: currentApprover.jabatan,
        tgl_mulai: targetItem.data_pemohon?.tgl_mulai_izin || 'Hari ini',
        tgl_selesai: targetItem.data_pemohon?.tgl_selesai_izin || 'Hari ini',
        durasi_hari: targetItem.data_pemohon?.durasi_hari || 1,
        guru_inval: targetItem.data_pemohon?.guru_pengganti_inval,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      });

      setActionModalItem(null);
      setDecisionNotes('');
      setCustomSkNumber('');
      onRefresh();
    } catch (err) {
      console.error('Error submitting decision:', err);
    } finally {
      setIsProcessingDecision(false);
    }
  };

  // Quick Direct One-Click Approve (without typing notes if confident)
  const handleDirectQuickApprove = async (item: PengajuanIzin) => {
    const randomSuffix = String(item.id_pengajuan).padStart(3, '0');
    const autoSk = item.nomor_surat_izin || `SK-IZN/SDIAH-YAA/VIII/2026/${randomSuffix}`;
    const defaultNote = 'Persetujuan langsung (Quick Approval) oleh Kepala Sekolah SDI Abu Hurairah Lahat.';

    try {
      await onUpdateStatus(item.id_pengajuan, {
        status_baru: 'DISETUJUI',
        id_petugas: 1, // Hendra, S.Pd.
        keterangan: defaultNote,
        nomor_surat_izin: autoSk,
      });

      const namaGuru = item.data_pemohon?.nama_guru_pegawai || item.pengguna?.nama_lengkap || 'Guru SDI Abu Hurairah';
      const jenisNama = item.jenis_perizinan?.nama_izin || 'Permohonan Izin Guru';

      setSentNotification({
        id: `notif-${Date.now()}`,
        id_pengajuan: item.id_pengajuan,
        nomor_registrasi: item.nomor_registrasi,
        nama_guru: namaGuru,
        nomor_wa_telepon: item.data_pemohon?.nomor_telepon || item.pengguna?.no_telepon || '081234567890',
        jenis_izin: jenisNama,
        status_baru: 'DISETUJUI',
        nomor_sk: autoSk,
        keterangan: defaultNote,
        otorisator_nama: 'Hendra, S.Pd.',
        otorisator_jabatan: 'Kepala Sekolah SDI Abu Hurairah Lahat',
        tgl_mulai: item.data_pemohon?.tgl_mulai_izin || 'Hari ini',
        tgl_selesai: item.data_pemohon?.tgl_selesai_izin || 'Hari ini',
        durasi_hari: item.data_pemohon?.durasi_hari || 1,
        guru_inval: item.data_pemohon?.guru_pengganti_inval,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      });

      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  // Quick Direct One-Click Reject
  const handleDirectQuickReject = async (item: PengajuanIzin) => {
    const reason = window.prompt(
      `Masukkan alasan penolakan izin untuk ${item.data_pemohon?.nama_guru_pegawai || 'Guru'}:`,
      'Berkas pendukung belum lengkap / Tugas guru inval belum dikoordinasikan.'
    );
    if (reason === null) return; // User cancelled

    const note = reason || 'Permohonan izin ditolak oleh Kepala Sekolah.';
    try {
      await onUpdateStatus(item.id_pengajuan, {
        status_baru: 'DITOLAK',
        id_petugas: 1,
        keterangan: note,
      });

      const namaGuru = item.data_pemohon?.nama_guru_pegawai || item.pengguna?.nama_lengkap || 'Guru SDI Abu Hurairah';
      const jenisNama = item.jenis_perizinan?.nama_izin || 'Permohonan Izin Guru';

      setSentNotification({
        id: `notif-${Date.now()}`,
        id_pengajuan: item.id_pengajuan,
        nomor_registrasi: item.nomor_registrasi,
        nama_guru: namaGuru,
        nomor_wa_telepon: item.data_pemohon?.nomor_telepon || item.pengguna?.no_telepon || '081234567890',
        jenis_izin: jenisNama,
        status_baru: 'DITOLAK',
        keterangan: note,
        otorisator_nama: 'Hendra, S.Pd.',
        otorisator_jabatan: 'Kepala Sekolah SDI Abu Hurairah Lahat',
        tgl_mulai: item.data_pemohon?.tgl_mulai_izin || 'Hari ini',
        tgl_selesai: item.data_pemohon?.tgl_selesai_izin || 'Hari ini',
        durasi_hari: item.data_pemohon?.durasi_hari || 1,
        guru_inval: item.data_pemohon?.guru_pengganti_inval,
        timestamp: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      });

      onRefresh();
    } catch (err) {
      console.error(err);
    }
  };

  // Calculations for stats
  const totalAll = pengajuanList.length;
  const totalPending = pengajuanList.filter(
    (p) => p.status_pengajuan === 'DIAJUKAN' || p.status_pengajuan === 'VERIFIKASI_BERKAS' || p.status_pengajuan === 'SURVEI_LAPANGAN' || p.status_pengajuan === 'MENUNGGU_PEMBAYARAN'
  ).length;
  const totalApproved = pengajuanList.filter((p) => p.status_pengajuan === 'DISETUJUI').length;
  const totalRejected = pengajuanList.filter((p) => p.status_pengajuan === 'DITOLAK' || p.status_pengajuan === 'DICABUT').length;

  // Filtered List
  const filteredList = pengajuanList.filter((item) => {
    // Status Filter
    if (statusFilter === 'PENDING') {
      const isPending = item.status_pengajuan === 'DIAJUKAN' || item.status_pengajuan === 'VERIFIKASI_BERKAS' || item.status_pengajuan === 'SURVEI_LAPANGAN' || item.status_pengajuan === 'MENUNGGU_PEMBAYARAN';
      if (!isPending) return false;
    } else if (statusFilter === 'DISETUJUI') {
      if (item.status_pengajuan !== 'DISETUJUI') return false;
    } else if (statusFilter === 'DITOLAK') {
      if (item.status_pengajuan !== 'DITOLAK' && item.status_pengajuan !== 'DICABUT') return false;
    }

    // Jenis Izin Filter
    if (selectedJenisId !== 'SEMUA' && item.id_jenis.toString() !== selectedJenisId) {
      return false;
    }

    // Search Query
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const nama = (item.data_pemohon?.nama_guru_pegawai || item.pengguna?.nama_lengkap || '').toLowerCase();
      const nuptk = (item.data_pemohon?.nuptk_nip || item.pengguna?.nuptk_nip || '').toLowerCase();
      const noReg = (item.nomor_registrasi || '').toLowerCase();
      const noSk = (item.nomor_surat_izin || '').toLowerCase();
      const alasan = (item.data_pemohon?.alasan_izin || '').toLowerCase();
      const inval = (item.data_pemohon?.guru_pengganti_inval || '').toLowerCase();
      const jenisNama = (item.jenis_perizinan?.nama_izin || '').toLowerCase();

      return (
        nama.includes(q) ||
        nuptk.includes(q) ||
        noReg.includes(q) ||
        noSk.includes(q) ||
        alasan.includes(q) ||
        inval.includes(q) ||
        jenisNama.includes(q)
      );
    }

    return true;
  });

  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner: Admin Authority Bar & Persona Switcher */}
      <div className="bg-linear-to-r from-slate-900 via-emerald-950 to-slate-900 rounded-2xl p-5 sm:p-6 text-white shadow-xl border border-emerald-800/30 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center space-x-4">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-lg shrink-0 shadow-inner border ${
              activeRole === 'KEPALA_SEKOLAH' 
                ? 'bg-emerald-600/30 border-emerald-400/40 text-emerald-300'
                : activeRole === 'ADMIN_YAYASAN'
                ? 'bg-amber-600/30 border-amber-400/40 text-amber-300'
                : 'bg-indigo-600/30 border-indigo-400/40 text-indigo-300'
            }`}>
              {currentApprover.avatar}
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                  activeRole === 'KEPALA_SEKOLAH'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-400/30'
                    : activeRole === 'ADMIN_YAYASAN'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-400/30'
                    : 'bg-indigo-500/20 text-indigo-300 border-indigo-400/30'
                }`}>
                  {currentApprover.badge}
                </span>
                <span className="text-xs text-slate-400">• Otorisasi Perizinan Guru</span>
              </div>
              <h2 className="text-lg sm:text-xl font-black text-white tracking-tight mt-1">
                {currentApprover.nama}
              </h2>
              <p className="text-xs text-slate-300">
                {currentApprover.jabatan} — <span className="text-amber-300/90">{currentApprover.wewenang}</span>
              </p>
            </div>
          </div>

          {/* Persona Switcher Buttons */}
          <div className="bg-slate-800/90 backdrop-blur-xs p-1.5 rounded-xl border border-slate-700/80 flex flex-wrap sm:flex-nowrap items-center gap-1 shrink-0">
            <span className="text-[10px] font-bold uppercase text-slate-400 px-2 py-1 hidden sm:inline">
              Akun Aktif:
            </span>
            <button
              id="switch-to-kepsek"
              onClick={() => setActiveRole('KEPALA_SEKOLAH')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 ${
                activeRole === 'KEPALA_SEKOLAH'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Kepala Sekolah</span>
            </button>
            <button
              id="switch-to-yayasan"
              onClick={() => setActiveRole('ADMIN_YAYASAN')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 ${
                activeRole === 'ADMIN_YAYASAN'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              <span>Admin Yayasan</span>
            </button>
            <button
              id="switch-to-kurikulum"
              onClick={() => setActiveRole('KURIKULUM')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 ${
                activeRole === 'KURIKULUM'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700/60'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Kurikulum & TU</span>
            </button>
          </div>
        </div>

        {/* Workflow SOP Banner */}
        <div className="pt-3 border-t border-emerald-900/60 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-2 text-slate-300">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
            <span className="font-medium">
              <strong className="text-white">Alur SOP Persetujuan:</strong> Setiap izin yang diajukan guru berstatus <em>PENDING</em> dan langsung masuk antrean verifikasi akun <strong>Kepala Sekolah</strong> & <strong>Admin Yayasan</strong> sebelum diterbitkan SK Resmi.
            </span>
          </div>

          <div className="flex items-center space-x-3 bg-slate-950/40 px-3 py-1.5 rounded-lg border border-emerald-900/40 text-[11px] shrink-0">
            <span className="text-slate-400">Antrean Perlu Disetujui:</span>
            <span className="font-black text-amber-400">{totalPending} Izin Menunggu</span>
          </div>
        </div>
      </div>

      {/* KPI Cards: Filter Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Total Permohonan */}
        <button
          onClick={() => setStatusFilter('SEMUA')}
          className={`p-4 rounded-xl border text-left transition-all duration-150 cursor-pointer ${
            statusFilter === 'SEMUA'
              ? 'bg-white border-slate-900 shadow-md ring-2 ring-slate-900/10'
              : 'bg-white border-slate-200 hover:border-slate-300 shadow-2xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase tracking-wider text-slate-500">Semua Izin</span>
            <FileText className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900">{totalAll}</span>
            <span className="text-[10px] font-bold text-slate-400">Total Masuk</span>
          </div>
        </button>

        {/* Menunggu Keputusan (Pending) */}
        <button
          onClick={() => setStatusFilter('PENDING')}
          className={`p-4 rounded-xl border text-left transition-all duration-150 cursor-pointer relative overflow-hidden ${
            statusFilter === 'PENDING'
              ? 'bg-amber-50/50 border-amber-500 shadow-md ring-2 ring-amber-500/20'
              : 'bg-white border-slate-200 hover:border-amber-400 shadow-2xs'
          }`}
        >
          {totalPending > 0 && (
            <span className="absolute top-0 right-0 w-2.5 h-2.5 bg-amber-500 rounded-bl-lg animate-pulse" />
          )}
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase tracking-wider text-amber-700">Menunggu Tindakan</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-black text-amber-600">{totalPending}</span>
            <span className="text-[10px] font-bold bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded">
              Antrean
            </span>
          </div>
        </button>

        {/* Disetujui (Approved) */}
        <button
          onClick={() => setStatusFilter('DISETUJUI')}
          className={`p-4 rounded-xl border text-left transition-all duration-150 cursor-pointer ${
            statusFilter === 'DISETUJUI'
              ? 'bg-emerald-50/50 border-emerald-600 shadow-md ring-2 ring-emerald-600/20'
              : 'bg-white border-slate-200 hover:border-emerald-400 shadow-2xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase tracking-wider text-emerald-800">Disetujui Kepsek</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-black text-emerald-700">{totalApproved}</span>
            <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded">
              SK Terbit
            </span>
          </div>
        </button>

        {/* Ditolak (Rejected) */}
        <button
          onClick={() => setStatusFilter('DITOLAK')}
          className={`p-4 rounded-xl border text-left transition-all duration-150 cursor-pointer ${
            statusFilter === 'DITOLAK'
              ? 'bg-rose-50/50 border-rose-500 shadow-md ring-2 ring-rose-500/20'
              : 'bg-white border-slate-200 hover:border-rose-300 shadow-2xs'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase tracking-wider text-rose-700">Ditolak / Revisi</span>
            <XCircle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl font-black text-rose-600">{totalRejected}</span>
            <span className="text-[10px] font-bold bg-rose-100 text-rose-800 px-1.5 py-0.5 rounded">
              Ditolak
            </span>
          </div>
        </button>
      </div>

      {/* Main Table Container */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        
        {/* Search and Filters Toolbar */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-linear-to-b from-slate-50 to-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex-1 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 transform -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari guru, NUPTK, alasan, guru inval, atau no. registrasi..."
                className="w-full pl-10 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white text-slate-800 font-medium"
              />
            </div>

            {/* Kategori Filter */}
            <div className="w-full sm:w-56">
              <select
                value={selectedJenisId}
                onChange={(e) => setSelectedJenisId(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white text-slate-700 font-bold"
              >
                <option value="SEMUA">Semua Kategori Izin</option>
                {jenisList.map((j) => (
                  <option key={j.id_jenis} value={j.id_jenis.toString()}>
                    {j.kode_izin} - {j.nama_izin}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center space-x-2 shrink-0">
            <span className="text-xs font-bold text-slate-500">
              Menampilkan: <strong className="text-slate-900">{filteredList.length}</strong> data
            </span>
          </div>
        </div>

        {/* Table of Applications with Direct Approve / Reject Buttons */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/90 text-slate-600 text-[11px] font-black uppercase tracking-wider border-b border-slate-200">
                <th className="py-3.5 px-4">No. Registrasi</th>
                <th className="py-3.5 px-4">Dewan Guru / Pegawai</th>
                <th className="py-3.5 px-4">Kategori & Alasan Izin</th>
                <th className="py-3.5 px-4">Jadwal & Pelimpahan Inval</th>
                <th className="py-3.5 px-4">Status Terkini</th>
                <th className="py-3.5 px-4 text-center">Keputusan Admin (Aksi)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs text-slate-800">
              {isLoading ? (
                <tr>
                  <td colSpan={6} className="py-16 text-center text-slate-500">
                    <div className="inline-flex flex-col items-center justify-center space-y-2">
                      <div className="w-6 h-6 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin"></div>
                      <span className="text-xs font-semibold">Memuat data permohonan...</span>
                    </div>
                  </td>
                </tr>
              ) : filteredList.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-16 text-center">
                    <div className="max-w-xs mx-auto text-slate-400 flex flex-col items-center">
                      <FileText className="w-10 h-10 text-slate-300 mb-2" />
                      <p className="text-sm font-bold text-slate-700">Tidak ada data permohonan izin</p>
                      <p className="text-xs text-slate-400 mt-1">
                        {statusFilter === 'PENDING'
                          ? 'Bagus! Semua antrean izin permohonan telah diproses.'
                          : 'Coba ubah kata kunci pencarian atau filter status.'}
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredList.map((item) => {
                  const badge = getStatusBadge(item.status_pengajuan);
                  const BadgeIcon = badge.icon;
                  const namaGuru = item.data_pemohon?.nama_guru_pegawai || item.pengguna?.nama_lengkap || `Guru #${item.id_pengguna}`;
                  const nuptk = item.data_pemohon?.nuptk_nip || item.pengguna?.nuptk_nip || '-';
                  const jabatan = item.data_pemohon?.jabatan || item.pengguna?.jabatan || 'Guru / Pegawai';
                  const alasan = item.data_pemohon?.alasan_izin || item.data_pemohon?.nama_usaha || '-';
                  const tglMulai = item.data_pemohon?.tgl_mulai_izin || '-';
                  const tglSelesai = item.data_pemohon?.tgl_selesai_izin || '-';
                  const durasi = item.data_pemohon?.durasi_hari || 1;
                  const guruInval = item.data_pemohon?.guru_pengganti_inval;
                  const isAlreadyApproved = item.status_pengajuan === 'DISETUJUI';
                  const isAlreadyRejected = item.status_pengajuan === 'DITOLAK';

                  return (
                    <tr
                      key={item.id_pengajuan}
                      className={`hover:bg-slate-50/80 transition-colors ${
                        item.status_pengajuan === 'DIAJUKAN' ? 'bg-amber-50/20' : ''
                      }`}
                    >
                      {/* No Registrasi & SK */}
                      <td className="py-4 px-4 font-mono text-xs align-top">
                        <div className="font-bold text-emerald-900 tracking-tight">
                          {item.nomor_registrasi}
                        </div>
                        {item.nomor_surat_izin ? (
                          <div className="mt-1">
                            <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 font-sans font-bold block truncate max-w-[170px]">
                              SK: {item.nomor_surat_izin}
                            </span>
                          </div>
                        ) : (
                          <span className="text-[10px] text-slate-400 font-sans mt-0.5 block">
                            Menunggu SK
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400 font-sans mt-1 block">
                          Tgl: {formatDate(item.created_at)}
                        </span>
                      </td>

                      {/* Guru / Pegawai */}
                      <td className="py-4 px-4 align-top">
                        <div className="flex items-start space-x-2.5">
                          <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 font-black text-xs flex items-center justify-center shrink-0 border border-emerald-300">
                            {namaGuru.charAt(0)}
                          </div>
                          <div>
                            <div className="font-black text-slate-900 text-xs sm:text-sm">
                              {namaGuru}
                            </div>
                            <div className="text-xs text-slate-500">{jabatan}</div>
                            <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                              NUPTK: {nuptk}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Kategori Izin & Alasan */}
                      <td className="py-4 px-4 align-top max-w-[240px]">
                        <div className="font-bold text-xs text-emerald-950">
                          {item.jenis_perizinan?.nama_izin || `Izin #${item.id_jenis}`}
                        </div>
                        <p className="text-xs text-slate-600 mt-1 line-clamp-2 leading-relaxed bg-slate-50 p-2 rounded-lg border border-slate-100">
                          "{alasan}"
                        </p>
                        {item.dokumen_lampiran && item.dokumen_lampiran.length > 0 && (
                          <div className="mt-1 flex items-center space-x-1 text-[10px] text-emerald-700 font-semibold">
                            <FileText className="w-3 h-3" />
                            <span>{item.dokumen_lampiran.length} Berkas Terlampir</span>
                          </div>
                        )}
                      </td>

                      {/* Jadwal & Pelimpahan Inval */}
                      <td className="py-4 px-4 align-top">
                        <div className="text-xs font-semibold text-slate-900 flex items-center">
                          <Calendar className="w-3 h-3 mr-1 text-slate-400 shrink-0" />
                          <span>{tglMulai} s.d {tglSelesai}</span>
                        </div>
                        <div className="text-[11px] text-emerald-800 font-bold mt-0.5">
                          Durasi: <span className="bg-emerald-50 text-emerald-800 px-1.5 py-0.5 rounded border border-emerald-200">{durasi} Hari</span>
                        </div>
                        {guruInval ? (
                          <div className="text-[11px] text-slate-600 mt-1.5 flex items-center bg-amber-50/60 p-1.5 rounded-md border border-amber-200/60">
                            <Users className="w-3 h-3 mr-1 text-amber-700 shrink-0" />
                            <span className="truncate max-w-[140px]" title={`Guru Inval: ${guruInval}`}>
                              Inval: <strong>{guruInval}</strong>
                            </span>
                          </div>
                        ) : (
                          <div className="text-[10px] text-slate-400 mt-1">Inval: Belum ada</div>
                        )}
                      </td>

                      {/* Status Terkini */}
                      <td className="py-4 px-4 align-top">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold border ${badge.bg}`}>
                          <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${badge.dot}`}></span>
                          <BadgeIcon className="w-3 h-3 mr-1" />
                          <span>{badge.label}</span>
                        </span>
                        {item.catatan_petugas && (
                          <p className="text-[10px] text-slate-500 mt-1 line-clamp-2 max-w-[150px] italic">
                            Catatan: {item.catatan_petugas}
                          </p>
                        )}
                      </td>

                      {/* ACTION BUTTONS (SETUJUI & TOLAK) */}
                      <td className="py-4 px-4 align-top text-center whitespace-nowrap">
                        <div className="flex flex-col sm:flex-row items-center justify-center gap-1.5">
                          {/* TOMBOL SETUJUI (APPROVE) */}
                          <button
                            id={`btn-admin-approve-${item.id_pengajuan}`}
                            onClick={() => handleOpenActionModal(item, 'SETUJUI')}
                            title="Setujui Permohonan & Terbitkan SK Izin"
                            className={`px-3 py-1.5 text-xs font-bold rounded-xl flex items-center justify-center space-x-1 transition-all cursor-pointer shadow-xs ${
                              isAlreadyApproved
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300 opacity-90'
                                : 'bg-emerald-700 hover:bg-emerald-800 text-white shadow-emerald-700/20'
                            }`}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{isAlreadyApproved ? 'Disetujui ✓' : 'Setujui'}</span>
                          </button>

                          {/* TOMBOL TOLAK (REJECT) */}
                          <button
                            id={`btn-admin-reject-${item.id_pengajuan}`}
                            onClick={() => handleOpenActionModal(item, 'TOLAK')}
                            title="Tolak / Minta Revisi Izin"
                            className={`px-3 py-1.5 text-xs font-bold rounded-xl flex items-center justify-center space-x-1 transition-all cursor-pointer shadow-xs ${
                              isAlreadyRejected
                                ? 'bg-rose-100 text-rose-800 border border-rose-300 opacity-90'
                                : 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'
                            }`}
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>{isAlreadyRejected ? 'Ditolak ✗' : 'Tolak'}</span>
                          </button>

                          {/* TOMBOL DETAIL / SURAT */}
                          <button
                            id={`btn-admin-detail-${item.id_pengajuan}`}
                            onClick={() => onOpenDetailModal(item)}
                            title="Lihat Detail Lengkap & Surat Izin Resmi"
                            className="p-1.5 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-all cursor-pointer border border-slate-200"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Info */}
        <div className="p-3.5 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span className="font-semibold">
            Status Terverifikasi: <strong>{totalApproved}</strong> disetujui • <strong>{totalPending}</strong> dalam antrean • <strong>{totalRejected}</strong> ditolak
          </span>
          <span className="text-[11px] text-slate-400 font-mono">
            SDI Abu Hurairah Lahat • PostgreSQL System
          </span>
        </div>
      </div>

      {/* MODAL DIALOG KONFIRMASI: SETUJUI / TOLAK PERIZINAN */}
      {actionModalItem && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden my-8">
            
            {/* Header Dialog */}
            <div className={`px-6 py-4.5 text-white flex items-center justify-between ${
              actionModalItem.type === 'SETUJUI' 
                ? 'bg-linear-to-r from-emerald-800 to-teal-900' 
                : 'bg-linear-to-r from-rose-800 to-slate-900'
            }`}>
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center">
                  {actionModalItem.type === 'SETUJUI' ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-200" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-200" />
                  )}
                </div>
                <div>
                  <h3 className="text-base font-black tracking-tight text-white">
                    {actionModalItem.type === 'SETUJUI' ? 'Setujui Permohonan Izin' : 'Tolak Permohonan Izin'}
                  </h3>
                  <p className="text-xs text-emerald-100/80">
                    No. Registrasi: <span className="font-mono font-bold text-amber-300">{actionModalItem.item.nomor_registrasi}</span>
                  </p>
                </div>
              </div>

              <button
                onClick={() => setActionModalItem(null)}
                className="text-white/70 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Dialog Form */}
            <form onSubmit={handleSubmitDecision} className="p-6 space-y-4 text-xs text-slate-800">
              
              {/* Info Guru Pemohon Brief */}
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-500 font-bold uppercase">Nama Guru / Pemohon:</span>
                  <strong className="text-slate-900 text-xs font-black">
                    {actionModalItem.item.data_pemohon?.nama_guru_pegawai || actionModalItem.item.pengguna?.nama_lengkap}
                  </strong>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-500 font-bold uppercase">Jenis Izin:</span>
                  <span className="font-bold text-emerald-800">
                    {actionModalItem.item.jenis_perizinan?.nama_izin}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-slate-500 font-bold uppercase">Rentang Jadwal:</span>
                  <span className="text-slate-800">
                    {actionModalItem.item.data_pemohon?.tgl_mulai_izin} s.d. {actionModalItem.item.data_pemohon?.tgl_selesai_izin} ({actionModalItem.item.data_pemohon?.durasi_hari || 1} Hari)
                  </span>
                </div>
                {actionModalItem.item.data_pemohon?.guru_pengganti_inval && (
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] text-slate-500 font-bold uppercase">Guru Inval:</span>
                    <span className="text-slate-900 font-bold">
                      {actionModalItem.item.data_pemohon?.guru_pengganti_inval}
                    </span>
                  </div>
                )}
              </div>

              {/* Approval Specific: Nomor Surat Keputusan (SK) */}
              {actionModalItem.type === 'SETUJUI' && (
                <div className="space-y-1">
                  <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700">
                    Nomor Surat Keputusan (SK) Izin Resmi
                  </label>
                  <input
                    type="text"
                    value={customSkNumber}
                    onChange={(e) => setCustomSkNumber(e.target.value)}
                    placeholder="SK-IZN/SDIAH-YAA/VIII/2026/015"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold text-emerald-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                  <span className="text-[10px] text-slate-400">
                    *Nomor ini akan tercetak otomatis pada lembar SK Izin Resmi SDI Abu Hurairah Lahat.
                  </span>
                </div>
              )}

              {/* Penandatangan Selector */}
              <div className="space-y-1">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700">
                  Otorisator / Penandatangan
                </label>
                <select
                  value={selectedPetugasId}
                  onChange={(e) => setSelectedPetugasId(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-emerald-500"
                >
                  <option value={1}>HENDRA, S.Pd. (Kepala Sekolah SDI Abu Hurairah)</option>
                  <option value={36}>RENNY MELIA SARI, Dipl, Phil, B.A. (Koordinator Kurikulum)</option>
                  <option value={33}>MIKO RAHMAN, S.A.P. (Kepala Tata Usaha)</option>
                  <option value={38}>Pengurus Yayasan Al Afwa Wal Afiah</option>
                </select>
              </div>

              {/* Catatan Disposisi / Alasan */}
              <div className="space-y-1">
                <label className="block text-[11px] font-bold uppercase tracking-wider text-slate-700">
                  {actionModalItem.type === 'SETUJUI' ? 'Catatan Persetujuan / Disposisi' : 'Alasan Penolakan / Catatan Perbaikan'}
                </label>
                <textarea
                  rows={3}
                  value={decisionNotes}
                  onChange={(e) => setDecisionNotes(e.target.value)}
                  placeholder={
                    actionModalItem.type === 'SETUJUI'
                      ? 'Catatan instruksi atau pesan untuk guru inval dan pemohon...'
                      : 'Tuliskan alasan penolakan secara jelas agar guru dapat memperbaikinya...'
                  }
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-emerald-500 text-slate-800"
                  required={actionModalItem.type === 'TOLAK'}
                />
              </div>

              {/* Footer Modal Action Buttons */}
              <div className="pt-3 border-t border-slate-200 flex items-center justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setActionModalItem(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  Batal
                </button>

                <button
                  type="submit"
                  disabled={isProcessingDecision}
                  className={`px-5 py-2 text-xs font-bold rounded-xl text-white shadow-md transition-all flex items-center space-x-1.5 cursor-pointer disabled:opacity-50 ${
                    actionModalItem.type === 'SETUJUI'
                      ? 'bg-emerald-700 hover:bg-emerald-800 shadow-emerald-700/20'
                      : 'bg-rose-700 hover:bg-rose-800 shadow-rose-700/20'
                  }`}
                >
                  {isProcessingDecision ? (
                    <span>Menyimpan Keputusan...</span>
                  ) : actionModalItem.type === 'SETUJUI' ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Sahkan & Terbitkan SK Izin</span>
                    </>
                  ) : (
                    <>
                      <XCircle className="w-4 h-4" />
                      <span>Kirim Penolakan</span>
                    </>
                  )}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* Pop-up Modal Notifikasi Guru Terkirim */}
      {sentNotification && (
        <NotificationModal
          notification={sentNotification}
          onClose={() => setSentNotification(null)}
        />
      )}

    </div>
  );
};
