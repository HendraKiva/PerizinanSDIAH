import React, { useState, useEffect } from 'react';
import { X, Check, Upload, FileText, Trash2, Calendar, User, Users, GraduationCap, AlertCircle, Plus, BookOpen } from 'lucide-react';
import { PengajuanIzin, JenisPerizinan, Pengguna, CreatePengajuanDTO, UpdatePengajuanDTO, DokumenLampiran } from '../types/database';
import { DAFTAR_GURU_PEGAWAI } from '../data/schoolStaffData';
import { LogoSDIAH } from './Logos';

interface PengajuanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (payload: CreatePengajuanDTO | UpdatePengajuanDTO, isEdit: boolean, id?: number) => Promise<void>;
  jenisList: JenisPerizinan[];
  usersList: Pengguna[];
  editItem?: PengajuanIzin | null;
  initialGuruId?: number | null;
}

export const PengajuanModal: React.FC<PengajuanModalProps> = ({
  isOpen,
  onClose,
  onSave,
  jenisList,
  usersList,
  editItem,
  initialGuruId
}) => {
  const isEdit = !!editItem;

  // Form State
  const [selectedUserId, setSelectedUserId] = useState<number>(initialGuruId || 1);
  const [selectedJenisId, setSelectedJenisId] = useState<number>(1);
  
  // Data Pemohon (Guru/Pegawai)
  const [alasanIzin, setAlasanIzin] = useState('');
  const [mapelKelas, setMapelKelas] = useState('');
  const [tglMulai, setTglMulai] = useState('');
  const [tglSelesai, setTglSelesai] = useState('');
  const [guruInval, setGuruInval] = useState('');
  const [tugasInval, setTugasInval] = useState('');
  const [keteranganTambahan, setKeteranganTambahan] = useState('');
  const [catatanPemohon, setCatatanPemohon] = useState('');

  // Dokumen Lampiran
  const [dokumenList, setDokumenList] = useState<DokumenLampiran[]>([]);
  const [newDocName, setNewDocName] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const selectedUser = usersList.find((u) => u.id_pengguna === selectedUserId) || usersList[0];
  const currentJenis = jenisList.find((j) => j.id_jenis === selectedJenisId) || jenisList[0];

  // Helper date formatter today / tomorrow
  const getTodayISO = () => new Date().toISOString().split('T')[0];

  useEffect(() => {
    if (editItem) {
      setSelectedUserId(editItem.id_pengguna);
      setSelectedJenisId(editItem.id_jenis);
      setAlasanIzin(editItem.data_pemohon?.alasan_izin || editItem.data_pemohon?.nama_usaha || '');
      setMapelKelas(editItem.data_pemohon?.mata_pelajaran_kelas || '');
      setTglMulai(editItem.data_pemohon?.tgl_mulai_izin || getTodayISO());
      setTglSelesai(editItem.data_pemohon?.tgl_selesai_izin || getTodayISO());
      setGuruInval(editItem.data_pemohon?.guru_pengganti_inval || '');
      setTugasInval(editItem.data_pemohon?.tugas_inval_siswa || '');
      setKeteranganTambahan(editItem.data_pemohon?.keterangan_tambahan || '');
      setDokumenList(editItem.dokumen_lampiran || []);
      setCatatanPemohon('');
    } else {
      const defaultUser = initialGuruId ? initialGuruId : (usersList[0]?.id_pengguna || 1);
      setSelectedUserId(defaultUser);
      if (jenisList.length > 0) setSelectedJenisId(jenisList[0].id_jenis);
      setAlasanIzin('');
      setMapelKelas('Tematik & PAI Kelas SD');
      setTglMulai(getTodayISO());
      setTglSelesai(getTodayISO());
      setGuruInval(DAFTAR_GURU_PEGAWAI[1]?.nama || 'WIWIN WINDRIANI');
      setTugasInval('Mengerjakan latihan modul tematik & membaca senyap di bawah pantauan Guru Piket.');
      setKeteranganTambahan('');
      setCatatanPemohon('');
      
      // Default sample documents based on permit requirements
      if (jenisList.length > 0) {
        const reqs = jenisList[0].persyaratan || [];
        setDokumenList(
          reqs.slice(0, 2).map((req, idx) => ({
            id_dokumen: `doc_${Date.now()}_${idx}`,
            nama_dokumen: `${req.replace(/[/\\?%*:|"<>]/g, '_')}.pdf`,
            url: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=600&auto=format&fit=crop&q=60',
            tipe_file: 'application/pdf',
            ukuran_kb: 420 + idx * 150,
            uploaded_at: new Date().toISOString(),
          }))
        );
      }
    }
    setErrorMsg('');
  }, [editItem, isOpen, initialGuruId]);

  const handleJenisChange = (newJenisId: number) => {
    setSelectedJenisId(newJenisId);
    if (!isEdit) {
      const selected = jenisList.find((j) => j.id_jenis === newJenisId);
      if (selected && selected.persyaratan) {
        setDokumenList(
          selected.persyaratan.slice(0, 2).map((req, idx) => ({
            id_dokumen: `doc_${Date.now()}_${idx}`,
            nama_dokumen: `${req.replace(/[/\\?%*:|"<>]/g, '_')}.pdf`,
            url: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=60',
            tipe_file: 'application/pdf',
            ukuran_kb: 380 + idx * 190,
            uploaded_at: new Date().toISOString(),
          }))
        );
      }
    }
  };

  const handleAddDocument = () => {
    if (!newDocName.trim()) return;
    const doc: DokumenLampiran = {
      id_dokumen: `doc_${Date.now()}`,
      nama_dokumen: newDocName.trim().endsWith('.pdf') ? newDocName.trim() : `${newDocName.trim()}.pdf`,
      url: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=600&auto=format&fit=crop&q=60',
      tipe_file: 'application/pdf',
      ukuran_kb: Math.floor(250 + Math.random() * 500),
      uploaded_at: new Date().toISOString(),
    };
    setDokumenList([...dokumenList, doc]);
    setNewDocName('');
  };

  const handleRemoveDoc = (id: string) => {
    setDokumenList(dokumenList.filter((d) => d.id_dokumen !== id));
  };

  // Calculate duration in days
  const calculateDays = () => {
    if (!tglMulai || !tglSelesai) return 1;
    const start = new Date(tglMulai).getTime();
    const end = new Date(tglSelesai).getTime();
    if (isNaN(start) || isNaN(end) || end < start) return 1;
    const diff = Math.round((end - start) / (1000 * 60 * 60 * 24)) + 1;
    return diff;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!alasanIzin.trim()) {
      setErrorMsg('Alasan permohonan izin wajib diisi dengan jelas');
      return;
    }
    if (!tglMulai || !tglSelesai) {
      setErrorMsg('Tanggal mulai dan selesai izin wajib dipilih');
      return;
    }

    setIsSubmitting(true);
    try {
      const durasiHari = calculateDays();
      const dataPemohonObj = {
        nama_guru_pegawai: selectedUser?.nama_lengkap || 'Guru / Pegawai',
        jabatan: selectedUser?.jabatan || 'Guru',
        nuptk_nip: selectedUser?.nuptk_nip || selectedUser?.nik || '',
        mata_pelajaran_kelas: mapelKelas.trim(),
        alasan_izin: alasanIzin.trim(),
        tgl_mulai_izin: tglMulai,
        tgl_selesai_izin: tglSelesai,
        durasi_hari: durasiHari,
        guru_pengganti_inval: guruInval.trim(),
        tugas_inval_siswa: tugasInval.trim(),
        keterangan_tambahan: keteranganTambahan.trim(),
      };

      if (isEdit && editItem) {
        const payload: UpdatePengajuanDTO = {
          data_pemohon: dataPemohonObj,
          dokumen_lampiran: dokumenList,
        };
        await onSave(payload, true, editItem.id_pengajuan);
      } else {
        const payload: CreatePengajuanDTO = {
          id_pengguna: Number(selectedUserId),
          id_jenis: Number(selectedJenisId),
          data_pemohon: dataPemohonObj,
          dokumen_lampiran: dokumenList,
          catatan_pemohon: catatanPemohon.trim() || `Pengajuan izin ${currentJenis?.nama_izin} baru oleh ${selectedUser?.nama_lengkap}.`,
        };
        await onSave(payload, false);
      }
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Terjadi kesalahan saat menyimpan pengajuan izin');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-3xl overflow-hidden my-8 transform transition-all flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-linear-to-r from-emerald-800 to-teal-900 px-6 py-4.5 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-white p-1 shadow-md shrink-0">
              <LogoSDIAH className="w-full h-full" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-black tracking-tight leading-snug">
                {isEdit ? 'Edit Formulir Permohonan Izin' : 'Formulir Permohonan Izin Guru & Pegawai'}
              </h3>
              <p className="text-xs text-emerald-200">
                SDI Abu Hurairah Lahat • Yayasan Al Afwa Wal Afiah
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-emerald-200 hover:text-white p-1.5 rounded-lg hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body / Scrollable Form */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-6 space-y-6 flex-1 text-slate-800 text-xs sm:text-sm">
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl text-xs flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Section 1: Pemohon (Guru / Pegawai) */}
          <div className="bg-emerald-50/50 p-4 rounded-xl border border-emerald-200/80 space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-emerald-900 flex items-center">
              <User className="w-4 h-4 mr-1.5 text-emerald-700" />
              1. Pilih Dewan Guru / Pegawai Pemohon (37 Personil)
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Nama Guru / Pegawai <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedUserId}
                  onChange={(e) => setSelectedUserId(Number(e.target.value))}
                  disabled={isEdit}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none disabled:bg-slate-100"
                >
                  {DAFTAR_GURU_PEGAWAI.map((guru) => (
                    <option key={guru.id} value={guru.id}>
                      #{guru.id.toString().padStart(2, '0')} - {guru.nama} ({guru.kategori})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Jabatan & NUPTK
                </label>
                <div className="px-3 py-2 bg-white border border-slate-200 rounded-lg text-xs text-slate-600">
                  <div className="font-semibold text-slate-900">{selectedUser?.jabatan || 'Guru / Pegawai'}</div>
                  <div className="text-[11px] text-slate-400 font-mono">NUPTK: {selectedUser?.nuptk_nip || selectedUser?.nik}</div>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Kategori Izin & Detail */}
          <div className="space-y-4">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center border-b border-slate-200 pb-2">
              <FileText className="w-4 h-4 mr-1.5 text-emerald-700" />
              2. Kategori & Waktu Izin
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Jenis Izin Sekolah <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedJenisId}
                  onChange={(e) => handleJenisChange(Number(e.target.value))}
                  disabled={isEdit}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:bg-white focus:outline-none"
                >
                  {jenisList.map((j) => (
                    <option key={j.id_jenis} value={j.id_jenis}>
                      [{j.kode_izin}] {j.nama_izin}
                    </option>
                  ))}
                </select>
                {currentJenis && (
                  <p className="text-[11px] text-slate-500 mt-1 italic leading-tight">
                    {currentJenis.deskripsi}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Mata Pelajaran & Kelas Mengajar
                </label>
                <input
                  type="text"
                  value={mapelKelas}
                  onChange={(e) => setMapelKelas(e.target.value)}
                  placeholder="Contoh: Tematik Kelas 3B, PAI, atau Piket Pagi"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:bg-white focus:outline-none font-medium"
                />
              </div>
            </div>

            {/* Tanggal & Durasi */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center">
                  <Calendar className="w-3.5 h-3.5 mr-1 text-emerald-600" />
                  Tanggal Mulai <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  value={tglMulai}
                  onChange={(e) => setTglMulai(e.target.value)}
                  className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center">
                  <Calendar className="w-3.5 h-3.5 mr-1 text-emerald-600" />
                  Tanggal Selesai <span className="text-rose-500">*</span>
                </label>
                <input
                  type="date"
                  value={tglSelesai}
                  onChange={(e) => setTglSelesai(e.target.value)}
                  className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Total Durasi
                </label>
                <div className="px-3 py-1.5 bg-emerald-100/70 border border-emerald-300 rounded-lg text-xs font-black text-emerald-900 text-center">
                  {calculateDays()} Hari Kerja
                </div>
              </div>
            </div>

            {/* Alasan Izin */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Alasan / Keperluan Izin <span className="text-rose-500">*</span>
              </label>
              <textarea
                rows={2}
                value={alasanIzin}
                onChange={(e) => setAlasanIzin(e.target.value)}
                placeholder="Jelaskan alasan permohonan izin (misal: sakit demam tinggi, penugasan Bimtek Kurikulum Merdeka Diknas Lahat, keperluan keluarga)..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:bg-white focus:outline-none"
              />
            </div>
          </div>

          {/* Section 3: Pelimpahan Tugas & Guru Inval */}
          <div className="space-y-3 bg-amber-50/40 p-4 rounded-xl border border-amber-200/80">
            <h4 className="text-xs font-black uppercase tracking-wider text-amber-900 flex items-center">
              <Users className="w-4 h-4 mr-1.5 text-amber-700" />
              3. Pelimpahan Tugas & Guru Pengganti (Inval)
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Guru Pengganti (Inval)
                </label>
                <select
                  value={guruInval}
                  onChange={(e) => setGuruInval(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                >
                  <option value="">-- Pilih Guru Inval --</option>
                  {DAFTAR_GURU_PEGAWAI.filter(g => g.id !== selectedUserId).map((guru) => (
                    <option key={guru.id} value={guru.nama}>
                      {guru.nama} - {guru.jabatan}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center">
                  <BookOpen className="w-3.5 h-3.5 mr-1 text-amber-600" />
                  Rencana Modul / Tugas Siswa
                </label>
                <input
                  type="text"
                  value={tugasInval}
                  onChange={(e) => setTugasInval(e.target.value)}
                  placeholder="Contoh: Mengerjakan LKS hal 45, hafalan Juz 30..."
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Dokumen Lampiran */}
          <div className="space-y-3">
            <h4 className="text-xs font-black uppercase tracking-wider text-slate-700 flex items-center border-b border-slate-200 pb-2">
              <Upload className="w-4 h-4 mr-1.5 text-emerald-700" />
              4. Berkas Lampiran (Surat Dokter, Undangan Diknas, dll)
            </h4>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Nama file lampiran (contoh: Surat_Dokter_RSUD.pdf)"
                value={newDocName}
                onChange={(e) => setNewDocName(e.target.value)}
                className="flex-1 px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:bg-white"
              />
              <button
                type="button"
                onClick={handleAddDocument}
                className="px-3 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-lg text-xs font-bold flex items-center cursor-pointer shadow-xs"
              >
                <Plus className="w-3.5 h-3.5 mr-1" />
                Tambah
              </button>
            </div>

            <div className="space-y-2">
              {dokumenList.map((doc) => (
                <div
                  key={doc.id_dokumen}
                  className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                >
                  <div className="flex items-center space-x-2 truncate">
                    <FileText className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="font-semibold text-slate-800 truncate">{doc.nama_dokumen}</span>
                    <span className="text-[10px] text-slate-400 font-mono shrink-0">({doc.ukuran_kb} KB)</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveDoc(doc.id_dokumen)}
                    className="text-rose-500 hover:text-rose-700 p-1 rounded hover:bg-rose-50 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* SOP Routing Banner */}
          <div className="bg-amber-50/80 p-3.5 rounded-xl border border-amber-200 text-xs text-amber-950 flex items-start space-x-2.5">
            <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <strong className="block text-[11px] uppercase tracking-wider text-amber-900 font-black">
                Alur Otorisasi Pimpinan:
              </strong>
              <p className="text-[11px] text-amber-800 leading-relaxed">
                Permohonan izin yang diajukan akan otomatis masuk ke antrean akun <strong>Kepala Sekolah Hendra, S.Pd.</strong> atau <strong>Admin Yayasan</strong> untuk diperiksa dan disetujui sebelum Surat Keputusan (SK) resmi diterbitkan.
              </p>
            </div>
          </div>
        </form>

        {/* Modal Footer */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex items-center justify-between shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-900 bg-white border border-slate-300 rounded-xl hover:bg-slate-100 transition-all cursor-pointer"
          >
            Batal
          </button>
          
          <button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="px-5 py-2 text-xs font-bold text-white bg-emerald-700 hover:bg-emerald-800 rounded-xl shadow-md shadow-emerald-700/20 transition-all flex items-center space-x-1.5 cursor-pointer disabled:opacity-50"
          >
            {isSubmitting ? (
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <Check className="w-4 h-4 mr-1" />
            )}
            <span>{isEdit ? 'Simpan Perubahan' : 'Kirim Permohonan Izin'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
