import React from 'react';
import { Database, FileText, Smartphone, FileCode2, RefreshCw, Users, ShieldCheck } from 'lucide-react';
import { LogoSDIAH, LogoYayasan } from './Logos';

export type ActiveTabType = 'admin' | 'crud' | 'guru' | 'schema' | 'api' | 'android';

interface HeaderProps {
  activeTab: ActiveTabType;
  setActiveTab: (tab: ActiveTabType) => void;
  onResetData: () => void;
  isResetting: boolean;
  pendingCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onResetData,
  isResetting,
  pendingCount = 0
}) => {
  return (
    <header className="border-b border-slate-200 bg-white sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 sm:h-[4.75rem]">
          {/* Official Dual Logos & School Brand */}
          <div className="flex items-center space-x-3 sm:space-x-3.5">
            <div className="flex items-center -space-x-2 shrink-0">
              {/* Logo Yayasan Al Afwa Wal Afiah */}
              <div 
                className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-white p-0.5 shadow-md ring-2 ring-emerald-600/30 flex items-center justify-center z-10 transition-transform hover:scale-105"
                title="Yayasan Al Afwa Wal Afiah Kabupaten Lahat"
              >
                <LogoYayasan className="w-full h-full" />
              </div>
              {/* Logo SDI Abu Hurairah Lahat */}
              <div 
                className="w-11 h-11 sm:w-12 sm:h-12 rounded-full bg-white p-0.5 shadow-md ring-2 ring-amber-500/30 flex items-center justify-center transition-transform hover:scale-105"
                title="Sekolah Dasar Islam (SDI) Abu Hurairah Lahat"
              >
                <LogoSDIAH className="w-full h-full" />
              </div>
            </div>

            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-none">
                  SDI Abu Hurairah <span className="text-emerald-700">Lahat</span>
                </h1>
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1.5 animate-pulse"></span>
                  Sistem Perizinan
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-500 font-medium leading-tight mt-1">
                Yayasan Al Afwa Wal Afiah • 37 Dewan Guru & Pegawai
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="hidden md:flex items-center space-x-1 bg-slate-100 p-1 rounded-xl border border-slate-200">
            {/* Dasbor Admin (Persetujuan / Tolak) */}
            <button
              id="nav-admin-tab"
              onClick={() => setActiveTab('admin')}
              className={`inline-flex items-center px-3 py-1.5 text-xs font-bold rounded-lg transition-all duration-150 cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 mr-1.5 text-amber-300" />
              <span>Dasbor Admin</span>
              {pendingCount > 0 && (
                <span className={`ml-1.5 px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                  activeTab === 'admin' ? 'bg-amber-400 text-slate-950' : 'bg-amber-500 text-white'
                }`}>
                  {pendingCount}
                </span>
              )}
            </button>

            <button
              id="nav-crud-tab"
              onClick={() => setActiveTab('crud')}
              className={`inline-flex items-center px-3 py-1.5 text-xs font-bold rounded-lg transition-all duration-150 cursor-pointer ${
                activeTab === 'crud'
                  ? 'bg-white text-emerald-800 shadow-xs ring-1 ring-slate-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <FileText className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
              <span>Daftar Izin</span>
            </button>

            <button
              id="nav-guru-tab"
              onClick={() => setActiveTab('guru')}
              className={`inline-flex items-center px-3 py-1.5 text-xs font-bold rounded-lg transition-all duration-150 cursor-pointer ${
                activeTab === 'guru'
                  ? 'bg-white text-emerald-800 shadow-xs ring-1 ring-slate-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <Users className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
              <span>37 Guru & Pegawai</span>
            </button>

            <button
              id="nav-schema-tab"
              onClick={() => setActiveTab('schema')}
              className={`inline-flex items-center px-3 py-1.5 text-xs font-bold rounded-lg transition-all duration-150 cursor-pointer ${
                activeTab === 'schema'
                  ? 'bg-white text-emerald-800 shadow-xs ring-1 ring-slate-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <Database className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
              <span>Skema PostgreSQL</span>
            </button>

            <button
              id="nav-api-tab"
              onClick={() => setActiveTab('api')}
              className={`inline-flex items-center px-3 py-1.5 text-xs font-bold rounded-lg transition-all duration-150 cursor-pointer ${
                activeTab === 'api'
                  ? 'bg-white text-emerald-800 shadow-xs ring-1 ring-slate-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <FileCode2 className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
              <span>REST API</span>
            </button>

            <button
              id="nav-android-tab"
              onClick={() => setActiveTab('android')}
              className={`inline-flex items-center px-3 py-1.5 text-xs font-bold rounded-lg transition-all duration-150 cursor-pointer ${
                activeTab === 'android'
                  ? 'bg-white text-emerald-800 shadow-xs ring-1 ring-slate-200'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 mr-1.5 text-emerald-600" />
              <span>Aplikasi Android</span>
            </button>
          </div>

          {/* Right Action / Reset */}
          <div className="flex items-center space-x-2">
            <button
              id="btn-reset-db-data"
              onClick={onResetData}
              disabled={isResetting}
              title="Reset ke Data Standar SDI Abu Hurairah Lahat"
              className="inline-flex items-center px-3 py-2 text-xs font-bold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-200 rounded-lg transition-all cursor-pointer disabled:opacity-60 shadow-2xs"
            >
              <RefreshCw className={`w-3.5 h-3.5 mr-1.5 text-slate-500 ${isResetting ? 'animate-spin text-emerald-600' : ''}`} />
              <span className="hidden sm:inline">Reset Sample Data</span>
            </button>
          </div>
        </div>

        {/* Mobile Sub-Navigation Bar */}
        <div className="flex md:hidden items-center justify-between pb-2.5 overflow-x-auto space-x-1.5">
          <button
            onClick={() => setActiveTab('admin')}
            className={`px-2.5 py-1 text-xs font-bold rounded-md shrink-0 flex items-center space-x-1 ${
              activeTab === 'admin' ? 'bg-emerald-800 text-white' : 'bg-slate-100 text-slate-700'
            }`}
          >
            <span>Admin</span>
            {pendingCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black inline-flex items-center justify-center">
                {pendingCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('crud')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md shrink-0 ${activeTab === 'crud' ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}
          >
            Izin Guru
          </button>
          <button
            onClick={() => setActiveTab('guru')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md shrink-0 ${activeTab === 'guru' ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}
          >
            37 Guru/Staf
          </button>
          <button
            onClick={() => setActiveTab('schema')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md shrink-0 ${activeTab === 'schema' ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}
          >
            PostgreSQL
          </button>
          <button
            onClick={() => setActiveTab('api')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md shrink-0 ${activeTab === 'api' ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}
          >
            REST API
          </button>
          <button
            onClick={() => setActiveTab('android')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md shrink-0 ${activeTab === 'android' ? 'bg-emerald-700 text-white' : 'bg-slate-100 text-slate-700'}`}
          >
            Android
          </button>
        </div>
      </div>
    </header>
  );
};
