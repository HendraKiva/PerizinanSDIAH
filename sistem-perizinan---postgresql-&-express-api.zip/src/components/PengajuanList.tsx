import React from 'react';
import { 
  Plus, 
  Search, 
  Eye, 
  Edit3, 
  Trash2, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Calendar,
  User,
  Users,
  GraduationCap,
  Sparkles,
  ArrowRight,
  XCircle,
  ShieldCheck
} from 'lucide-react';
import { PengajuanIzin, JenisPerizinan, StatusPengajuan } from '../types/database';

interface PengajuanListProps {
  items: PengajuanIzin[];
  jenisList: JenisPerizinan[];
  selectedStatus: string;
  selectedJenis: string;
  searchQuery: string;
  isLoading: boolean;
  onSearchChange: (q: string) => void;
  onStatusChange: (status: string) => void;
  onJenisChange: (jenisId: string) => void;
  onOpenCreateModal: () => void;
  onOpenDetailModal: (item: PengajuanIzin) => void;
  onOpenEditModal: (item: PengajuanIzin) => void;
  onDelete: (item: PengajuanIzin) => void;
  onQuickApprove?: (item: PengajuanIzin) => void;
  onQuickReject?: (item: PengajuanIzin) => void;
}

export const getStatusBadge = (status: StatusPengajuan | string) => {
  switch (status) {
    case 'DIAJUKAN':
      return {
        label: 'Diajukan',
        sublabel: 'Menunggu Verifikasi TU/Kurikulum',
        bg: 'bg-amber-50 text-amber-800 border-amber-200',
        dot: 'bg-amber-500',
        icon: Clock,
      };
    case 'VERIFIKASI_BERKAS':
      return {
        label: 'Verifikasi Berkas',
        sublabel: 'Pemeriksaan Tugas Inval & Surat',
        bg: 'bg-blue-50 text-blue-800 border-blue-200',
        dot: 'bg-blue-500',
        icon: FileText,
      };
    case 'SURVEI_LAPANGAN':
      return {
        label: 'Koordinasi Piket',
        sublabel: 'Penyusunan Jadwal Pengganti',
        bg: 'bg-purple-50 text-purple-800 border-purple-200',
        dot: 'bg-purple-500',
        icon: Users,
      };
    case 'MENUNGGU_PEMBAYARAN':
      return {
        label: 'Menunggu Disposisi',
        sublabel: 'Disposisi Waka / Ka. TU',
        bg: 'bg-orange-50 text-orange-800 border-orange-200',
        dot: 'bg-orange-500',
        icon: AlertCircle,
      };
    case 'DISETUJUI':
      return {
        label: 'Disetujui Kepsek',
        sublabel: 'SK Izin Resmi Diterbitkan',
        bg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
        dot: 'bg-emerald-500',
        icon: CheckCircle2,
      };
    case 'DITOLAK':
      return {
        label: 'Ditolak / Ditinjau',
        sublabel: 'Alasan Tidak Memenuhi Syarat',
        bg: 'bg-rose-50 text-rose-800 border-rose-200',
        dot: 'bg-rose-500',
        icon: AlertCircle,
      };
    case 'DICABUT':
      return {
        label: 'Dibatalkan',
        sublabel: 'Dibatalkan Guru/Pegawai',
        bg: 'bg-slate-100 text-slate-700 border-slate-300',
        dot: 'bg-slate-500',
        icon: AlertCircle,
      };
    case 'DRAFT':
    default:
      return {
        label: 'Draft',
        sublabel: 'Konsep Pengajuan',
        bg: 'bg-slate-100 text-slate-700 border-slate-200',
        dot: 'bg-slate-400',
        icon: Clock,
      };
  }
};

export const PengajuanList: React.FC<PengajuanListProps> = ({
  items,
  jenisList,
  selectedStatus,
  selectedJenis,
  searchQuery,
  isLoading,
  onSearchChange,
  onStatusChange,
  onJenisChange,
  onOpenCreateModal,
  onOpenDetailModal,
  onOpenEditModal,
  onDelete,
  onQuickApprove,
  onQuickReject,
}) => {
  const formatDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
      });
    } catch {
      return dateStr;
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
      {/* Header & Controls Toolbar */}
      <div className="p-5 sm:p-6 border-b border-slate-200 space-y-4 bg-linear-to-b from-slate-50/70 to-white">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                Daftar Permohonan Izin Guru & Pegawai
              </h2>
              <span className="bg-emerald-50 text-emerald-800 text-xs px-2.5 py-0.5 rounded-full font-bold border border-emerald-200 font-mono">
                {items.length} Permohonan
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              SDI Abu Hurairah Lahat • Terhubung langsung dengan tabel <code className="bg-emerald-50 text-emerald-800 px-1 py-0.5 rounded text-xs font-mono font-medium">pengajuan_izin</code> & <code className="bg-emerald-50 text-emerald-800 px-1 py-0.5 rounded text-xs font-mono font-medium">log_status</code>.
            </p>
          </div>
          
          <button
            id="btn-create-pengajuan"
            onClick={onOpenCreateModal}
            className="inline-flex items-center justify-center px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs sm:text-sm font-bold rounded-xl shadow-md shadow-emerald-700/20 transition-all duration-150 cursor-pointer shrink-0"
          >
            <Plus className="w-4 h-4 mr-1.5" />
            <span>Ajukan Izin Guru / Pegawai</span>
          </button>
        </div>

        {/* Filters Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-1">
          {/* Search Input */}
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 transform -translate-y-1/2 text-slate-400" />
            <input
              id="input-search-pengajuan"
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Cari nama guru, NUPTK, alasan, guru inval, no. surat..."
              className="w-full pl-10 pr-4 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white text-slate-800 placeholder-slate-400 transition-all font-medium"
            />
          </div>

          {/* Status Filter */}
          <div className="sm:col-span-3">
            <select
              id="select-filter-status"
              value={selectedStatus}
              onChange={(e) => onStatusChange(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white text-slate-700 font-bold transition-all"
            >
              <option value="SEMUA">Semua Status (All)</option>
              <option value="DIAJUKAN">Diajukan (Permohonan Baru)</option>
              <option value="VERIFIKASI_BERKAS">Verifikasi Berkas & Tugas Inval</option>
              <option value="DISETUJUI">Disetujui (Surat Izin Terbit)</option>
              <option value="DITOLAK">Ditolak / Perlu Perbaikan</option>
            </select>
          </div>

          {/* Jenis Perizinan Filter */}
          <div className="sm:col-span-3">
            <select
              id="select-filter-jenis"
              value={selectedJenis}
              onChange={(e) => onJenisChange(e.target.value)}
              className="w-full px-3 py-2 text-xs sm:text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:bg-white text-slate-700 font-bold transition-all"
            >
              <option value="SEMUA">Semua Kategori Izin</option>
              {jenisList.map((j) => (
                <option key={j.id_jenis} value={j.id_jenis.toString()}>
                  {j.kode_izin} - {j.nama_izin}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Table Section */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 text-slate-600 text-[11px] font-black uppercase tracking-wider border-b border-slate-200">
              <th className="py-3 px-4">No. Registrasi & SK Izin</th>
              <th className="py-3 px-4">Guru / Pegawai</th>
              <th className="py-3 px-4">Jenis Izin & Alasan</th>
              <th className="py-3 px-4">Jadwal & Guru Inval</th>
              <th className="py-3 px-4">Status Verifikasi</th>
              <th className="py-3 px-4">Tanggal Pengajuan</th>
              <th className="py-3 px-4 text-center">Aksi (CRUD)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs sm:text-sm text-slate-800">
            {isLoading ? (
              <tr>
                <td colSpan={7} className="py-16 text-center text-slate-500">
                  <div className="inline-flex flex-col items-center justify-center space-y-2">
                    <div className="w-6 h-6 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-xs font-semibold">Memuat permohonan izin guru...</span>
                  </div>
                </td>
              </tr>
            ) : items.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-16 text-center">
                  <div className="max-w-xs mx-auto text-slate-400 flex flex-col items-center">
                    <FileText className="w-10 h-10 text-slate-300 mb-2" />
                    <p className="text-sm font-bold text-slate-700">Tidak ada permohonan izin ditemukan</p>
                    <p className="text-xs text-slate-400 mt-1">Coba gunakan kata kunci lain atau ajukan izin guru baru.</p>
                  </div>
                </td>
              </tr>
            ) : (
              items.map((item) => {
                const badge = getStatusBadge(item.status_pengajuan);
                const BadgeIcon = badge.icon;
                const namaGuru = item.data_pemohon?.nama_guru_pegawai || item.pengguna?.nama_lengkap || `Guru #${item.id_pengguna}`;
                const nuptk = item.data_pemohon?.nuptk_nip || item.pengguna?.nuptk_nip || '-';
                const jabatan = item.data_pemohon?.jabatan || item.pengguna?.jabatan || 'Guru / Pegawai';
                const alasan = item.data_pemohon?.alasan_izin || item.data_pemohon?.nama_usaha || '-';
                const tglMulai = item.data_pemohon?.tgl_mulai_izin || '-';
                const tglSelesai = item.data_pemohon?.tgl_selesai_izin || '-';
                const durasi = item.data_pemohon?.durasi_hari || 1;
                const guruInval = item.data_pemohon?.guru_pengganti_inval;

                return (
                  <tr 
                    key={item.id_pengajuan} 
                    className="hover:bg-emerald-50/30 transition-colors group"
                  >
                    {/* No Registrasi & SK */}
                    <td className="py-3.5 px-4 font-mono text-xs">
                      <div className="font-bold text-emerald-800 tracking-tight flex items-center">
                        <span>{item.nomor_registrasi}</span>
                      </div>
                      {item.nomor_surat_izin ? (
                        <div className="text-[11px] text-emerald-700 font-bold font-sans mt-0.5 truncate max-w-[170px]" title={item.nomor_surat_izin}>
                          SK: {item.nomor_surat_izin}
                        </div>
                      ) : (
                        <div className="text-[10px] text-slate-400 font-sans mt-0.5">Menunggu TTD Kepsek</div>
                      )}
                    </td>

                    {/* Guru / Pegawai */}
                    <td className="py-3.5 px-4">
                      <div className="font-bold text-slate-900 flex items-center">
                        <GraduationCap className="w-3.5 h-3.5 mr-1.5 text-emerald-600 shrink-0" />
                        <span>{namaGuru}</span>
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5 flex items-center truncate max-w-[200px]">
                        <span className="truncate">{jabatan}</span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        NUPTK: {nuptk}
                      </div>
                    </td>

                    {/* Jenis Perizinan & Alasan */}
                    <td className="py-3.5 px-4 max-w-[220px]">
                      <span className="inline-block font-bold text-xs text-slate-900">
                        {item.jenis_perizinan?.nama_izin || `Izin #${item.id_jenis}`}
                      </span>
                      <p className="text-xs text-slate-500 line-clamp-2 mt-0.5 leading-tight">
                        {alasan}
                      </p>
                    </td>

                    {/* Jadwal & Guru Inval */}
                    <td className="py-3.5 px-4">
                      <div className="text-xs font-semibold text-slate-800 flex items-center">
                        <Calendar className="w-3 h-3 mr-1 text-slate-400" />
                        <span>{tglMulai} s.d {tglSelesai}</span>
                      </div>
                      <div className="text-[11px] text-emerald-700 font-bold mt-0.5">
                        Durasi: {durasi} Hari
                      </div>
                      {guruInval && (
                        <div className="text-[10px] text-slate-500 mt-0.5 flex items-center">
                          <Users className="w-3 h-3 mr-1 text-slate-400" />
                          <span className="truncate max-w-[130px]" title={`Guru Inval: ${guruInval}`}>Inval: {guruInval}</span>
                        </div>
                      )}
                    </td>

                    {/* Status Badge */}
                    <td className="py-3.5 px-4">
                      <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-bold border ${badge.bg}`}>
                        <span className={`w-1.5 h-1.5 rounded-full mr-1.5 ${badge.dot}`}></span>
                        <BadgeIcon className="w-3 h-3 mr-1" />
                        <span>{badge.label}</span>
                      </span>
                    </td>

                    {/* Tanggal Diajukan */}
                    <td className="py-3.5 px-4 text-xs text-slate-500 whitespace-nowrap">
                      <span>{formatDate(item.created_at)}</span>
                    </td>

                    {/* Actions (CRUD & Keputusan) */}
                    <td className="py-3.5 px-4 text-center whitespace-nowrap">
                      <div className="inline-flex items-center space-x-1 bg-slate-100 p-1 rounded-lg border border-slate-200">
                        {/* Quick Setujui */}
                        {onQuickApprove && (
                          <button
                            id={`btn-quick-approve-${item.id_pengajuan}`}
                            onClick={() => onQuickApprove(item)}
                            title={item.status_pengajuan === 'DISETUJUI' ? 'Izin Telah Disetujui' : 'Setujui Permohonan (Kepsek)'}
                            className={`p-1.5 rounded-md transition-all cursor-pointer shadow-2xs ${
                              item.status_pengajuan === 'DISETUJUI'
                                ? 'bg-emerald-600 text-white'
                                : 'text-emerald-700 hover:text-emerald-900 hover:bg-emerald-50'
                            }`}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                          </button>
                        )}

                        {/* Quick Tolak */}
                        {onQuickReject && (
                          <button
                            id={`btn-quick-reject-${item.id_pengajuan}`}
                            onClick={() => onQuickReject(item)}
                            title={item.status_pengajuan === 'DITOLAK' ? 'Izin Telah Ditolak' : 'Tolak Permohonan'}
                            className={`p-1.5 rounded-md transition-all cursor-pointer shadow-2xs ${
                              item.status_pengajuan === 'DITOLAK'
                                ? 'bg-rose-600 text-white'
                                : 'text-rose-600 hover:text-rose-800 hover:bg-rose-50'
                            }`}
                          >
                            <XCircle className="w-3.5 h-3.5" />
                          </button>
                        )}

                        <span className="w-px h-3.5 bg-slate-300 mx-0.5" />

                        {/* Detail / Tracking */}
                        <button
                          id={`btn-detail-pengajuan-${item.id_pengajuan}`}
                          onClick={() => onOpenDetailModal(item)}
                          title="Lihat Detail & Tracking Log"
                          className="p-1.5 text-emerald-700 hover:text-emerald-900 hover:bg-white rounded-md transition-all cursor-pointer shadow-2xs"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>

                        {/* Edit */}
                        <button
                          id={`btn-edit-pengajuan-${item.id_pengajuan}`}
                          onClick={() => onOpenEditModal(item)}
                          title="Edit Formulir Izin"
                          className="p-1.5 text-slate-600 hover:text-slate-900 hover:bg-white rounded-md transition-all cursor-pointer shadow-2xs"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        {/* Delete */}
                        <button
                          id={`btn-delete-pengajuan-${item.id_pengajuan}`}
                          onClick={() => onDelete(item)}
                          title="Hapus Pengajuan Izin"
                          className="p-1.5 text-rose-600 hover:text-rose-800 hover:bg-white rounded-md transition-all cursor-pointer shadow-2xs"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Footer Info */}
      <div className="p-3.5 bg-slate-50 border-t border-slate-200 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <span className="font-semibold">Menampilkan <strong>{items.length}</strong> data izin guru & pegawai</span>
        <span className="text-[11px] text-slate-400">Endpoint: <code className="text-emerald-800 font-mono bg-white px-1.5 py-0.5 rounded border border-slate-200">GET /api/pengajuan</code></span>
      </div>
    </div>
  );
};
