export interface GuruPegawai {
  id: number;
  nama: string;
  jabatan: string;
  kategori: 'Guru' | 'Pegawai / Tata Usaha' | 'Pimpinan';
  nuptk_nip: string;
  no_telepon: string;
  email: string;
}

export const DAFTAR_GURU_PEGAWAI: GuruPegawai[] = [
  { id: 1, nama: 'HENDRA, S.Pd.', jabatan: 'Kepala Sekolah / Guru', kategori: 'Pimpinan', nuptk_nip: '197805122005011002', no_telepon: '081271234001', email: 'hendra.spiah@sdiah-lahat.sch.id' },
  { id: 2, nama: 'APYURI PAREZKA AMA.PUST', jabatan: 'Pustakawan / Tenaga Perpustakaan', kategori: 'Pegawai / Tata Usaha', nuptk_nip: '198902142012012003', no_telepon: '081373456002', email: 'apyuri.parezka@sdiah-lahat.sch.id' },
  { id: 3, nama: 'EVIANI FRANSISKA S.Pd', jabatan: 'Guru Kelas / Wali Kelas', kategori: 'Guru', nuptk_nip: '198506212009012004', no_telepon: '082181234003', email: 'eviani.fransiska@sdiah-lahat.sch.id' },
  { id: 4, nama: 'MUTIARA S.Pd', jabatan: 'Guru Kelas / Wali Kelas', kategori: 'Guru', nuptk_nip: '199003182014012005', no_telepon: '085267123004', email: 'mutiara.spd@sdiah-lahat.sch.id' },
  { id: 5, nama: 'DINIA ALFAIZAH S.Pd', jabatan: 'Guru Mata Pelajaran', kategori: 'Guru', nuptk_nip: '199211052016012006', no_telepon: '081278901005', email: 'dinia.alfaizah@sdiah-lahat.sch.id' },
  { id: 6, nama: 'RESTI HANDAIANI', jabatan: 'Staf Tata Usaha & Keuangan', kategori: 'Pegawai / Tata Usaha', nuptk_nip: '199307252017012007', no_telepon: '081369012006', email: 'resti.handaiani@sdiah-lahat.sch.id' },
  { id: 7, nama: 'NIA WULANDARI S.PD SD', jabatan: 'Guru Kelas SD', kategori: 'Guru', nuptk_nip: '198812102011012008', no_telepon: '082280123007', email: 'nia.wulandari@sdiah-lahat.sch.id' },
  { id: 8, nama: 'WIWIN WINDRIANI', jabatan: 'Guru / Tenaga Pendidik', kategori: 'Guru', nuptk_nip: '199104082015012009', no_telepon: '085381234008', email: 'wiwin.windriani@sdiah-lahat.sch.id' },
  { id: 9, nama: 'AYU ANDIRA', jabatan: 'Guru / Tenaga Pendidik', kategori: 'Guru', nuptk_nip: '199408192018012010', no_telepon: '081273456009', email: 'ayu.andira@sdiah-lahat.sch.id' },
  { id: 10, nama: 'ELIP NURYANA', jabatan: 'Guru / Tenaga Pendidik', kategori: 'Guru', nuptk_nip: '198709302010012011', no_telepon: '081377890010', email: 'elip.nuryana@sdiah-lahat.sch.id' },
  { id: 11, nama: 'MERLIN ASNITA S.Sos', jabatan: 'Staf Kepegawaian & Administrasi', kategori: 'Pegawai / Tata Usaha', nuptk_nip: '198603152008012012', no_telepon: '082185678011', email: 'merlin.asnita@sdiah-lahat.sch.id' },
  { id: 12, nama: 'TARI CAHYANI, S.Pd.', jabatan: 'Guru Kelas / Wali Kelas', kategori: 'Guru', nuptk_nip: '199205142016012013', no_telepon: '085269012012', email: 'tari.cahyani@sdiah-lahat.sch.id' },
  { id: 13, nama: 'ARYANTI RIZKIYAH S.Pd', jabatan: 'Guru Kelas', kategori: 'Guru', nuptk_nip: '199301222017012014', no_telepon: '081279123013', email: 'aryanti.rizkiyah@sdiah-lahat.sch.id' },
  { id: 14, nama: 'SRI RAHAYU', jabatan: 'Guru / Tenaga Kependidikan', kategori: 'Guru', nuptk_nip: '198910042013012015', no_telepon: '081374567014', email: 'sri.rahayu@sdiah-lahat.sch.id' },
  { id: 15, nama: 'RENSI RATNA SARI S.E', jabatan: 'Bendahara Sekolah / Keuangan', kategori: 'Pegawai / Tata Usaha', nuptk_nip: '199008122014012016', no_telepon: '082281234015', email: 'rensi.ratnasari@sdiah-lahat.sch.id' },
  { id: 16, nama: 'HENI SUVIANTI', jabatan: 'Guru Kelas', kategori: 'Guru', nuptk_nip: '198807162012012017', no_telepon: '085382345016', email: 'heni.suvianti@sdiah-lahat.sch.id' },
  { id: 17, nama: 'NURCHENI ASTARA S.Pi', jabatan: 'Guru Mapel IPA / Tematik', kategori: 'Guru', nuptk_nip: '198611282009012018', no_telepon: '081271901017', email: 'nurcheni.astara@sdiah-lahat.sch.id' },
  { id: 18, nama: 'RANGGA ABDUL BARI', jabatan: 'Guru Tahfidz & PAI', kategori: 'Guru', nuptk_nip: '199504102019011019', no_telepon: '081378123018', email: 'rangga.bari@sdiah-lahat.sch.id' },
  { id: 19, nama: 'SURNIYATI S.Pd', jabatan: 'Guru Kelas SD', kategori: 'Guru', nuptk_nip: '198402172007012020', no_telepon: '082186789019', email: 'surniyati.spd@sdiah-lahat.sch.id' },
  { id: 20, nama: 'RETIA ABILLILA', jabatan: 'Guru / Tenaga Kependidikan', kategori: 'Guru', nuptk_nip: '199412032018012021', no_telepon: '085261234020', email: 'retia.abillila@sdiah-lahat.sch.id' },
  { id: 21, nama: 'CRISMALAYANI S.PD.I', jabatan: 'Guru Pendidikan Agama Islam (PAI)', kategori: 'Guru', nuptk_nip: '198705092010012022', no_telepon: '081272345021', email: 'crismalayani.pai@sdiah-lahat.sch.id' },
  { id: 22, nama: 'DELLA ARISKA', jabatan: 'Staf Administrasi & Kesiswaan', kategori: 'Pegawai / Tata Usaha', nuptk_nip: '199609142020012023', no_telepon: '081379012022', email: 'della.ariska@sdiah-lahat.sch.id' },
  { id: 23, nama: 'NORMANSYAH S.Pd', jabatan: 'Guru PJOK / Olahraga & Kesehatan', kategori: 'Guru', nuptk_nip: '198801252011011024', no_telepon: '082282345023', email: 'normansyah.pjok@sdiah-lahat.sch.id' },
  { id: 24, nama: 'APRIYANI', jabatan: 'Guru / Tenaga Pendidik', kategori: 'Guru', nuptk_nip: '199106182015012025', no_telepon: '085383456024', email: 'apriyani@sdiah-lahat.sch.id' },
  { id: 25, nama: 'BETA TIARA SARI, S.SOS', jabatan: 'Staf Bimbingan Konseling (BK) & TU', kategori: 'Pegawai / Tata Usaha', nuptk_nip: '199203112016012026', no_telepon: '081273901025', email: 'beta.tiarasari@sdiah-lahat.sch.id' },
  { id: 26, nama: 'BALQIS SALSABILLA', jabatan: 'Guru Bahasa Arab & Inggris', kategori: 'Guru', nuptk_nip: '199708202021012027', no_telepon: '081371234026', email: 'balqis.salsabilla@sdiah-lahat.sch.id' },
  { id: 27, nama: 'DEWI NURSELA', jabatan: 'Guru Kelas', kategori: 'Guru', nuptk_nip: '199310052017012028', no_telepon: '082187890027', email: 'dewi.nursela@sdiah-lahat.sch.id' },
  { id: 28, nama: 'RAMA HIDAYAT', jabatan: 'Operator Sekolah & IT Support', kategori: 'Pegawai / Tata Usaha', nuptk_nip: '199402282018011029', no_telepon: '085262345028', email: 'rama.hidayat@sdiah-lahat.sch.id' },
  { id: 29, nama: 'NOPRIANI, S.PD SD', jabatan: 'Guru Kelas SD', kategori: 'Guru', nuptk_nip: '198511152009012030', no_telepon: '081274567029', email: 'nopriani.spd@sdiah-lahat.sch.id' },
  { id: 30, nama: 'MELA AILSA SALSABILLA', jabatan: 'Guru / Tenaga Pendidik', kategori: 'Guru', nuptk_nip: '199806142022012031', no_telepon: '081372345030', email: 'mela.ailsa@sdiah-lahat.sch.id' },
  { id: 31, nama: 'IMAM MUTTAQIN S.Sos', jabatan: 'Wakil Kepala Sekolah / Humas', kategori: 'Pimpinan', nuptk_nip: '198308072006011032', no_telepon: '082283456031', email: 'imam.muttaqin@sdiah-lahat.sch.id' },
  { id: 32, nama: 'EFTA SYATRIANSA', jabatan: 'Staf Sarana & Prasarana', kategori: 'Pegawai / Tata Usaha', nuptk_nip: '199109232015011033', no_telepon: '085384567032', email: 'efta.syatriansa@sdiah-lahat.sch.id' },
  { id: 33, nama: 'MIKO RAHMAN, S.A.P.', jabatan: 'Kepala Tata Usaha (Ka. TU)', kategori: 'Pegawai / Tata Usaha', nuptk_nip: '198710182010011034', no_telepon: '081275678033', email: 'miko.rahman@sdiah-lahat.sch.id' },
  { id: 34, nama: 'EFFELL HELLEVENT', jabatan: 'Tenaga Kebersihan & Keamanan', kategori: 'Pegawai / Tata Usaha', nuptk_nip: '199005122014011035', no_telepon: '081373901034', email: 'effell.hellevent@sdiah-lahat.sch.id' },
  { id: 35, nama: 'AKBAR SAPUTRA', jabatan: 'Guru Pendamping & Ekstrakurikuler', kategori: 'Guru', nuptk_nip: '199601192020011036', no_telepon: '082188901035', email: 'akbar.saputra@sdiah-lahat.sch.id' },
  { id: 36, nama: 'RENNY MELIA SARI, Dipl, Phil, B.A.', jabatan: 'Koordinator Kurikulum & Bahasa', kategori: 'Guru', nuptk_nip: '198904032013012037', no_telepon: '085263456036', email: 'renny.meliasari@sdiah-lahat.sch.id' },
  { id: 37, nama: 'RAMA JEA, S.Pd.', jabatan: 'Guru Kelas & Pembina Prestasi', kategori: 'Guru', nuptk_nip: '199308142017011038', no_telepon: '081276789037', email: 'rama.jea@sdiah-lahat.sch.id' },
];

export const DAFTAR_JENIS_IZIN_SEKOLAH = [
  {
    id_jenis: 1,
    kode_izin: 'IZN-SKT',
    nama_izin: 'Izin Sakit Guru & Pegawai',
    deskripsi: 'Permohonan izin tidak dapat melaksanakan tugas mengajar/piket karena kondisi kesehatan yang memerlukan istirahat atau perawatan medis.',
    persyaratan: [
      'Surat Keterangan Dokter / Klinik / Puskesmas',
      'Informasi Rencana Pembelajaran / Tugas Inval Siswa',
      'Konfirmasi ke Guru Piket Harian'
    ],
    estimasi_hari_kerja: 1,
    biaya_retribusi: 0,
    masa_berlaku_tahun: 1,
    is_active: true
  },
  {
    id_jenis: 2,
    kode_izin: 'IZN-PBD',
    nama_izin: 'Izin Keperluan Pribadi / Keluarga Mendesak',
    deskripsi: 'Izin tidak hadir sementara untuk keperluan keluarga penting, musibah, hajatan keluarga inti, atau keperluan pribadi mendesak yang tidak dapat diwakilkan.',
    persyaratan: [
      'Formulir Pengajuan Izin Bermaterai / Ditandatangani',
      'Pelimpahan Tugas Mengajar / Modul Ajar Inval',
      'Persetujuan Wali Kelas / Rekan Guru Pendamping'
    ],
    estimasi_hari_kerja: 1,
    biaya_retribusi: 0,
    masa_berlaku_tahun: 1,
    is_active: true
  },
  {
    id_jenis: 3,
    kode_izin: 'IZN-TGS',
    nama_izin: 'Izin Tugas Kedinasan / Workshop / Bimtek',
    deskripsi: 'Penugasan luar sekolah untuk menghadiri undangan Diknas, KKG/MGMP, Pelatihan Kurikulum, Lomba Kesiswaan, atau kegiatan Yayasan Al Afwa Wal Afiah.',
    persyaratan: [
      'Surat Undangan / Surat Tugas Dinas Resmi',
      'Lembar Disposisi Kepala Sekolah',
      'Jadwal & Agenda Pelaksanaan Kegiatan'
    ],
    estimasi_hari_kerja: 1,
    biaya_retribusi: 0,
    masa_berlaku_tahun: 1,
    is_active: true
  },
  {
    id_jenis: 4,
    kode_izin: 'IZN-DSP',
    nama_izin: 'Dispensasi Jam Mengajar / Izin Keluar Sementara',
    deskripsi: 'Dispensasi meninggalkan lingkungan sekolah beberapa jam untuk keperluan dinas singkat, administrasi yayasan, atau urusan mendesak dengan kembali di hari yang sama.',
    persyaratan: [
      'Pemberitahuan Guru Piket & Ka. TU',
      'Tugas Belajar Mandiri di Kelas',
      'Konfirmasi Jam Kembali ke Sekolah'
    ],
    estimasi_hari_kerja: 1,
    biaya_retribusi: 0,
    masa_berlaku_tahun: 1,
    is_active: true
  },
  {
    id_jenis: 5,
    kode_izin: 'IZN-CTI',
    nama_izin: 'Permohonan Cuti Tahunan / Melahirkan / Umroh & Haji',
    deskripsi: 'Cuti resmi bagi pendidik dan tenaga kependidikan meliputi cuti melahirkan, cuti tahunan terjadwal, ibadah haji/umroh, atau cuti alasan penting.',
    persyaratan: [
      'Surat Permohonan Cuti Tertulis',
      'Rekomendasi Kepala Sekolah SDI Abu Hurairah',
      'Persetujuan Pengurus Yayasan Al Afwa Wal Afiah',
      'Rencana Guru Pengganti (Inval Jangka Panjang)'
    ],
    estimasi_hari_kerja: 3,
    biaya_retribusi: 0,
    masa_berlaku_tahun: 1,
    is_active: true
  }
];
