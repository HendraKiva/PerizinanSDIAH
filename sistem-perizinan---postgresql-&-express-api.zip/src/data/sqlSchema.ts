import { TableSchemaDef } from '../types/database';

export const POSTGRESQL_DDL_SCRIPT = `-- ====================================================================
-- SKRIP DATABASE POSTGRESQL: APLIKASI PERIZINAN TERPADU (WEB & ANDROID)
-- Termasuk Tabel: pengguna, jenis_perizinan, pengajuan_izin, log_status
-- Dilengkapi Foreign Key, Indexing, Triggers, & Constraints
-- ====================================================================

-- 1. Buat Ekstensi UUID (Opsional jika ingin UUID)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. ENUM TYPES (Tipe Data Kustom untuk Integritas Status)
CREATE TYPE peran_pengguna_enum AS ENUM (
    'pemohon', 
    'verifikator', 
    'kepala_dinas', 
    'admin'
);

CREATE TYPE status_pengajuan_enum AS ENUM (
    'DRAFT',
    'DIAJUKAN',
    'VERIFIKASI_BERKAS',
    'SURVEI_LAPANGAN',
    'MENUNGGU_PEMBAYARAN',
    'DISETUJUI',
    'DITOLAK',
    'DICABUT'
);

CREATE TYPE status_pembayaran_enum AS ENUM (
    'BELUM_BAYAR',
    'LUNAS',
    'GRATIS'
);

-- ====================================================================
-- TABEL 1: PENGGUNA (Users & Staff/Officers)
-- ====================================================================
CREATE TABLE IF NOT EXISTS pengguna (
    id_pengguna SERIAL PRIMARY KEY,
    nama_lengkap VARCHAR(150) NOT NULL,
    nik VARCHAR(20) UNIQUE,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    no_telepon VARCHAR(20),
    alamat TEXT,
    peran peran_pengguna_enum NOT NULL DEFAULT 'pemohon',
    fcm_token VARCHAR(255), -- Token Firebase Cloud Messaging untuk notifikasi Android
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexing Tabel Pengguna
CREATE INDEX IF NOT EXISTS idx_pengguna_email ON pengguna(email);
CREATE INDEX IF NOT EXISTS idx_pengguna_nik ON pengguna(nik);
CREATE INDEX IF NOT EXISTS idx_pengguna_peran ON pengguna(peran);

COMMENT ON TABLE pengguna IS 'Menyimpan data akun pemohon perizinan serta petugas dinas/verifikator/admin';
COMMENT ON COLUMN pengguna.nik IS 'Nomor Induk Kependudukan pemohon perizinan';
COMMENT ON COLUMN pengguna.fcm_token IS 'Device push token untuk push notification perangkat Android';

-- ====================================================================
-- TABEL 2: JENIS_PERIZINAN (Permit Types & Requirements)
-- ====================================================================
CREATE TABLE IF NOT EXISTS jenis_perizinan (
    id_jenis SERIAL PRIMARY KEY,
    kode_izin VARCHAR(30) UNIQUE NOT NULL,
    nama_izin VARCHAR(150) NOT NULL,
    deskripsi TEXT,
    persyaratan JSONB NOT NULL DEFAULT '[]'::jsonb, -- Daftar syarat berkas dalam JSONB array
    estimasi_hari_kerja INTEGER NOT NULL DEFAULT 7 CHECK (estimasi_hari_kerja > 0),
    biaya_retribusi NUMERIC(12, 2) NOT NULL DEFAULT 0.00 CHECK (biaya_retribusi >= 0),
    masa_berlaku_tahun INTEGER NOT NULL DEFAULT 1 CHECK (masa_berlaku_tahun >= 0),
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Indexing Tabel Jenis Perizinan
CREATE INDEX IF NOT EXISTS idx_jenis_perizinan_kode ON jenis_perizinan(kode_izin);
CREATE INDEX IF NOT EXISTS idx_jenis_perizinan_active ON jenis_perizinan(is_active);

COMMENT ON TABLE jenis_perizinan IS 'Master data katalog jenis-jenis izin yang dapat diajukan oleh masyarakat/badan usaha';

-- ====================================================================
-- TABEL 3: PENGAJUAN_IZIN (Core Permit Applications)
-- ====================================================================
CREATE TABLE IF NOT EXISTS pengajuan_izin (
    id_pengajuan SERIAL PRIMARY KEY,
    nomor_registrasi VARCHAR(50) UNIQUE NOT NULL,
    id_pengguna INTEGER NOT NULL,
    id_jenis INTEGER NOT NULL,
    data_pemohon JSONB NOT NULL DEFAULT '{}'::jsonb, -- Detail spesifik (nama usaha, luas, koordinat GPS Android, dsb)
    dokumen_lampiran JSONB NOT NULL DEFAULT '[]'::jsonb, -- Berkas upload (KTP, NPWP, Denah, Sertifikat)
    status_pengajuan status_pengajuan_enum NOT NULL DEFAULT 'DIAJUKAN',
    catatan_petugas TEXT,
    nomor_surat_izin VARCHAR(100), -- Nomor SK izin jika sudah disetujui
    tgl_terbit DATE,
    tgl_kedaluwarsa DATE,
    biaya_final NUMERIC(12, 2) NOT NULL DEFAULT 0.00 CHECK (biaya_final >= 0),
    status_pembayaran status_pembayaran_enum NOT NULL DEFAULT 'BELUM_BAYAR',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    -- Relasi Foreign Key
    CONSTRAINT fk_pengajuan_pengguna 
        FOREIGN KEY (id_pengguna) 
        REFERENCES pengguna(id_pengguna) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE,

    CONSTRAINT fk_pengajuan_jenis 
        FOREIGN KEY (id_jenis) 
        REFERENCES jenis_perizinan(id_jenis) 
        ON DELETE RESTRICT 
        ON UPDATE CASCADE
);

-- Indexing Tabel Pengajuan Izin
CREATE INDEX IF NOT EXISTS idx_pengajuan_nomor_reg ON pengajuan_izin(nomor_registrasi);
CREATE INDEX IF NOT EXISTS idx_pengajuan_pengguna ON pengajuan_izin(id_pengguna);
CREATE INDEX IF NOT EXISTS idx_pengajuan_jenis ON pengajuan_izin(id_jenis);
CREATE INDEX IF NOT EXISTS idx_pengajuan_status ON pengajuan_izin(status_pengajuan);
CREATE INDEX IF NOT EXISTS idx_pengajuan_created_at ON pengajuan_izin(created_at DESC);

-- GIN Index untuk pencarian cepat dalam JSONB (data_pemohon & lampiran)
CREATE INDEX IF NOT EXISTS idx_pengajuan_data_pemohon_gin ON pengajuan_izin USING gin (data_pemohon);

COMMENT ON TABLE pengajuan_izin IS 'Tabel transaksi permohonan izin dari pemohon lengkap dengan berkas dan status';

-- ====================================================================
-- TABEL 4: LOG_STATUS (Audit Trail & Tracking History)
-- ====================================================================
CREATE TABLE IF NOT EXISTS log_status (
    id_log SERIAL PRIMARY KEY,
    id_pengajuan INTEGER NOT NULL,
    status_sebelumnya status_pengajuan_enum,
    status_baru status_pengajuan_enum NOT NULL,
    id_petugas INTEGER,
    keterangan TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,

    -- Relasi Foreign Key
    CONSTRAINT fk_log_pengajuan 
        FOREIGN KEY (id_pengajuan) 
        REFERENCES pengajuan_izin(id_pengajuan) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE,

    CONSTRAINT fk_log_petugas 
        FOREIGN KEY (id_petugas) 
        REFERENCES pengguna(id_pengguna) 
        ON DELETE SET NULL 
        ON UPDATE CASCADE
);

-- Indexing Tabel Log Status
CREATE INDEX IF NOT EXISTS idx_log_id_pengajuan ON log_status(id_pengajuan);
CREATE INDEX IF NOT EXISTS idx_log_created_at ON log_status(created_at DESC);

COMMENT ON TABLE log_status IS 'Riwayat perubahan status perizinan secara kronologis untuk transparansi dan audit trail';

-- ====================================================================
-- TRIGGER OTOMATIS: AUTO UPDATE COLUMN "updated_at"
-- ====================================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_update_pengguna_updated_at
    BEFORE UPDATE ON pengguna
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_update_jenis_perizinan_updated_at
    BEFORE UPDATE ON jenis_perizinan
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_update_pengajuan_izin_updated_at
    BEFORE UPDATE ON pengajuan_izin
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ====================================================================
-- DATA AWAL (SEED SAMPLE DATA)
-- ====================================================================

-- Data Pengguna
INSERT INTO pengguna (nama_lengkap, nik, email, password_hash, no_telepon, alamat, peran)
VALUES 
('Budi Santoso', '3201012304890001', 'budi.santoso@example.com', '$2b$10$hashedpw1...', '081234567890', 'Jl. Merdeka No. 45, Jakarta', 'pemohon'),
('Siti Rahmawati', '3201016508920002', 'siti.rahma@example.com', '$2b$10$hashedpw2...', '081398765432', 'Jl. Sudirman Kav. 12, Bandung', 'pemohon'),
('Ahmad Fauzi, S.STP', '3271011103850005', 'ahmad.verifikator@dinas.go.id', '$2b$10$hashedpw3...', '082111223344', 'Kantor DPMPTSP Lantai 2', 'verifikator'),
('Dr. Ir. Hendra Kusuma, M.Si', '3171011502750001', 'hendra.kadis@dinas.go.id', '$2b$10$hashedpw4...', '081122334455', 'Gedung Balai Kota Ruang 301', 'kepala_dinas');

-- Data Master Jenis Perizinan
INSERT INTO jenis_perizinan (kode_izin, nama_izin, deskripsi, persyaratan, estimasi_hari_kerja, biaya_retribusi, masa_berlaku_tahun)
VALUES 
(
    'IMB-01', 
    'Persetujuan Bangunan Gedung (PBG / IMB)', 
    'Izin mendirikan, merenovasi, atau memelihara bangunan sesuai standar teknis keselamatan.',
    '["KTP Pemohon", "Bukti Kepemilikan Tanah / SHM", "Gambar Arsitektur & Struktur", "Surat Pernyataan Kesanggupan Teknis"]'::jsonb,
    14,
    750000.00,
    0 -- 0 = Seumur hidup bangunan
),
(
    'SIUP-02', 
    'Surat Izin Usaha Perdagangan (SIUP)', 
    'Izin operasional untuk menjalankan kegiatan perdagangan skala mikro, kecil, menengah, atau besar.',
    '["KTP Direktur / Pemilik", "NPWP Perusahaan", "Akta Pendirian Badan Usaha", "Bukti Lokasi Tempat Usaha / NIB"]'::jsonb,
    5,
    0.00, -- Gratis program kemudahan UMKM
    5
),
(
    'SIP-DR-03', 
    'Surat Izin Praktik Dokter (SIP)', 
    'Izin praktik resmi bagi tenaga medis profesional dokter umum/spesialis di klinik atau faskes.',
    '["Surat Tanda Registrasi (STR) Aktif", "Rekomendasi Organisasi Profesi (IDI)", "Surat Keterangan Tempat Praktik", "Pas Foto Berwarna 4x6"]'::jsonb,
    7,
    150000.00,
    5
),
(
    'REKLAME-04', 
    'Izin Penyelenggaraan Reklame / Reklame Billboard', 
    'Izin pemasangan media promosi luar ruang di titik-titik strategis wilayah kota/kabupaten.',
    '["KTP Penanggung Jawab", "Desain Visual & Teks Reklame", "Denah Lokasi & Titik Koordinat GPS", "Surat Izin Pemilik Lahan"]'::jsonb,
    10,
    1200000.00,
    1
);

-- Data Pengajuan Izin
INSERT INTO pengajuan_izin (nomor_registrasi, id_pengguna, id_jenis, data_pemohon, dokumen_lampiran, status_pengajuan, catatan_petugas, biaya_final, status_pembayaran)
VALUES 
(
    'REG-2026-08001',
    1,
    1,
    '{"nama_usaha": "Pembangunan Rumah Tinggal 2 Lantai", "alamat_lokasi": "Jl. Melati Blok C-12", "kecamatan": "Coblong", "kelurahan": "Dago", "luas_tempat_m2": 180, "koordinat_lat": -6.8856, "koordinat_lng": 107.6139}'::jsonb,
    '[{"id_dokumen": "doc_01", "nama_dokumen": "KTP_Budi.pdf", "url": "https://storage.example.com/ktp_budi.pdf", "tipe_file": "application/pdf", "ukuran_kb": 450, "uploaded_at": "2026-08-20T08:30:00Z"}, {"id_dokumen": "doc_02", "nama_dokumen": "SHM_Tanah.pdf", "url": "https://storage.example.com/shm.pdf", "tipe_file": "application/pdf", "ukuran_kb": 1200, "uploaded_at": "2026-08-20T08:31:00Z"}]'::jsonb,
    'VERIFIKASI_BERKAS',
    'Berkas SHM dan KTP lengkap, berkas teknis sedang dicek oleh tim arsitek.',
    750000.00,
    'BELUM_BAYAR'
),
(
    'REG-2026-08002',
    2,
    2,
    '{"nama_usaha": "CV Berkah Maju Bersama", "alamat_lokasi": "Jl. Gatot Subroto No. 88", "kecamatan": "Lengkong", "kelurahan": "Malabar", "luas_tempat_m2": 65, "koordinat_lat": -6.9248, "koordinat_lng": 107.6256}'::jsonb,
    '[{"id_dokumen": "doc_03", "nama_dokumen": "NIB_Perusahaan.pdf", "url": "https://storage.example.com/nib.pdf", "tipe_file": "application/pdf", "ukuran_kb": 620, "uploaded_at": "2026-08-22T10:00:00Z"}]'::jsonb,
    'DISETUJUI',
    'Semua persyaratan NIB dan KTP valid. SK Izin telah diterbitkan secara digital.',
    0.00,
    'GRATIS'
);

-- Data Log Status
INSERT INTO log_status (id_pengajuan, status_sebelumnya, status_baru, id_petugas, keterangan)
VALUES 
(1, NULL, 'DIAJUKAN', 1, 'Pengajuan baru didaftarkan secara online melalui aplikasi.'),
(1, 'DIAJUKAN', 'VERIFIKASI_BERKAS', 3, 'Dokumen diterima petugas loket dan diteruskan ke tim verifikasi.'),
(2, NULL, 'DIAJUKAN', 2, 'Pengajuan SIUP didaftarkan oleh pemohon.'),
(2, 'DIAJUKAN', 'VERIFIKASI_BERKAS', 3, 'Verifikasi berkas NIB dan NPWP lengkap.'),
(2, 'VERIFIKASI_BERKAS', 'DISETUJUI', 4, 'Kepala dinas menandatangani persetujuan izin secara elektronik.');
`;

export const TABLE_SCHEMAS: TableSchemaDef[] = [
  {
    tableName: 'pengguna',
    description: 'Menyimpan identitas akun pemohon izin, verifikator berkas, kepala dinas, dan administrator sistem.',
    primaryKey: 'id_pengguna',
    indexes: ['idx_pengguna_email (UNIQUE)', 'idx_pengguna_nik (UNIQUE)', 'idx_pengguna_peran'],
    columns: [
      { columnName: 'id_pengguna', dataType: 'SERIAL', constraints: 'PRIMARY KEY', nullable: false, description: 'ID unik pengguna (Auto-increment integer)' },
      { columnName: 'nama_lengkap', dataType: 'VARCHAR(150)', constraints: 'NOT NULL', nullable: false, description: 'Nama lengkap pemohon atau pegawai dinas' },
      { columnName: 'nik', dataType: 'VARCHAR(20)', constraints: 'UNIQUE', nullable: true, description: 'Nomor Induk Kependudukan (16 digit)' },
      { columnName: 'email', dataType: 'VARCHAR(100)', constraints: 'UNIQUE, NOT NULL', nullable: false, description: 'Alamat surel untuk login dan notifikasi' },
      { columnName: 'password_hash', dataType: 'VARCHAR(255)', constraints: 'NOT NULL', nullable: false, description: 'Hash kata sandi (Bcrypt/Argon2)' },
      { columnName: 'no_telepon', dataType: 'VARCHAR(20)', constraints: '', nullable: true, description: 'Nomor HP/WhatsApp untuk notifikasi SMS/WA' },
      { columnName: 'alamat', dataType: 'TEXT', constraints: '', nullable: true, description: 'Alamat domisili lengkap pemohon' },
      { columnName: 'peran', dataType: 'peran_pengguna_enum', constraints: 'NOT NULL, DEFAULT \'pemohon\'', nullable: false, defaultValue: '\'pemohon\'', description: 'Peran hak akses: pemohon | verifikator | kepala_dinas | admin' },
      { columnName: 'fcm_token', dataType: 'VARCHAR(255)', constraints: '', nullable: true, description: 'Firebase Cloud Messaging Device Token untuk push notification Android' },
      { columnName: 'is_active', dataType: 'BOOLEAN', constraints: 'DEFAULT TRUE', nullable: false, defaultValue: 'true', description: 'Status keaktifan akun pengguna' },
      { columnName: 'created_at', dataType: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP', nullable: false, defaultValue: 'CURRENT_TIMESTAMP', description: 'Waktu registrasi akun' },
      { columnName: 'updated_at', dataType: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP', nullable: false, defaultValue: 'CURRENT_TIMESTAMP', description: 'Waktu terakhir data diperbarui' }
    ]
  },
  {
    tableName: 'jenis_perizinan',
    description: 'Master katalog izin resmi yang disediakan pemerintah/instansi, lengkap dengan syarat dan tarif retribusi.',
    primaryKey: 'id_jenis',
    indexes: ['idx_jenis_perizinan_kode (UNIQUE)', 'idx_jenis_perizinan_active'],
    columns: [
      { columnName: 'id_jenis', dataType: 'SERIAL', constraints: 'PRIMARY KEY', nullable: false, description: 'ID unik jenis perizinan' },
      { columnName: 'kode_izin', dataType: 'VARCHAR(30)', constraints: 'UNIQUE, NOT NULL', nullable: false, description: 'Kode unik izin (contoh: IMB-01, SIUP-02, SIP-DR-03)' },
      { columnName: 'nama_izin', dataType: 'VARCHAR(150)', constraints: 'NOT NULL', nullable: false, description: 'Nama resmi layanan perizinan' },
      { columnName: 'deskripsi', dataType: 'TEXT', constraints: '', nullable: true, description: 'Penjelasan dasar hukum dan lingkup perizinan' },
      { columnName: 'persyaratan', dataType: 'JSONB', constraints: 'NOT NULL, DEFAULT \'[]\'', nullable: false, defaultValue: '\'[]\'', description: 'Daftar dokumen syarat yang wajib diunggah pemohon (JSON Array)' },
      { columnName: 'estimasi_hari_kerja', dataType: 'INTEGER', constraints: 'CHECK (> 0), DEFAULT 7', nullable: false, defaultValue: '7', description: 'SLA penyelesaian layanan dalam hitungan hari kerja' },
      { columnName: 'biaya_retribusi', dataType: 'NUMERIC(12,2)', constraints: 'CHECK (>= 0), DEFAULT 0.00', nullable: false, defaultValue: '0.00', description: 'Tarif retribusi resmi daerah (Rp)' },
      { columnName: 'masa_berlaku_tahun', dataType: 'INTEGER', constraints: 'CHECK (>= 0), DEFAULT 1', nullable: false, defaultValue: '1', description: 'Durasi izin berlaku dalam tahun (0 = seumur hidup)' },
      { columnName: 'is_active', dataType: 'BOOLEAN', constraints: 'DEFAULT TRUE', nullable: false, defaultValue: 'true', description: 'Status apakah jenis izin ini sedang aktif dibuka' },
      { columnName: 'created_at', dataType: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP', nullable: false, defaultValue: 'CURRENT_TIMESTAMP', description: 'Waktu pembuatan master data' },
      { columnName: 'updated_at', dataType: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP', nullable: false, defaultValue: 'CURRENT_TIMESTAMP', description: 'Waktu perubahan data' }
    ]
  },
  {
    tableName: 'pengajuan_izin',
    description: 'Tabel transaksi permohonan izin dari masyarakat/perusahaan, menyimpan formulir dinamis, dokumen lampiran, dan status proses.',
    primaryKey: 'id_pengajuan',
    foreignKeys: [
      { column: 'id_pengguna', referencesTable: 'pengguna', referencesColumn: 'id_pengguna', onDelete: 'CASCADE' },
      { column: 'id_jenis', referencesTable: 'jenis_perizinan', referencesColumn: 'id_jenis', onDelete: 'RESTRICT' }
    ],
    indexes: ['idx_pengajuan_nomor_reg (UNIQUE)', 'idx_pengajuan_pengguna', 'idx_pengajuan_jenis', 'idx_pengajuan_status', 'idx_pengajuan_created_at', 'idx_pengajuan_data_pemohon_gin (GIN)'],
    columns: [
      { columnName: 'id_pengajuan', dataType: 'SERIAL', constraints: 'PRIMARY KEY', nullable: false, description: 'ID unik pengajuan perizinan' },
      { columnName: 'nomor_registrasi', dataType: 'VARCHAR(50)', constraints: 'UNIQUE, NOT NULL', nullable: false, description: 'Nomor pendaftaran perizinan (contoh: REG-2026-08001)' },
      { columnName: 'id_pengguna', dataType: 'INTEGER', constraints: 'FK -> pengguna.id_pengguna (ON DELETE CASCADE)', nullable: false, description: 'Relasi ke akun pemohon perizinan' },
      { columnName: 'id_jenis', dataType: 'INTEGER', constraints: 'FK -> jenis_perizinan.id_jenis (ON DELETE RESTRICT)', nullable: false, description: 'Relasi ke jenis perizinan yang diproses' },
      { columnName: 'data_pemohon', dataType: 'JSONB', constraints: 'NOT NULL, DEFAULT \'{}\'', nullable: false, defaultValue: '\'{}\'', description: 'Data formulir terstruktur (nama usaha, alamat, koordinat GPS Android lat/lng, luas lokasi, dll)' },
      { columnName: 'dokumen_lampiran', dataType: 'JSONB', constraints: 'NOT NULL, DEFAULT \'[]\'', nullable: false, defaultValue: '\'[]\'', description: 'Array JSON dokumen lampiran (nama berkas, URL Cloud Storage, tipe file, dsb)' },
      { columnName: 'status_pengajuan', dataType: 'status_pengajuan_enum', constraints: 'NOT NULL, DEFAULT \'DIAJUKAN\'', nullable: false, defaultValue: '\'DIAJUKAN\'', description: 'Status alur perizinan: DRAFT, DIAJUKAN, VERIFIKASI_BERKAS, SURVEI_LAPANGAN, MENUNGGU_PEMBAYARAN, DISETUJUI, DITOLAK, DICABUT' },
      { columnName: 'catatan_petugas', dataType: 'TEXT', constraints: '', nullable: true, description: 'Catatan hasil verifikasi atau arahan perbaikan berkas' },
      { columnName: 'nomor_surat_izin', dataType: 'VARCHAR(100)', constraints: '', nullable: true, description: 'Nomor Surat Keputusan / Sertifikat Izin setelah disetujui' },
      { columnName: 'tgl_terbit', dataType: 'DATE', constraints: '', nullable: true, description: 'Tanggal terbit Surat Izin' },
      { columnName: 'tgl_kedaluwarsa', dataType: 'DATE', constraints: '', nullable: true, description: 'Tanggal habis masa berlaku izin' },
      { columnName: 'biaya_final', dataType: 'NUMERIC(12,2)', constraints: 'CHECK (>= 0), DEFAULT 0.00', nullable: false, defaultValue: '0.00', description: 'Total biaya retribusi yang harus dibayarkan pemohon' },
      { columnName: 'status_pembayaran', dataType: 'status_pembayaran_enum', constraints: 'NOT NULL, DEFAULT \'BELUM_BAYAR\'', nullable: false, defaultValue: '\'BELUM_BAYAR\'', description: 'Status retribusi: BELUM_BAYAR | LUNAS | GRATIS' },
      { columnName: 'created_at', dataType: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP', nullable: false, defaultValue: 'CURRENT_TIMESTAMP', description: 'Waktu permohonan pertama kali diajukan' },
      { columnName: 'updated_at', dataType: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP', nullable: false, defaultValue: 'CURRENT_TIMESTAMP', description: 'Waktu perubahan data pengajuan' }
    ]
  },
  {
    tableName: 'log_status',
    description: 'Catatan riwayat audit (audit trail) kronologis dari setiap perpindahan status perizinan beserta aktor petugas dan alasan/keterangan.',
    primaryKey: 'id_log',
    foreignKeys: [
      { column: 'id_pengajuan', referencesTable: 'pengajuan_izin', referencesColumn: 'id_pengajuan', onDelete: 'CASCADE' },
      { column: 'id_petugas', referencesTable: 'pengguna', referencesColumn: 'id_pengguna', onDelete: 'SET NULL' }
    ],
    indexes: ['idx_log_id_pengajuan', 'idx_log_created_at (DESC)'],
    columns: [
      { columnName: 'id_log', dataType: 'SERIAL', constraints: 'PRIMARY KEY', nullable: false, description: 'ID unik log status' },
      { columnName: 'id_pengajuan', dataType: 'INTEGER', constraints: 'FK -> pengajuan_izin.id_pengajuan (ON DELETE CASCADE)', nullable: false, description: 'Relasi ke pengajuan izin yang mengalami perubahan' },
      { columnName: 'status_sebelumnya', dataType: 'status_pengajuan_enum', constraints: '', nullable: true, description: 'Status izin sebelum perubahan (NULL jika pertama kali)' },
      { columnName: 'status_baru', dataType: 'status_pengajuan_enum', constraints: 'NOT NULL', nullable: false, description: 'Status izin setelah perubahan' },
      { columnName: 'id_petugas', dataType: 'INTEGER', constraints: 'FK -> pengguna.id_pengguna (ON DELETE SET NULL)', nullable: true, description: 'ID verifikator/pejabat yang melakukan aksi pengubahan status' },
      { columnName: 'keterangan', dataType: 'TEXT', constraints: '', nullable: true, description: 'Alasan perubahan, catatan lapangan, atau disposisi surat' },
      { columnName: 'created_at', dataType: 'TIMESTAMPTZ', constraints: 'DEFAULT CURRENT_TIMESTAMP', nullable: false, defaultValue: 'CURRENT_TIMESTAMP', description: 'Timestamp saat status berubah' }
    ]
  }
];
