export type PeranPengguna = 
  | 'guru_pegawai'
  | 'pemohon' 
  | 'kepala_sekolah'
  | 'verifikator' 
  | 'pimpinan_yayasan'
  | 'kepala_dinas' 
  | 'admin';

export type StatusPengajuan = 
  | 'DRAFT'
  | 'DIAJUKAN'
  | 'VERIFIKASI_BERKAS'
  | 'SURVEI_LAPANGAN'
  | 'MENUNGGU_PEMBAYARAN'
  | 'DISETUJUI'
  | 'DITOLAK'
  | 'DICABUT';

export type StatusPembayaran = 'BELUM_BAYAR' | 'LUNAS' | 'GRATIS';

export interface Pengguna {
  id_pengguna: number;
  nama_lengkap: string;
  nik: string;
  email: string;
  password_hash?: string;
  no_telepon: string;
  alamat: string;
  peran: PeranPengguna;
  jabatan?: string;
  nuptk_nip?: string;
  kategori_staf?: string;
  fcm_token?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface JenisPerizinan {
  id_jenis: number;
  kode_izin: string;
  nama_izin: string;
  deskripsi: string;
  persyaratan: string[];
  estimasi_hari_kerja: number;
  biaya_retribusi: number;
  masa_berlaku_tahun: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface DokumenLampiran {
  id_dokumen: string;
  nama_dokumen: string;
  url: string;
  tipe_file: string;
  ukuran_kb?: number;
  uploaded_at: string;
}

export interface DataPemohonDetail {
  nama_guru_pegawai?: string;
  jabatan?: string;
  nuptk_nip?: string;
  mata_pelajaran_kelas?: string;
  alasan_izin?: string;
  tgl_mulai_izin?: string;
  tgl_selesai_izin?: string;
  durasi_hari?: number;
  guru_pengganti_inval?: string;
  tugas_inval_siswa?: string;
  nama_usaha?: string; // backward compat
  alamat_lokasi?: string;
  kelurahan?: string;
  kecamatan?: string;
  koordinat_lat?: number;
  koordinat_lng?: number;
  luas_tempat_m2?: number;
  keterangan_tambahan?: string;
  [key: string]: any;
}


export interface PengajuanIzin {
  id_pengajuan: number;
  nomor_registrasi: string;
  id_pengguna: number;
  id_jenis: number;
  data_pemohon: DataPemohonDetail;
  dokumen_lampiran: DokumenLampiran[];
  status_pengajuan: StatusPengajuan;
  catatan_petugas: string | null;
  nomor_surat_izin: string | null;
  tgl_terbit: string | null;
  tgl_kedaluwarsa: string | null;
  biaya_final: number;
  status_pembayaran: StatusPembayaran;
  created_at: string;
  updated_at: string;
  
  // Joined relation fields for convenience
  pengguna?: Pengguna;
  jenis_perizinan?: JenisPerizinan;
}

export interface LogStatus {
  id_log: number;
  id_pengajuan: number;
  status_sebelumnya: StatusPengajuan | null;
  status_baru: StatusPengajuan;
  id_petugas: number | null;
  keterangan: string;
  created_at: string;
  
  // Joined relation fields
  petugas?: Pengguna;
}

export interface CreatePengajuanDTO {
  id_pengguna: number;
  id_jenis: number;
  data_pemohon: DataPemohonDetail;
  dokumen_lampiran?: DokumenLampiran[];
  catatan_pemohon?: string;
}

export interface UpdatePengajuanDTO {
  data_pemohon?: DataPemohonDetail;
  dokumen_lampiran?: DokumenLampiran[];
  catatan_petugas?: string;
  biaya_final?: number;
  status_pembayaran?: StatusPembayaran;
}

export interface UpdateStatusDTO {
  status_baru: StatusPengajuan;
  id_petugas?: number;
  keterangan: string;
  nomor_surat_izin?: string;
  tgl_terbit?: string;
  masa_berlaku_tahun?: number;
}

export interface ApiResponse<T = any> {
  success: boolean;
  message: string;
  data?: T;
  meta?: {
    total: number;
    page: number;
    limit: number;
    totalPages: number;
  };
  error?: string;
}

export interface TableColumnDef {
  columnName: string;
  dataType: string;
  constraints: string;
  nullable: boolean;
  defaultValue?: string;
  description: string;
}

export interface TableSchemaDef {
  tableName: string;
  description: string;
  columns: TableColumnDef[];
  primaryKey: string;
  foreignKeys?: { column: string; referencesTable: string; referencesColumn: string; onDelete: string }[];
  indexes?: string[];
}
